https://docs.elest.io/platform/backups/aws-setup

Platform Features 

 Backups 

 How to Create AWS Access and Secret Key for External backups (S3) 
 On this page 

# How to Create AWS Access and Secret Key for External backups (S3) 

##### To create your AWS Access and Secret Key, follow these steps. ​ 

 Step 1 : Use your AWS account ID or account alias, your IAM user name, and your password to sign in to the IAM console 

 Step 2 : In the navigation bar on the upper right, choose your user name, and then choose Security credentials .

 Step 3 : If you want to create the AWS Access and Secret credentials with the root user, skip to step 4 ; otherwise, click Users on the left side of access management and then Add users .

 Enter your AWS Account access user name and click Next, Next, Next and Create User to proceed.

 After clicking the Create User button, you will be taken to the user list. Choose your created user name from the user list and click on it.

 Navigate to Security Credentials under User Details.

 Step 4 : Select Create access key from the Access keys section . If you already have two access keys, this button is disabled, and you must delete one before creating a new one.

On the Access key best practices & alternatives page, choose your use case to learn about additional options which can help you avoid creating a long-term access key. If you determine that your use case still requires an access key, choose Other and then choose Next .

(Optional) Set a description tag value for the access key. This adds a tag key-value pair to your IAM user. This can help you identify and rotate access keys later. The tag key is set to the access key id. The tag value is set to the access key description that you specify. When you are finished, choose to Create access key .

 For Non-Root Users : Choose Command Line Interface as an alternative and check the box, then click Next and Create Access Key. 

 For Root User : Check the box and click Create Access Key .

 Step 5 : On the Retrieve access keys page, choose either Show to reveal the value of your user's secret access key, or Download .csv file . This is your only opportunity to save your secret access key. After you've saved your secret access key in a secure location, choose Done .

 Step 6 : Now grant Administration access to the newly created keys.

 Elestio requires a AmazonS3FullAccess permission to manage your external backups for service.

 Navigate to permission in the user details to add the permission and select Add Permission 

 Select the Attach policies directly Tab to attach permission.

 Now Enter AmazonS3FullAccess into the search box and then select the AmazonS3FullAccess permission from the results.

 If you only want to grant access to your bucket which you choose for backups instead of AmazonS3FullAccess, click Create Policy, paste this JSON policy in the JSON tab, and attach it.

 { 
 "Id" : "BucketPolicy" , 
 "Version" : "2012-10-17" , 
 "Statement" : [ 
 { 
 "Sid" : "AllAccess" , 
 "Action" : "s3:*" , 
 "Effect" : "Allow" , 
 "Resource" : [ 
 "arn:aws:s3:::elestio" , 
 "arn:aws:s3:::elestio/*" 
 ] 
 } 
 ] 
 } 

 Note: If your bucket name is not elestio, then put your bucket name in place of elestio.

 After Selecting both Click Next and then click Add permission to proceed.

##### Follow these steps if you already have an access key and want to activate it instead of creating a new one. ​ 

 In the Access keys section, find the key to activate.

 To activate the key, go to Actions and select Activate .

 success
 Before adding keys to elestio, you must grant Administration access to them.

## How to Create Bucket in AWS for External backups (S3) ​ 

##### To create your bucket for backups, follow these steps. ​ 

 Step 1 : Use your AWS account ID or account alias, your IAM user name, and your password to sign in to the IAM console 

 Step 2 : Search for S3 in the Services section of the navigation menu on the top left, or just click here to go.

 Step 3 : Click the Create Bucket button for the next step.

 Step 4 : Give your bucket a name in the Bucket name column, and in the AWS Region column, choose the region where you want to create it.

 Step 5 : After you've completed both columns, scroll down and click the Create Bucket button to create it.

 Step 6 : Your bucket will be created and listed in buckets following these successful steps.

 Previous
 Automated External Backups (S3)
 Next
 Service Dashboard

 How to Create Bucket in AWS for External backups (S3)