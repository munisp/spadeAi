https://docs.elest.io/platform/services-dashboard/resync

Platform Features 

 Service Dashboard 

 Resync 

# Resync 
 After cloning a service, the overview shows a Resync option to refresh the clone from its origin.

 Click Resync in the service overview, then confirm. The process will:

Create a fresh backup from the origin.

Stop the app on the destination server.

Restore the latest backup.

Restart the service.

 This refreshes the Docker Compose stack, the .env , credentials, and volumes.

 Not copied by resync
 Global settings such as custom backup configuration, custom alert rules, and custom firewall rules are not copied during resync.

 Previous
 Storage
 Next
 Delete a Service