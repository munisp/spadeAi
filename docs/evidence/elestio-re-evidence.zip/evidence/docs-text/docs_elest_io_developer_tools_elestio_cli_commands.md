https://docs.elest.io/developer-tools/elestio-cli/commands

Developer Tools 

 Elestio CLI 

 Command Reference 
 On this page 

# Command Reference 
 The full Elestio CLI command surface for services, backups, firewall, SSL, updates, and more.

##### Authentication & Configuration ​ 
 elestio login --email X --token Y # Store credentials locally 
 elestio auth test # Verify current credentials 
 elestio whoami # Show current user info 
 elestio config # Show current configuration 
 elestio config --set-default-project X # Set a default project ID 

##### Catalog (no authentication required) ​ 
 elestio templates # List all 400+ templates 
 elestio templates search <query> # Search by name (e.g. "postgresql") 
 elestio templates info <name> # Detailed template information 
 elestio categories # List all software categories 
 elestio sizes # All provider/region/size combinations 
 elestio sizes --provider netcup # Filter sizes by provider 
 elestio sizes --provider hetzner 

##### Projects ​ 
 elestio projects # List all projects 
 elestio projects create <name> # Create a new project 
 elestio projects delete <id> --force # Delete a project 
 elestio projects members <id> # List project members 
 elestio projects add-member <id> <email> 
 elestio projects remove-member <id> <memberId> 

##### Services ​ 
 elestio services # List all services (all projects) 
 elestio services --project 123 # Filter by project 
 elestio service <vmID> # Get service details 
 elestio deploy <template> --project X --name Y # Deploy from catalog 
 elestio deploy cicd --project X --name Y # Deploy a CI/CD target VM 
 elestio delete-service <vmID> --force # Delete a service 
 elestio move-service <vmID> <projectId> # Move service to another project 
 elestio wait <vmID> # Wait until deployment completes 

 Deploy with all options: 

 elestio deploy postgresql \ 
 --project 112 \ 
 --name prod-postgres \ 
 --provider hetzner \ 
 --region fsn1 \ 
 --size LARGE-4C-8G \ 
 --support level2 

 Default values (when flags are omitted):

 Setting Default 
 Provider netcup 
 Region nbg (Germany) 
 Size MEDIUM-2C-4G 
 Support level1 

##### Power Management ​ 
 elestio reboot <vmID> # Graceful reboot 
 elestio reset <vmID> # Hard reset (power cycle) 
 elestio shutdown <vmID> # Graceful shutdown (ACPI) 
 elestio poweroff <vmID> # Force power off 
 elestio poweron <vmID> # Power on 
 elestio restart-stack <vmID> # Restart Docker containers only (fastest) 
 elestio lock <vmID> # Enable termination protection 
 elestio unlock <vmID> # Disable termination protection 
 elestio resize <vmID> --size LARGE-4C-8G # Resize VM (upgrade or downgrade) 

##### Firewall ​ 
 elestio firewall get <vmID> # List current firewall rules 

 elestio firewall enable <vmID> --rules '[ 
 {"type":"INPUT","port":"22","protocol":"tcp","targets":["0.0.0.0/0"]}, 
 {"type":"INPUT","port":"443","protocol":"tcp","targets":["0.0.0.0/0"]} 
 ]' 

 elestio firewall update <vmID> --rules '[...]' # Replace all rules 
 elestio firewall disable <vmID> # Disable firewall 

##### SSL & Custom Domains ​ 
 elestio ssl list <vmID> # List domains for a service 
 elestio ssl add <vmID> myapp.example.com # Add domain (auto-provisions SSL) 
 elestio ssl remove <vmID> myapp.example.com 

##### SSH Keys ​ 
 elestio ssh-keys list <vmID> 
 elestio ssh-keys add <vmID> --name "deploy-key" --key "ssh-ed25519 AAAA..." 
 elestio ssh-keys remove <vmID> --name "deploy-key" 

 Note: Provide only the key type and key data. Do not include the trailing comment/email.

##### Auto-Updates ​ 
 # OS-level updates 
 elestio updates system-enable <vmID> --day 0 --hour 5 --security-only 
 elestio updates system-disable <vmID> 
 elestio updates system-now <vmID> # Run OS update immediately 

 # Application-level updates 
 elestio updates app-enable <vmID> --day 0 --hour 3 
 elestio updates app-disable <vmID> 
 elestio updates app-now <vmID> # Run app update immediately 

 # Change application version 
 elestio change-version <vmID> 15 # e.g., PostgreSQL 15 

##### Alerts ​ 
 elestio alerts get <vmID> 
 elestio alerts enable <vmID> --rules '{...}' --cycle 60 
 elestio alerts disable <vmID> 

##### Access & Credentials ​ 
 elestio credentials <vmID> # App URL + admin login 
 elestio ssh <vmID> # SSH web terminal URL 
 elestio ssh <vmID> --direct # Direct SSH command (copy-paste) 
 elestio vscode <vmID> # VSCode in browser URL 
 elestio files <vmID> # File manager URL 

##### Billing ​ 
 elestio billing # Total cost across all projects 
 elestio billing project <id> # Per-service cost breakdown 

##### ID Reference ​ 
 Term Where to find it Used in 
 vmID elestio services → .vmID Most commands 
 serverID elestio services → .id Backup endpoints, notes 
 projectID elestio projects → .projectID --project flag 
 templateID elestio templates → .id elestio deploy 
 pipelineID elestio cicd pipelines → .pipelineID CI/CD commands 
 volumeID elestio volumes → .id Volume commands 

 Common mistake: vmID and serverID are different numbers for the same service. Most commands use vmID .

 Previous
 Installation and Setup
 Next
 Using the CLI as an AI Agent Skill