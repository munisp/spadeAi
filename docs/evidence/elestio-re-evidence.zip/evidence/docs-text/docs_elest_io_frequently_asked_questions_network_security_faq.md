https://docs.elest.io/frequently-asked-questions/network-security-faq

FAQ 

 Network & Security FAQ 
 On this page 

# Network & Security FAQ 
 This section covers frequently asked questions about networking, firewall configuration, private networks, and security features.

## Is it possible to restrict access to my virtual machine (with a firewall)? ​ 
 Yes, every service has a pre-configured firewall that allows access to the internet through ports specific to certain applications. From the service dashboard, you can easily restrict access to a single or a range of IPs.

 Learn more about setting your firewall 

## Can my software services communicate between different cloud providers safely? ​ 
 Every Elestio project establishes a unique and secure encrypted virtual network, allowing services within the project to communicate through private IPv4 addresses.

 This communication occurs with nearly line-speed throughput, regardless of location or service provider.

 The driving force behind this distinctive capability is Nebula, initially developed by Slack and released as open-source software in 2020. You can learn about nebula from here .

 It provides a virtual private cloud (VPC) Isolated per project.

### How can I Enable/Disable the Global Private IP? ​ 
 To toggle the Global Private IP on or off, follow these steps:

Navigate to the services section in the Elestio dashboard using the left sidebar.

Choose your specific service.

Locate the Network row in the same overview tab.

Within the Network row, find the Global Private IP switch on the right side and toggle it to enable or disable the Global Private IP.

### How to associate the Service with the Private IP rather than the Public IP? ​ 
 Taking the example of the MySQL service, if you want to bind it to the Private IP instead of the Public IP, making it accessible only within the global private network of your project in Elestio, follow these steps:

Navigate to the services section in the Elestio dashboard using the left sidebar.

Choose your specific MYSQL service.

Click the "Update Config" button in the Software row on the Overview tab.

Within the docker-compose file, locate the following section:

 ports: 
 - '24306:3306' 

 Replace it with:

 ports: 
 - 'GLOBAL_PRIVATE_IP:24306:3306' 

 The value for GLOBAL_PRIVATE_IP 10.xx.xxx.x corresponds to your Global Private IP, and you can locate it in the service details.

Click the "Update & Restart" button to apply the changes.

 Afterward, the MySQL port will only be accessible from the internal network through the global private IP address on port 24306.

 This setup is akin to a Virtual Private Cloud (VPC), where all other services deployed in the same Elestio project coexist within the same Virtual VPC.

 Previous
 Services & Deployment
 Next
 Support & Account FAQ

 Is it possible to restrict access to my virtual machine (with a firewall)? 

 Can my software services communicate between different cloud providers safely? 
 How can I Enable/Disable the Global Private IP? 

 How to associate the Service with the Private IP rather than the Public IP?