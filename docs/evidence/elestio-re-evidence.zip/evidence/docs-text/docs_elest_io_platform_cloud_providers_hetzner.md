https://docs.elest.io/platform/cloud-providers/hetzner

Platform Features 

 Cloud Providers 

 Hetzner 
 On this page 

# Hetzner 
 Hetzner is an award-winning provider, born and based in Germany. They are one of our favorite providers because they are reliable and cost effective. Most of the time, you get twice the CPU & RAM for the same price compared to other providers.

 We also love Hetzner for their commitment to promoting an energy-efficient use of the internet. All of their datacenters are powered by renewable energy.

 Bandwidth Included
 20 TB of bandwidth is included with all VM sizes.

## Supported Services ​ 
 Service Supported 
 Compute ✅ 
 Private network ✅ 
 Firewall ✅ 
 Volumes ✅ 
 Floating IP ✅ 
 Snapshots ✅ 

## Supported Regions ​ 
 Continent Country City Datacenter 
 Europe Germany Falkenstein FSN1 
 Europe Germany Nuremberg NBG1 
 Europe Finland Helsinki HEL1 
 America USA Ashburn, Virginia ASH1 

## VM Sizes ​ 
 Size Cores Ram HDD Bandwidth 
 SMALL-1C-2G 1 2GB 20GB NVME 20 TB 
 MEDIUM-2C-4G 2 4GB 40GB NVME 20 TB 
 LARGE-2C-8G 2 8GB 80GB NVME 20 TB 
 XLARGE-4C-16G 4 16GB 160GB NVME 20 TB 
 2XLARGE-8C-32G 8 32GB 240GB NVME 20 TB 
 3XLARGE-16C-64G 16 64GB 360GB NVME 20 TB 
 4XLARGE-32C-128G 32 128GB 600GB NVME 20 TB 

## Why Choose Hetzner? ​ 

 Best price-performance ratio - Get more resources for your budget

 Renewable energy - All datacenters powered by clean energy

 Generous bandwidth - 20TB included with all sizes

 NVME storage - Fast, reliable storage for all VM sizes

 European data sovereignty - Perfect for GDPR compliance

 Excellent reliability - Award-winning infrastructure provider

## Getting Started ​ 

Select Hetzner as your provider in the Elestio dashboard

Choose your preferred region (Germany for lowest latency within Europe)

Pick a VM size based on your application requirements

Deploy your service and enjoy the performance!

 Previous
 Cloud Providers
 Next
 Netcup

 Supported Services 

 Supported Regions 

 VM Sizes 

 Why Choose Hetzner? 

 Getting Started