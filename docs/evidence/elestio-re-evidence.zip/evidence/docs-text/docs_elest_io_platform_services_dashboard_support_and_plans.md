https://docs.elest.io/platform/services-dashboard/support-and-plans

Platform Features 

 Service Dashboard 

 Support and Plans 
 On this page 

# Support and Plans 
 Pick the right support level and resize your service as your needs grow.

## Support plans ​ 
 Elestio offers 3 support levels :

 Level 1 is included free with every deployed service.

 Levels 2 and 3 are for important workloads that need a guaranteed response time, longer backup retention, and priority support across multiple channels.

 Need something beyond these plans or a custom SLA? Contact sales@elest.io .

 info
 You can change your support plan once per month . Support plans are billed per hour, like all other services.

## Upgrade your service plan ​ 

Disable Termination protection.

Shut down the service.

Click Upgrade plan and select a new size.

 warning
 You must shut down the service before upgrading its plan.

 Resize CPU and RAM only
 When resizing, you can change CPU and RAM without changing disk size. Check that option to keep the ability to downgrade later.

## Change your support plan ​ 
 From the overview, click Upgrade plan on the support plan row.

 Then switch to any other support plan.

 warning
 You can change support plans once every 30 days .

 info
 Support plans are billed per hour, like all other services.

 Previous
 Versions and Updates
 Next
 AI DevOps

 Support plans 

 Upgrade your service plan 

 Change your support plan