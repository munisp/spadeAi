https://docs.elest.io/developer-tools/elestio-cli/deploying

Developer Tools 

 Elestio CLI 

 Deploying Services 
 On this page 

# Deploying Services 
 Search the catalog and deploy services from the CLI, with providers, regions, and sizes.

###### Elestio supports two deployment modes: ​ 

 Catalog Deployment (400+ pre-built open-source templates)

 CI/CD Deployment (your own custom code from GitHub or GitLab).

##### Catalog Deployment ​ 
 Use this when you need a standard open-source service (database, monitoring tool, CMS, etc.).

###### Find a template ​ 
 # Search by name 
 elestio templates search postgresql 
 elestio templates search redis 
 elestio templates search wordpress 

 # Browse all templates 
 elestio templates 

 # Get template details (ID, versions, supported providers) 
 elestio templates info postgresql 

###### Deploy a template ​ 
 # Minimal deploy (uses defaults: netcup / nbg / MEDIUM-2C-4G) 
 elestio deploy postgresql --project 112 --name my-db 

 # Full options 
 elestio deploy postgresql \ 
 --project 112 \ 
 --name prod-postgres \ 
 --provider hetzner \ 
 --region fsn1 \ 
 --size LARGE-4C-8G \ 
 --support level2 

###### Wait for the deployment to complete ​ 
 elestio wait <vmID> 
 # Polls until deploymentStatus = "Deployed" 

###### Get your service credentials ​ 
 elestio credentials <vmID> 
 # Returns: URL, admin username, admin password 

###### Common catalog examples ​ 
 # Databases 
 elestio deploy postgresql --project 112 --name prod-pg 
 elestio deploy mysql --project 112 --name prod-mysql 
 elestio deploy redis --project 112 --name cache 
 elestio deploy mongodb --project 112 --name docs-db 

 # Analytics & monitoring 
 elestio deploy grafana --project 112 --name metrics 
 elestio deploy metabase --project 112 --name bi 

 # Automation 
 elestio deploy n8n --project 112 --name automation 
 elestio deploy temporal --project 112 --name workflows 

 # CMS & web 
 elestio deploy wordpress --project 112 --name blog 
 elestio deploy ghost --project 112 --name newsletter 

##### CI/CD Deployment (Custom Code) ​ 
 Use this when you want to deploy your own application from a GitHub or GitLab repository.

###### Decision tree ​ 
 Is your app in a GitHub/GitLab repo? 
 ├── YES → Automated CI/CD (recommended) 
 │ Step 1: elestio deploy cicd --project 112 --name my-cicd 
 │ Step 2: elestio cicd create --auto --target <vmID> --name my-app --repo owner/repo --mode github 
 │ 
 └── NO (custom Docker) → Manual CI/CD 
 Step 1: elestio deploy cicd --project 112 --name my-cicd 
 Step 2: elestio ssh-keys add <vmID> --name "agent-key" --key "ssh-ed25519 ..." 
 Step 3: elestio cicd template docker > pipeline.json (edit this file) 
 Step 4: elestio cicd create pipeline.json 
 Step 5: SSH in and configure docker-compose.yml 

###### Automated GitHub/GitLab deploy ​ 
 # 1. Deploy a CI/CD target VM 
 elestio deploy cicd --project 112 --name my-cicd-target 

 # 2. Auto-create the pipeline (CLI handles SSH, Dockerfile, build, start) 
 elestio cicd create --auto \ 
 --target <vmID> \ 
 --name my-app \ 
 --repo owner/repo \ 
 --mode github \ 
 --auth-id <githubAuthID> 

 # Site is live at: https://my-app-u<userID>.vm.elestio.app/ 

 Modes available: github , github-fullstack , gitlab , gitlab-fullstack , docker 

 Optional flags: 

 --branch main # Git branch (default: main) 
 --build-cmd "npm run build" 
 --run-cmd "npm start" 
 --install-cmd "npm install" 
 --build-dir dist/ 
 --framework react 
 --node-version 20 

##### What does auto-create do automatically ​ 

Discovers the Git account linked to the auth ID

Finds the repository and selects the correct branch

Creates the pipeline via the Elestio API

Adds an SSH key to the CI/CD target VM

Writes a correct multi-stage Dockerfile (Node build + Nginx serve)

Builds the Docker image

Starts the container

Verifies HTTP 200 on the service URL

 Total time from cicd create --auto to live URL: ~2 minutes after the CI/CD target is deployed.

###### Available Providers & Sizes ​ 
 # See all available provider/region/size combinations with pricing 
 elestio sizes 

 # Filter by provider 
 elestio sizes --provider netcup 
 elestio sizes --provider hetzner 
 elestio sizes --provider aws 

###### Common sizes ​ 
 Size CPU RAM ~Price/mo 
 MEDIUM-2C-4G 2 cores 4 GB ~$14 
 LARGE-4C-8G 4 cores 8 GB ~$26 
 XL-8C-16G 8 cores 16 GB ~$49 

 You can find more at https://elest.io/pricing#pricing .

 Previous
 Using the CLI as an AI Agent Skill
 Next
 Managing Services