https://docs.elest.io/platform/databases/migrations/database-migration

Platform Features 

 Databases 

 Migration Services 

 Database Migration Guides 
 On this page 

# Database Migration Guides 
 This section covers database-specific migration guides for popular database systems. Each database type has unique migration considerations and tools.

## Supported Database Migrations ​ 

### MySQL Database Migration ​ 
 NEW: Check our Data Migration Service for MySQL to migrate more easily

 Elestio provides a robust migration tool for MySQL databases with minimal downtime and comprehensive validation.

 → Complete MySQL Migration Guide 

 Key Features: 

Built-in migration tool with real-time monitoring

Connection validation before migration

Multi-master and replica cluster support

Automated backup and recovery options

### PostgreSQL Database Migration ​ 
 Comprehensive PostgreSQL migration with support for complex schemas and data types.

 → Complete PostgreSQL Migration Guide 

 Key Features: 

Schema and data validation

Support for PostgreSQL extensions

Incremental migration options

Connection pooling optimization

### MongoDB Migration ​ 
 Document database migration with support for collections, indexes, and aggregation pipelines.

 → Complete MongoDB Migration Guide 

### Other Supported Databases ​ 

 MariaDB Migration - MySQL-compatible migration

 TimescaleDB Migration - Time-series data migration

 Redis Migration - In-memory data store migration

 KeyDB Migration - High-performance Redis-compatible migration

## General Database Migration Process ​ 
 All database migrations on Elestio follow a consistent three-step process:

### Step 1: Configure ​ 

Navigate to your database service overview in Elestio

Click on the "Migrate Database" button

Ensure your target service has sufficient disk space

Click "Get started" to begin the migration wizard

### Step 2: Validation ​ 

Provide source database connection details: 

Hostname/IP address

Port number

Database name (if required)

Username and password

Click "Run Check" to validate the connection

Review any warnings or compatibility issues

### Step 3: Migration ​ 

If validation passes, click "Start migration"

Monitor progress through real-time migration logs

Receive notification upon completion

Perform validation tests on the migrated data

## Migration Best Practices ​ 

### Pre-Migration Checklist ​ 

✅ Verify source database is accessible and stable

✅ Ensure sufficient storage space on target instance

✅ Create backup of source database

✅ Test connection parameters

✅ Plan maintenance window for minimal disruption

### During Migration ​ 

✅ Monitor migration logs for any errors

✅ Avoid making changes to source database

✅ Keep migration credentials secure

✅ Have rollback plan ready if needed

### Post-Migration Validation ​ 

✅ Compare record counts between source and target

✅ Test application connectivity

✅ Verify data integrity and consistency

✅ Update application connection strings

✅ Monitor performance metrics

## Legacy MySQL Migration Method ​ 
 For reference, here's the traditional MySQL migration process using phpMyAdmin:

### Prerequisites ​ 

Create an account on Elestio 

Log in to your MySQL admin dashboard account where your current database is hosted

Make sure the UI for the application is working fine and there are no critical errors detected in the application logs

Use the same software version when deploying on Elestio

### Export Process ​ 

Access your phpMyAdmin UI with admin credentials

Select your database to see all tables

Click on the "Export" option from the top menu

Choose "Quick" export or "Custom" for advanced options

Select SQL format and click "Export"

Save the .sql file to your local machine

### Import Process ​ 

Deploy MySQL service on Elestio

Access phpMyAdmin using provided credentials

Create a new database for your imported data

Click on the database and select "Import"

Choose your .sql file and configure import settings

Click "Import" to start the process

Verify tables and data after import completion

## Troubleshooting Common Issues ​ 

### Connection Issues ​ 

 Problem: Cannot connect to source database

 Solution: Verify firewall settings, credentials, and network accessibility

### Version Compatibility ​ 

 Problem: Migration fails due to version mismatch

 Solution: Ensure source and target versions are compatible or use compatibility mode

### Large Database Migration ​ 

 Problem: Migration times out or fails with large datasets

 Solution: Consider incremental migration or contact support for assistance

### Data Integrity Issues ​ 

 Problem: Data appears corrupted after migration

 Solution: Verify source database integrity before migration and check migration logs

## Need Help? ​ 
 For database migration assistance:

Create a support ticket 

Our database experts will provide personalized guidance

We offer assisted migration services for complex scenarios

## Related Resources ​ 

 Migration Overview - General migration guidance

 Best Practices - Comprehensive best practices guide

 Custom Applications - Migrating applications with databases

 Previous
 Database Migrations
 Next
 Migrate to Elestio Managed Services

 Supported Database Migrations 
 MySQL Database Migration 

 PostgreSQL Database Migration 

 MongoDB Migration 

 Other Supported Databases 

 General Database Migration Process 
 Step 1: Configure 

 Step 2: Validation 

 Step 3: Migration 

 Migration Best Practices 
 Pre-Migration Checklist 

 During Migration 

 Post-Migration Validation 

 Legacy MySQL Migration Method 
 Prerequisites 

 Export Process 

 Import Process 

 Troubleshooting Common Issues 
 Connection Issues 

 Version Compatibility 

 Large Database Migration 

 Data Integrity Issues 

 Need Help? 

 Related Resources