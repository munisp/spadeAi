https://docs.elest.io/developer-tools/db-migrations/mastodon-migration

Developer Tools 

 Database Migrations 

 Mastodon Migration 
 On this page 

# Migrate Mastodon Server to Elestio 
 info
 This migration document focuses on Mastodon, which is supported by Elestio. Find the complete software list here 

 This document provides a step-by-step guide for migrating your existing Mastodon server to Elestio. Elestio is designed to enhance performance, scalability, and overall system efficiency.

## 1️⃣ Pre-requisites ​ 

 Create Account : Set up your account on Elestio 

 Access Current Mastodon : Log in to your Mastodon admin dashboard where your current server is hosted

 Check Server Health : Ensure your application works correctly with no critical errors in logs

 Version Matching : Use the same Mastodon version on Elestio as your current service to prevent migration failures

## 2️⃣ Exporting the Data ​ 

### Step 1: Access Mastodon Preferences ​ 
 Log into your Mastodon server and navigate to preferences settings

### Step 2: Navigate to Import/Export ​ 
 Go to "Import and Export" and click on the "Data Export" option

### Step 3: Download CSV Data ​ 
 Click on the "CSV" file section to download the data you want to migrate. The CSV files will be stored on your local machine.

### Step 4: Additional Data Considerations ​ 
 Additional Data Export
 For complete migration, you should also export:

 PostgreSQL Database : The underlying database containing all server data

 Media Storage : All uploaded images, videos, and other media files

## 3️⃣ Setting Up Mastodon on Elestio ​ 

### Step 1: Deploy Mastodon Service ​ 

Log in to your Elestio account

Go to "Create Services" and select "Mastodon"

### Step 2: Configure Service ​ 
 Select your service provider, region, and machine preferences

### Step 3: Deploy Service ​ 
 Name your service, configure settings and support level, then click "Create Service"

## 4️⃣ Importing the Data ​ 

### Step 1: Access Elestio Mastodon ​ 
 Once deployed, navigate to the service details and use the URL provided under "Admin UI" to access your Mastodon server

### Step 2: Log in to Mastodon ​ 
 Access your new Mastodon instance and log in with the credentials provided in the Elestio dashboard

### Step 3: Access Import Settings ​ 
 Navigate to "Import and Export" and click on "Import"

### Step 4: Import CSV Data ​ 

Click the "Choose file" option under the data section

Select the "Import type" from the dropdown menu

Choose the file corresponding to your selected import type

Confirm your imports by clicking the "Confirm" button

### Step 5: Database and Media Migration ​ 
 Complete Migration
 If you exported the PostgreSQL database and media storage in step 2, ensure you:

Import the database using the PostgreSQL credentials provided on the Elestio dashboard

Upload and configure the media storage files

### Step 6: Monitor Import Progress ​ 
 After confirming imports, wait for the data to be processed. You can monitor progress on the same tab.

 Congratulations! Your data is successfully migrated to Elestio.

## 5️⃣ Testing the Migration ​ 

### Verify Data Import ​ 

Navigate through your Mastodon server

Check bookmarks, posts, and lists in their respective tabs

Look for mentions of your previous server to identify migrated content

### Example Verification ​ 
 Here's an example of successfully migrated bookmarks:

### Post-Migration Checks ​ 

 User Accounts : Verify all user accounts are properly migrated

 Content Integrity : Check that posts, media, and interactions are intact

 Federation : Test federation with other Mastodon instances

 Performance : Monitor server performance and response times

 Custom Settings : Verify server-specific settings and customizations

## 6️⃣ Post-Migration Steps ​ 
 After successful migration, consider these additional steps:

 Update DNS : Point your domain to the new Elestio Mastodon instance

 SSL Configuration : Ensure proper SSL certificate setup

 Federation Settings : Update federation and instance settings

 Backup Strategy : Set up regular backups for your Mastodon instance

 Monitoring : Configure server monitoring and alerting

 User Communication : Inform your community about the migration and any necessary actions

## 7️⃣ Federation Considerations ​ 

### Domain Migration ​ 
 If you're changing domains:

 Redirect Setup : Configure proper redirects from the old domain

 User Notification : Inform users about the domain change

 Federation Updates : Other instances will need to update their federation records

### Maintaining Federation ​ 
 To maintain existing federation relationships:

Keep the same domain if possible

Ensure proper SSL certificate configuration

Test federation with key partner instances

## 8️⃣ Need Additional Help? ​ 
 Stuck somewhere? We're here to help! Create a support ticket and we'll get back to you promptly.

## Related Resources ​ 

 Mastodon Service Details - Learn more about Elestio's Mastodon offering

 PostgreSQL Migration - For migrating your underlying database

 Best Practices - General migration tips and best practices

 Previous
 Superset Migration
 Next
 Custom Applications Migration

 1️⃣ Pre-requisites 

 2️⃣ Exporting the Data 
 Step 1: Access Mastodon Preferences 

 Step 2: Navigate to Import/Export 

 Step 3: Download CSV Data 

 Step 4: Additional Data Considerations 

 3️⃣ Setting Up Mastodon on Elestio 
 Step 1: Deploy Mastodon Service 

 Step 2: Configure Service 

 Step 3: Deploy Service 

 4️⃣ Importing the Data 
 Step 1: Access Elestio Mastodon 

 Step 2: Log in to Mastodon 

 Step 3: Access Import Settings 

 Step 4: Import CSV Data 

 Step 5: Database and Media Migration 

 Step 6: Monitor Import Progress 

 5️⃣ Testing the Migration 
 Verify Data Import 

 Example Verification 

 Post-Migration Checks 

 6️⃣ Post-Migration Steps 

 7️⃣ Federation Considerations 
 Domain Migration 

 Maintaining Federation 

 8️⃣ Need Additional Help? 

 Related Resources