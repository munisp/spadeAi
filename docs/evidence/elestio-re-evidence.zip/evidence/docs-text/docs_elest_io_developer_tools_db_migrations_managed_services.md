https://docs.elest.io/developer-tools/db-migrations/managed-services

Developer Tools 

 Database Migrations 

 Managed Services Migration 
 On this page 

# Migrate to Elestio Managed Services 
 info
 This migration document focuses on applications supported by Elestio. Find the complete software list here 

 This document provides a step-by-step guide for migrating your existing system to Elestio. Elestio is designed to enhance performance, scalability, and overall system efficiency.

## 1️⃣ Pre-requisites ​ 

 Check Support : Ensure your service is supported by Elestio. View the complete software catalogue here 

 Create Account : Set up your account on Elestio 

 Deploy Service : Deploy the service you want to migrate to. Follow deployment guides on Elestio's blogs 

 Verify Deployment : Ensure the UI works correctly with no critical errors in application logs

 Version Matching : Use the same software version as your current service to avoid migration failures

## 2️⃣ Exporting the Data ​ 

 Access Your Application : Navigate to your current application's dashboard

 Find Migration Options : Look for either "Migrate" or "Export" options

 Handle Migration Options : 

 Migration Option : Usually requires API keys - keep track of API key usage

 Export Option : Downloads a configuration file to your local machine

 Export Mounted Data : If running in Docker containers or personal VMs, export mounted data separately

 Important
 Don't forget to add mounted data to /opt/app directory inside Elestio's file system

## 3️⃣ Importing the Data ​ 

 Access Elestio Service : After deployment, access your service using the URL, username, and password from admin credentials (also sent via email)

 Navigate to Import : Find migration or import settings in the application dashboard

 Import Process : 

 Migration : Enter application ID, API keys, etc., then wait for migration to complete

 Import : Select the exported file from step 2 and wait for import to finish

 Manual Upload : If no import options exist, manually upload data to /opt/app directory using File Explorer, VSCode, or FileZilla

## 4️⃣ Testing the Migration ​ 

 Verify Functionality : Test that your application runs as intended on Elestio

 Use Integrated Tools : Utilize File Explorer, VSCode, or FileZilla to configure additional data and assets

 Troubleshooting : If issues occur, restart your instance and containers:

 docker-compose down; 
 docker-compose up -d --build 

 Check Logs : Review logs for failures, noting potential version differences between your original application and Elestio's latest version

## 5️⃣ Need Additional Help? ​ 
 Stuck somewhere? We're here to help! Create a support ticket and we'll get back to you promptly.

## Next Steps ​ 

 Specific Migrations : Check our guides for WordPress , MySQL , or other specific applications

 Custom Applications : For unsupported applications, see our Custom Applications Guide 

 Best Practices : Review our Migration Best Practices 

 Previous
 DB Migrations
 Next
 MySQL Migration

 1️⃣ Pre-requisites 

 2️⃣ Exporting the Data 

 3️⃣ Importing the Data 

 4️⃣ Testing the Migration 

 5️⃣ Need Additional Help? 

 Next Steps