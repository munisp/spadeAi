https://docs.elest.io/account-billing/legal-compliance/privacy-policy

Account & Billing 

 Legal & Compliance 

 Privacy Policy 

# Privacy Policy 
 Elestio (“Elestio” / “We”) is aware that users of Elest.io and its related applications (“Users” / “You”) value their privacy. The purpose of this Privacy Statement is to provide You with relevant information regarding the use and disclosure of personal information of Users collected though the site. We provide this Privacy Statement to help You make informed decisions on whether to use or continue using Elest.io.

 This Privacy Statement is incorporated in the Elestio’s Terms of Use and is subject to them. Capitalized terms which are not defined herein shall have the meaning set forth in our Terms of Use. Your use of Elest.io, and all of the personal information You provide in connection with such use, remain subject to the terms of this Privacy Statement, as well as to Elestio’s Terms of Use.

 Please note that any image, video, or any other content posted by Users on websites or applications created using Elest.io become published content; hence these are not considered “personally identifiable information”, and therefore are not subject to this Privacy Statement.

 1. Information Collected by Elestio 

 Upon registration, purchase of Services, and at each time You visit Elest.io or You access Your account, We collect the following information:

 a) User Provided Information: Personally identifiable information (such as name and email address) that You provide to Elestio when registering to use Elestio services, or using different functionalities on the User Apps such as uploading images and captions, uploading videos, posting messages in forums, etc.

 b) Billing Information: Elestio will collect billing information if You sign up for a paid Service, which may include Your name, address, telephone number, credit card details, and other information that is necessary in order to process the transaction. Likewise, when purchasing Our Services, Elestio may collect additional details in order to process payments and comply with tax law, which may include Your social security number or EIN, Your address, and other information, as appropriate. Under no circumstance do we store any of Your sensitive billing details. We do not retain the details of Your credit card, as this information is discarded once Your transaction is processed. Since the subscription is auto-renewed, a recurring subscription will be created by Stripe, our third-party payment gateway. Stripe will store Your billing information on their secure payment gateway, for as long as necessary, to carry out the terms of Your subscription. Should You close Your Elestio account, Your billing information will be removed by Stripe.

 c) Cookies: When You visit Elest.io, We may send one or more cookies - a small text file containing a string of alphanumeric characters - to Your computer that uniquely identifies Your browser. We use, both, session cookies and persistent cookies. A persistent cookie remains on Your hard drive after You close Your browser. Persistent cookies may be used by Your browser on subsequent visits to the site. Persistent cookies can be removed by following Your web browser's help file directions. A session cookie is temporary, and disappears after You close Your browser. You can reset Your web browser to refuse all cookies or to indicate when a cookie is being sent. However, some functionalities of Elest.io may not work properly if the feature “accept cookies” is disabled.

 d) Log Files: Log file information is automatically reported by Your browser each time You view a webpage. When You view or register on Elest.io, Our servers automatically record certain information that Your web browser sends whenever You visit a website. These server logs may include information such as Your web request, Internet Protocol (IP) address, browser type, browser language, referring/exit pages and Universal Resource Locators (URL), platform type, number of clicks, domain names, landing pages, pages viewed and the order of those pages, the amount of time spent on particular pages, the date and time of Your request, and one or more cookies that may uniquely identify Your browser.

 2. Use of the Information 

 If You submit personally identifiable information to Us through Elest.io, We may use Your personal information to:

 a) Provide the Services to You.
b) Provide customer support, respond and communicate with You about Your requests, questions, and comments.
c) Diagnose or fix technical problems.
d) Offer You Services that may be of interest to You.
e) Operate, evaluate, and improve Our business (including developing new Services, managing Our communications, determining the effectiveness of Our sales, marketing, and advertising, analyzing and enhancing our Services, websites, and apps, and performing accounting, auditing, invoicing, reconciliation, and collection activities).
f) Perform data analysis (including market and consumer search, trend analysis, financial analysis, and anonymization of personal information).
g) Protect against, identify, and prevent fraud and other criminal activity, claims, and other liabilities.
h) Comply with applicable legal requirements and our policies.

 Please be aware that any personal information or content that You voluntarily disclose online (on discussion boards, in messages areas, and blogs, within Your public profile page, etc.) becomes publicly available, and can be collected and used by others. Any images, captions, videos, or other content that You submit to the Elestio Apps may be redistributed through the Internet and other media channels, and may be viewed by the general public.

 3. Disclosure of Information 

 We do not sell, or otherwise share, personal information about You, except as described in this Privacy Statement.

 We may share personal information with third parties who perform services on Our behalf, based on Our instructions. These third parties are not authorized by us to use or disclose the information, except as necessary to perform services on Our behalf or comply with legal requirements.

 We may release personally identifiable information and/or non-personally identifiable information if required to do so by law, or in the good-faith belief that such action is necessary to comply with state laws or respond to a court order, subpoena, or search warrant.

 It may be necessary to share information in order to investigate, prevent, or take action regarding suspected or actual illegal activities, including, but not limited to, fraud, potential threats to public safety or the physical safety of any person, violations of Our Terms of Service, or as otherwise permitted by law.

 Elestio also reserves the right to disclose personally identifiable information and/or non-personally identifiable information that Elestio believes, in good-faith, is appropriate or necessary to enforce our Terms of Use, take precautions against liability, to investigate and defend Ourselves against any third-party claims or allegations, to assist government enforcement agencies, to protect the security or integrity of our websites, products, and services, and to exercise or protect the rights, property, or personal safety of Elestio, Our staff, our Users, or others.

 4. User Rights 

 The General Data Protection Regulation provides you with several rights under the legislation as a data subject. We will respond to your requests within one month of the receipt of your request, or inform you, in circumstances where an extension may be required.

 You are not obligated by law to provide Us with any information. You hereby acknowledge, warrant, and agree that any information You do provide Us is provided of Your own free will and consent, for the purposes and uses described herein.

 a) Right of Access
We will provide You with certain details relating to Your information upon receipt of a request by email from You to support@Elest.io . In order to protect the security of Your information:

 b) Right to Rectification
All information that Elestio stores related to Your account is accessible through Your user account. You may use this interface to correct, update or delete Your information at any time. We encourage You to keep this information up to date so Your customer service requests and billing processes operate efficiently.

 c) Right to Erasure
To completely remove your personal informations from our system, send an email to support@Elest.io , and ask for an account deletion. We will require you to confirm certain security information in order to verify your identity, and process your request.

 c) Right to Data Portability
You can request to receive your personal data, which you provided to us, in a structured, commonly used, and machine readable format, and have the right to transmit this data to another controller.

 d) Data Retention
We will retain Your information for as long as Your account is active, or as needed to provide You Services. We will retain and use Your information as necessary to comply with Our legal obligations, resolve disputes, and enforce Our agreements.

 e) Right to Lodge a Complaint with Data Protection Commissioner
You have the right to lodge a complaint with the Data Protection Commissioner by emailing info@dataprotection.ie , or by writing to the Data Protection Commissioner, Canal House, Station Road, Portarlington, R32 AP23 Co. Laois, Ireland.

 4.1 Data Protection Officer (DPO) 

 We have appointed a Data Protection Officer (DPO) responsible for overseeing questions in relation to this privacy policy and our data protection practices. If you have any questions about this policy or how we handle your personal data, including any requests to exercise your legal rights, please contact our DPO (Steven Betito) at: steven@elest.io 

 5. Data Security 

 We maintain administrative, technica,l and physical safeguards designed to protect the personal information that You provide against accidental, unlawful, or unauthorised destruction, loss, alteration, access, disclosure, or use. We cannot, however, ensure or warrant the security of any information You provide to Elestio, and You do so at Your own risk. Once We receive the information You submitted, Elestio makes commercially-reasonable efforts to ensure the security of Our systems. However, please note it is not guaranteed that such information may not be accessed, disclosed, altered, or destroyed by breach of any of our physical, technical, or managerial safeguards.

 To protect Your privacy and security, We take reasonable steps (such as requesting a unique password) to verify Your identity before granting You profile access or making corrections. You are responsible for maintaining the secrecy of Your unique password and account information at all times.

 If Elestio is aware of a security systems breach, then We may (i) notify You electronically so that You can take appropriate protective steps, or (ii) post a notice on Our Website.

 Given that the Internet is a global environment, using it to collect and process personal data involves the transmission of data on an international basis. This means, for instance, that data You pass to Us may be processed outside the European Economic Area, although the data will always be held securely and in accordance with applicable law.

 When processed as part of a hosted service, the information will be processed and stored on the servers of third-party providers hired to provide the hosting, and our agreements with such parties require that they not use, disclose, or share such information.

 6. Policy on Responding to External Requests for Customer Data 

 Elestio is committed to protecting the privacy, security, and confidentiality of our customers’ data.

 We will only consider external requests for customer data if one of the following conditions is met:

 The request is made pursuant to a valid and enforceable court order, warrant, or statutory obligation recognised under Irish or EU law.
The request is routed through an applicable international legal assistance mechanism (e.g., MLAT).
We have obtained the freely given, specific, informed, and unambiguous consent of the data subject.
There is a legitimate legal obligation under Irish or EU law compelling disclosure.

 We limit data collection and retention to the minimum necessary for operational purposes. We use robust security measures, including encryption, access controls, and data segregation, to protect customer data. As a result, certain data may be inaccessible even if a valid request is received.

 We aim to notify affected customers of any third-party data request involving their information, unless:

 We are legally prohibited from doing so,
The request is clearly non-contentious and already disclosed under applicable terms (e.g., fraud detection),
Immediate disclosure would compromise an investigation or endanger individuals.

 7. Other Sites 

 Our Website may contain links to other websites that are outside Our control and are not covered by this Privacy Statement. If You access other sites using the links provided, the operators of these sites may collect information from You that will be used by them in accordance with their Privacy Statement, which may differ from Ours.

 8. Changes and Updates to This Privacy Statement 

 This Privacy Statement may be revised periodically, and this will be reflected on the “last modification date” stated below. Please revisit this page to stay aware of any changes. In general, We only use Your personal information in the manner described in the Privacy Statement in effect at the time We received the personal information You provided. Your use of Our Website constitutes Your agreement to this Privacy Statement and any future revisions.

 9. Contact Information 

 You may contact Elestio in relation to this Privacy Statement by emailing support@elest.io .

 Last modification date: 2025-08-06 13:05:15

 Previous
 Legal & Compliance
 Next
 Data Processing Agreement