https://docs.elest.io/platform/cloud-providers/aws-lightsail

Platform Features 

 Cloud Providers 

 AWS Lightsail 
 On this page 

# AWS Lightsail 
 AWS is the largest cloud provider with one of the best networks available and a large number of regions and datacenters.

## Supported Services ​ 
 Service Supported 
 Compute ✅ 
 Private network ✅ 
 Firewall ✅ 
 Volumes ✅ 
 Floating IP ✅ 
 Snapshots ✅ 

 SMTP Limitation
 SMTP Services are not supported in AWS Lightsail (Mailcow, Postal, etc.).

## Supported Regions ​ 
 Continent Country City Datacenter 
 Asia India Mumbai ap-south-1 
 Asia South Korea Seoul ap-northeast-2 
 Asia Singapore Singapore ap-southeast-1 
 Asia Australia Sydney ap-southeast-2 
 Asia Japan Tokyo ap-northeast-1 
 Europe Germany Frankfurt eu-central-1 
 Europe Ireland Dublin eu-west-1 
 Europe United Kingdom London eu-west-2 
 Europe France Paris eu-west-3 
 Europe Sweden Stockholm eu-north-1 
 North America USA Ohio us-east-2 
 North America USA N. Virginia us-east-1 
 North America USA Oregon us-west-2 
 North America Canada Montreal ca-central-1 

## VM Sizes ​ 
 Size Cores Ram HDD Bandwidth 
 MICRO-1C-1G 1 1GB 40GB SSD 2 TB 
 SMALL-1C-2G 1 2GB 60GB SSD 3 TB 
 MEDIUM-2C-4G 2 4GB 80GB SSD 4 TB 
 LARGE-2C-8G 2 8GB 160GB SSD 5 TB 
 XLARGE-4C-16G 4 16GB 320GB SSD 6 TB 
 2XLARGE-8C-32G 8 32GB 640GB SSD 7 TB 

## Why Choose AWS Lightsail? ​ 

 AWS ecosystem integration - Easy integration with other AWS services

 Global infrastructure - Extensive worldwide network

 Enterprise reliability - Backed by Amazon's robust infrastructure

 Simplified pricing - Predictable monthly costs with bandwidth included

 SSD storage - Reliable solid-state storage for all sizes

 Managed by AWS - Benefit from Amazon's operational expertise

## Important Considerations ​ 

 SMTP restrictions - AWS blocks outbound SMTP traffic on port 25

 Email services - Cannot deploy mail servers like Mailcow or Postal

 Alternative solutions - Use AWS SES or external email providers instead

## Getting Started ​ 

Select AWS Lightsail as your provider in the Elestio dashboard

Choose your preferred region based on your users' location

Pick an appropriate VM size - consider bandwidth needs

Note that email/SMTP services cannot be deployed on this platform

 Previous
 Digital Ocean
 Next
 Vultr

 Supported Services 

 Supported Regions 

 VM Sizes 

 Why Choose AWS Lightsail? 

 Important Considerations 

 Getting Started