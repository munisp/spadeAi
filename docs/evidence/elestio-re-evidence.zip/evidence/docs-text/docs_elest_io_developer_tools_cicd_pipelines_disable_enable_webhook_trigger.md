https://docs.elest.io/developer-tools/cicd-pipelines/disable-enable-webhook-trigger

Developer Tools 

 CI/CD Pipelines 

 Configuration & Management 

 Enable or Disable Webhook Triggers 
 On this page 

# Enable or Disable Webhook Triggers 
 Control whether a CI/CD pipeline redeploys automatically on each git push.

 *] :pointer-events-auto R6Vx5W_threadScrollVars scroll-mb-[calc(var(--scroll-root-safe-area-inset-bottom,0px)+var(--thread-response-height))] scroll-mt-[calc(var(--header-height)+min(200px,max(70px,20svh)))]" dir="auto">Elestio CI/CD pipelines can automatically trigger a deployment when new commits are pushed to your Git repository. This is handled through a webhook integration.

 You now have full control over this behavior directly from the Elestio dashboard. You can temporarily disable the webhook trigger to prevent automatic builds and re-enable it at any time.

 This is useful when:

You want to pause deployments during maintenance

You are testing changes without triggering builds

You want to control deployments manually

##### How It Works ​ 

###### When the webhook trigger is enabled: ​ 

Every new commit pushed to the connected repository automatically triggers the pipeline.

###### When the webhook trigger is disabled: ​ 

New commits will not trigger any pipeline execution.

You can still run the pipeline manually from the dashboard.

##### Disable Webhook Trigger ​ 
 Follow these steps to disable automatic pipeline triggers:

Go to your service in the Elestio dashboard

Navigate to the CI/CD Pipeline section

Select the Pipeline that you need to update.

Locate the Webhook Trigger option

Toggle the setting to Disabled 

 Once disabled:

The pipeline will no longer run on new commits

Existing webhook configuration remains intact but inactive

##### Enable Webhook Trigger ​ 
 To re-enable automatic triggering:

Go to your service in the Elestio dashboard

Open the CI/CD Pipeline section

Select the Pipeline that you need to update.

Find the Webhook Trigger option

Toggle the setting to Enabled 

 Once enabled:

New commits will again automatically trigger the pipeline

##### Manual Pipeline Execution ​ 
 Even when the webhook trigger is disabled, you can still run the pipeline manually:

Go to the CI/CD Pipeline section

Navigate to the Build and Deploy tab.

Click on Resync Pipeline 

 This allows you to deploy changes only when needed.

##### Best Practices ​ 

Disable webhook triggers during major debugging sessions to avoid unnecessary builds

Re-enable the trigger once your changes are stable

Use manual runs to validate deployments before reactivating automatic triggers

##### Notes ​ 

Disabling the webhook does not remove it from your Git provider

No changes are required on GitHub/GitLab side

The feature is reversible at any time without side effects

 Previous
 Pipelines migration, move pipelines between CI/CD targets safely
 Next
 GitLab Self-Hosted: Personal Access Token Setup