https://docs.elest.io/platform/backups/automated-remote

Platform Features 

 Backups 

 Automated Remote Backups (Borg) 
 On this page 

# Automated Remote Backups (Borg) Remote backups are sent to another datacenter in the same continent that your service (Ashburn USA for the US, Germany for EU zone and rest of the world). We use Borg Backups to do incremental backups with deduplication. It's very fast and efficient. This kind of backup includes only the data, not the software itself.

 From the Dashboard, click on the Backups tab, then click on Automated Remote Backups .

 From there you can make new manual backups, list existing backups or restore a backup.

 info
 Retention periods depend on your support plan: 7 days on Standard, 14 days on Premium and 30 days on Enterprise.

#### Partial restoration / mount backups ​ 
 It's possible to do partial restorations by mounting the backups into the VM and exploring them to copy only few files with this process:

 Open the terminal and type this:

 cd /opt/borg; 
 ./backupMount.sh; 

 You can then explore the mounted backups in /mnt/backups-mount from there you can copy some files to your real app folder in /opt/app/ 

 WARNING : do not forget to unmount the backups after usage with this command:

 cd /opt/borg; 
 ./backupUmount.sh; 

 Previous
 Manual Local Backups
 Next
 Automated VM Snapshots