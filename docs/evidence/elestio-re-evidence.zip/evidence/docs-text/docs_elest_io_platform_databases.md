https://docs.elest.io/platform/databases/

Platform Features 

 Databases 

 Databases 
 On this page 

# Managed Databases 
 Deploy and run databases on Elestio with automated backups, monitoring, migration tools, and optional clustering. Per-database guides live under Software Guides .

## Support plans ​ 
 Support is billed hourly and can change once a month. Each level sets your backup retention, snapshots, response time, and channels.

 Level 1 — Free. 7 days remote backup retention, email support, 3-day response time, proactive monitoring. No snapshots or SLA. Best for testing.

 Level 2 — $0.0685/hour . 14 days retention, 2 snapshots, email support, 24-hour response time (business hours), priority queuing. Best for staging.

 Level 3 — $0.2740/hour . 30 days retention, 4 snapshots, email and phone support, 4-hour response time (business hours), email alerts, priority queuing, and a dedicated Customer Success Manager. Best for production.

## Supported databases ​ 
 Relational 

 MySQL — Reliable, widely used open-source RDBMS.

 PostgreSQL — Advanced, standards-compliant, extensible RDBMS.

 MariaDB — Community-developed MySQL fork.

 TimescaleDB — Time-series database built on PostgreSQL.

 NoSQL and key-value 

 Redis — In-memory data store, cache, and message broker.

 KeyDB — Multi-threaded, Redis-compatible.

 Valkey — Redis-compatible in-memory database.

 MongoDB — Document-oriented NoSQL database.

 Cassandra — Distributed NoSQL with no single point of failure.

 ScyllaDB — High-performance, Cassandra-compatible.

 Specialized 

 ClickHouse — Columnar OLAP database for analytics.

 Hydra — Columnar Postgres for analytics.

 ColumnStore — Columnar storage engine for analytics.

 Neo4j — Graph database for connected data.

 Milvus — Vector database for similarity search.

 Weaviate — Vector search engine for semantic search.

## Backups and retention ​ 
 Every managed database is backed up automatically. Three methods are available:

 Manual local backups — User-initiated, stored on the local server. Fast to take and restore, but no redundancy against hardware failure.

 Automated remote backups (Borg) — Sent automatically to a different datacenter on the same continent. Deduplicated and encrypted for efficient, secure, redundant backups.

 External S3 backups — Stored in your own S3 or S3-compatible bucket, giving you full ownership and control.

 Retention follows your support plan: 7 days (Level 1), 14 days (Level 2), 30 days (Level 3). See the backups documentation for details.

## Migration and clustering ​ 

 Migration service — Move databases from external sources with minimal downtime.

 Clustering — Available for MySQL (multi-master or replica) and KeyDB (Redis-compatible). More engines are being added.

 Previous
 Open Telekom Cloud (BYO-TCloud)
 Next
 Database Migrations

 Support plans 

 Supported databases 

 Backups and retention 

 Migration and clustering