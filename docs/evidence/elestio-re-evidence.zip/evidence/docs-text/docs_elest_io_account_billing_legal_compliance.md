https://docs.elest.io/account-billing/legal-compliance/

Account & Billing 

 Legal & Compliance 

 Legal & Compliance 
 On this page 

# Legal & Compliance 
 Elestio is SOC 2 Type 2, ISO 27001, HIPAA, and GDPR compliant . Every service runs on a dedicated instance with encrypted storage, automated security patches, and 24/7 monitoring.

 For the full picture, see the Security & Compliance page .

## Legal documents ​ 

 Data Processing Agreement — How Elestio processes Personal Data on your behalf under the GDPR.

 Subcontractors & Sub-processors — The third parties Elestio engages, and what each one is used for.

 Privacy Policy — How we collect, use, and protect your personal data.

 Terms of Service — The agreement that governs your use of Elestio.

## Certifications and compliance ​ 
 Compliance is verified through continuous third-party evaluation.

 SOC 2 Type 2 — AICPA auditing standard for security, availability, and confidentiality controls.

 ISO 27001 — International standard for Information Security Management Systems.

 GDPR — EU and EEA regulation for data protection and privacy.

 HIPAA — U.S. regulation for the privacy and security of health data.

## Security at every layer ​ 

 Dedicated hardware — Every service runs on a dedicated VM with kernel-level security.

 End-to-end encryption — Connections between your computer, the dashboard, and your services are encrypted with TLS.

 Network safeguards — Firewalls with IP whitelisting, plus Bring Your Own VM (BYOVM) and Bring Your Own Account (BYOA) for extra control.

 Backups — External S3-compatible backups for efficient recovery, plus local backups for flexibility.

 Yearly security audits — External evaluations every year, with an internal Security Operations team continuously strengthening defenses.

 Automated updates — Software and system updates applied regularly, without manual intervention.

## Questions? ​ 
 For anything about compliance, privacy, or security:

 Email — support@elest.io 

 Security & Compliance — elest.io/security-and-compliance 

 Previous
 Bandwidth Billing
 Next
 Privacy Policy

 Legal documents 

 Certifications and compliance 

 Security at every layer 

 Questions?