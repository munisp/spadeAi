https://docs.elest.io/developer-tools/cicd-pipelines

Developer Tools 

 CI/CD Pipelines 

 CI/CD Pipelines 
 On this page 

# CI/CD Pipelines 
 Go from source code to production with CI/CD Pipelines. We support GitHub, GitLab & docker registries as source. Pipelines can be deployed on any cloud, even on-premise.

## Quick Navigation ​ 
 This comprehensive documentation covers all aspects of Elestio CI/CD Pipelines, organized by workflow and use case:

### Getting Started ​ 

 Overview & Introduction - Understanding Elestio CI/CD pipelines, features, and benefits

 Deploy Your First CI/CD Pipeline - Complete step-by-step guide from Git to production

### Deployment Methods ​ 

 Docker Compose Apps - Deploy WordPress, MySQL, Redis, Keycloak and other apps

 Custom Docker Compose - Deploy your own Docker images using custom docker-compose

### Framework-Specific Guides ​ 

 React Application - Deploy React applications with optimal configuration

 Node.js Express with Pug - Deploy Node.js apps with static frontend

 Nuxt.js with Preinstall Scripts - Deploy Nuxt apps with custom setup scripts

### Advanced Features ​ 

 Clone Template Feature - Deploy apps using the clone template functionality

 Third-Party Git Repository Import - Import and deploy any public Git repository

 Git Submodule Repositories - Handle repositories with submodules

### Configuration & Management ​ 

 Custom Domains - Set up custom domains with automatic SSL certificates

 Create Custom Templates - Build your own elestio.yml templates for automated deployments

 Clone CI/CD Pipelines - Duplicate existing pipelines for different environments

 Pipeline Migration - Move pipelines between CI/CD targets safely

## Popular Use Cases ​ 

### Web Applications ​ 

 Frontend Apps : React, Vue.js, Angular, Nuxt.js, static websites

 Backend APIs : Node.js, Python, PHP, Java applications

 Full-Stack : Complete applications with databases

### Containerized Applications ​ 

 Docker Images : Deploy from any Docker registry (Docker Hub, GitHub Registry, private registries)

 Docker Compose : Multi-container applications like WordPress + MySQL

 Microservices : Distributed application architectures

### Development Workflows ​ 

 Git-based Deployment : Automatic deployments on code changes

 Template Reuse : Clone and modify existing configurations

 Multi-Environment : Production, staging, and development deployments

## Key Benefits ​ 

 No Build Minutes Charges - Pay only for infrastructure, not build time

 Multi-Cloud Support - Deploy to 132+ datacenters across 29 countries

 Automatic SSL - Free SSL certificates and renewals

 Pipeline Migration - Move applications between targets with one click

 Flexible Scaling - From 1 CPU/2GB to 48 CPU/256GB RAM

 Any Linux Stack - Support for all popular frameworks and languages

## Quick Reference ​ 
 Task Documentation 
 Deploy your first app Getting Started Guide 
 Deploy React app React Deployment 
 Deploy Node.js app Node.js + Pug Guide 
 Set up custom domain Custom Domains 
 Create custom template Template Creation 
 Deploy Docker app Docker Compose 
 Clone existing pipeline Pipeline Cloning 
 Migrate between targets Pipeline Migration 

 Ready to get started? Begin with the overview to understand the platform, then follow the complete deployment guide to deploy your first application.

 Previous
 Elestio Terraform provider
 Next
 Overview

 Quick Navigation 
 Getting Started 

 Deployment Methods 

 Framework-Specific Guides 

 Advanced Features 

 Configuration & Management 

 Popular Use Cases 
 Web Applications 

 Containerized Applications 

 Development Workflows 

 Key Benefits 

 Quick Reference