https://docs.elest.io/getting-started/create-account

Getting Started 

 Create Account 
 On this page 

# Create an Account 
 Sign up with OAuth or email in under a minute. MFA is on by default.

 Head to the Elestio signup page to begin.

## Sign up with OAuth ​ 
 Connect Elestio to your existing GitHub, GitLab, or Google account using OAuth2.

## Sign up with email ​ 
 Or use any valid email address.

 Multi-factor authentication
 MFA is enabled by default for email accounts, and a new code is sent to your inbox on every login. If you use OAuth, your account security depends on your provider (Google, GitHub, GitLab), so make sure MFA is enabled there too.

 Authenticator apps
 Elestio also supports TOTP-based MFA from Authy, Google Authenticator, and Microsoft Authenticator. Manage it anytime from your account settings.

 Previous
 Getting Started
 Next
 Deploy Service

 Sign up with OAuth 

 Sign up with email