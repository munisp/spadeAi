https://docs.elest.io/platform/services-dashboard/

Platform Features 

 Service Dashboard 

 Service Dashboard 
 On this page 

# Service Dashboard 
 Once a service is deployed, the dashboard is where you run it day to day. Power and protection, plans and versions, updates, built-in tools, monitoring, and backups all live here.

## What you can manage ​ 

 Protection and power — Prevent accidental deletion, reboot, shut down, or power off.

 Admin UI and credentials — Reach the app admin interface and database connection details.

 Versions and updates — Change software version and configure OS and software updates.

 Support and plans — Pick a support level and resize your service.

 Networking and projects — Track bandwidth and move a service between projects.

 Storage — Increase your AWS disk or volume size.

 Resync — Refresh a cloned service from its origin.

 Delete a service — Remove a service safely.

 Tools — VS Code, File Explorer, Web Terminal, and SSH password reset.

 Monitoring — Metrics, alerts, notes, and backups.

 Previous
 How to Create AWS Access and Secret Key for External backups (S3)
 Next
 Protection and Power

 What you can manage