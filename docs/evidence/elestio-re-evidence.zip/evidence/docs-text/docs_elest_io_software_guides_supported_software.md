https://docs.elest.io/software-guides/supported-software

Software Guides 

 Supported Software 

# Supported Software 
 Over 400+ open source services, each fully managed end to end. We add more every month.

 For every supported software, we run a complete managed lifecycle:

 Setup — A Docker Compose based install script.

 Backups — Pre and post backup and restore scripts, so every backup is consistent and restores correctly.

 Operations — Test, benchmark, maintenance, and upgrade scripts.

 We focus on software that is:

Available with a web UI

Available with API access

Safe and secure

Frequently updated and well maintained

Popular and in demand

 Browse the full catalog at elest.io/fully-managed-services .

 Previous
 FAQ
 Next
 ClickHouse