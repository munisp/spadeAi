https://docs.elest.io/frequently-asked-questions/

FAQ 

 Elestio FAQ - Frequently Asked Questions & Troubleshooting 
 On this page 

# Frequently Asked Questions 
 Welcome to the Elestio FAQ section. Here you'll find answers to the most commonly asked questions about our platform, organized by topic for easy navigation.

## FAQ Categories ​ 

### 💳 Billing & Payment FAQ ​ 
 Find answers to questions about billing, payments, credits, and account funding:

Credit warnings and auto-recharge

Payment failures and troubleshooting

Service reactivation after funding

Project ownership and billing transfers

### 🚀 Services & Deployment FAQ ​ 
 Learn about service management, deployments, and infrastructure options:

Installing multiple software on VMs

Service migration and cloning

BYOVM (Bring Your Own VM) capabilities

AWS integration issues

Domain and SSL issues

### 🔒 Network & Security FAQ ​ 
 Understand networking, firewall configuration, and security features:

Firewall and access restrictions

Global private networks

Service communication across cloud providers

Private IP configuration

### 🎧 Support & Account FAQ ​ 
 Information about support plans and account management:

Support plan types and features

Response times and SLA details

Available support channels

### 🗄️ Database FAQ ​ 
 Database-specific questions and configurations:

MySQL OUTFILE and INFILE usage

Docker container modifications

CSV data import/export

### ⚙️ System Maintenance FAQ ​ 
 System maintenance, OS updates, and optimization:

Automatic log file cleanup

OS upgrade management

Disk space optimization

Maintenance scheduling

### 🔧 Troubleshooting FAQ ​ 
 Resolve common errors and technical issues:

Borg backup lock issues

Borg cache errors

Remote backup troubleshooting

## Need More Help? ​ 
 If you can't find the answer to your question in these FAQs, don't hesitate to contact our support team:

 Email Support : Available for all plans

 Priority Support : Available for Staging and Production plans

 Phone Support : Available for Production plans

 Contact Support 

## Contributing to FAQ ​ 
 Have a question that's not covered here? Let us know through our support channels, and we'll consider adding it to improve this resource for everyone.

 Previous
 Newsletter
 Next
 Billing & Payments

 FAQ Categories 
 💳 Billing & Payment FAQ 

 🚀 Services & Deployment FAQ 

 🔒 Network & Security FAQ 

 🎧 Support & Account FAQ 

 🗄️ Database FAQ 

 ⚙️ System Maintenance FAQ 

 🔧 Troubleshooting FAQ 

 Need More Help? 

 Contributing to FAQ