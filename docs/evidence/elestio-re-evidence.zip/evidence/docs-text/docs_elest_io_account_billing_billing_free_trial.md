https://docs.elest.io/account-billing/billing/free-trial

Account & Billing 

 Billing 

 Free Trial 
 On this page 

# Free Trial 
 Elestio offers a 3-day free trial with $20 in credits, during which you can launch up to 2 services.

 Additionally to the services in our catalog, you have access to load balancers, volumes, and CI/CD pipelines. Domain names are the only thing that cannot be acquired with free credits.

 info
 For important details about the free trial, please review the Elestio Free Trial Policy & Fair Use Statement .

## End of the Free Trial ​ 
 The Free Trial ends when you use all of your credit, or after 3 days, whichever happens first. At that time, the following conditions apply:

Your account will be automatically renewed for $25 or less based on monthly spending if you have active services.

You'll need to add credits to your account to keep all the services you've deployed.

If you do not wish to be billed, simply delete all services from your account and disable auto-refill.

 info
 You may disable auto-refill in your payment options from the left sidebar Account tab, or you can click here to disable auto-refill.

 info
 Any resources you create during the trial will be destroyed if your account runs out of credits. You may add credit using the add credit tab of the Account tab on the left sidebar, or by clicking here to add credits.

## Related Topics ​ 

 Payment Options - Learn how to disable auto-refill

 Add Credits - Add funds after your trial ends

 Previous
 Invoices
 Next
 Elestio Free Trial Policy & Fair Use Statement

 End of the Free Trial 

 Related Topics