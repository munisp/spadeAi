https://docs.elest.io/platform/security/termination-protection

Platform Features 

 Security 

 Termination Protection 

# Termination Protection and Grace Period 
 Enable or disable Termination protection from the dashboard Overview , using the toggle on the right. It is disabled by default .

 warning
 While Termination protection is on, you cannot change software versions, delete, shut down, power off, reset, or reboot the service. Disable it first to make any of these changes.

 Grace period
 After a service is deleted, backups are kept for 7 days , so you can restore the service within that window for any reason.

 Previous
 Rate Limiter and Output Cache
 Next
 SSH Keys