https://docs.elest.io/platform/domains/locking

Platform Features 

 Domains 

 Lock or Unlock a Domain 
 On this page 

# Lock or Unlock a Domain 
 Lock or unlock a domain to control whether it can be transferred.

###### The domain lock is an added layer of security to guard against unauthorized domain transfers. You can lock or unlock your domain by following the instructions below: ​ 
 Step 1: Navigate to the Domains page from the left sidebar.

 Step 2: Select your domain from the list to change the setting of the lock/unlock domain.

 Step 3: In the Domain overview, click the Security tab.

 Step 4: Now, In the Domain Lock row, click the Toggle Switch to lock/unlock the domain.

 Once the switch to "lock/unlock" the domain has been flipped, a confirmation window will now open, allowing you to confirm the operation by clicking the "Lock" or "Unlock" button.

 As soon as you confirm the action, your domain's Lock/Unlock settings will change.

 This only affects transfers, so it is best to leave a domain name locked unless you are about to transfer it to another registrar.

###### Why won't my domain name unlock? ​ 
 ICANN , the group that regulates the distribution of domain names, has a very strict rule that domain names cannot be transferred to another registrar within 60 days of the date they were registered or transferred to a new registrar. This is done to prevent fraud. Unfortunately, since this is an ICANN rule and not an elestio rule, there is no way we can remove the 60-day hold.

 The good news is that you can fully use your site while the domain name is locked. Your hosting provider or website builder will give you either name servers or DNS records to point to the domain name.

 Previous
 Change Nameservers
 Next
 Load Balancers