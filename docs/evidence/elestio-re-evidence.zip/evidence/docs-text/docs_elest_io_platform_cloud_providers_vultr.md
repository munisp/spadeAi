https://docs.elest.io/platform/cloud-providers/vultr

Platform Features 

 Cloud Providers 

 Vultr 
 On this page 

# Vultr 
 VULTR is a great cloud provider with a large number of regions and datacenters available. They provide good network and overall reliability.

## Supported Services ​ 
 Service Support 
 Compute ✅ High Frequency CPU 
 Private network ✅ 
 Firewall ✅ 
 Volumes ✅ 
 Floating IP ✅ 
 Snapshots ✅ 

## Supported Regions ​ 
 Continent Country City Datacenter 
 Asia South Korea Seoul icn 
 Asia Japan Tokyo nrt 
 Asia Singapore Singapore sgp 
 Asia Australia Sydney syd 
 Europe Netherlands Amsterdam ams 
 Europe France Paris cdg 
 Europe Germany Frankfurt fra 
 Europe United Kingdom London lhr 
 North America USA Atlanta atl 
 North America USA Dallas dfw 
 North America USA New Jersey ewr 
 North America USA Los Angeles lax 
 North America USA Miami mia 
 North America USA Chicago ord 
 North America USA Seattle sea 
 North America USA Silicon Valley sjc 
 North America Canada Toronto yto 

## VM Sizes ​ 
 Size Cores Ram HDD Bandwidth 
 MICRO-1C-1G 1 1GB 32GB SSD 1 TB 
 SMALL-1C-2G 1 2GB 64GB SSD 2 TB 
 MEDIUM-2C-4G 2 4GB 128GB SSD 3 TB 
 LARGE-4C-16G 4 16GB 384GB SSD 5 TB 
 XLARGE-8C-32G 8 32GB 512GB SSD 7 TB 
 2XLARGE-12C-48G 12 48GB 768GB SSD 8 TB 

 Previous
 AWS Lightsail
 Next
 Linode

 Supported Services 

 Supported Regions 

 VM Sizes