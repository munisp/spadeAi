https://docs.elest.io/platform/security/smtp

Platform Features 

 Security 

 SMTP Service 
 On this page 

# SMTP Service 
 Every deployed service includes a basic preconfigured SMTP service, useful for sending alerts and notifications. It is free, with a few limits.

## What is included ​ 

 Transactional email only. Marketing email is not permitted.

 Up to 300 emails per hour , which is up to 7,200 per day .

 Sender must be [domain]@vm.elestio.app , where [domain] is your service URL.

 Available from the global private network IP of your VM only.

 danger
 Sending marketing email leads to suspension or termination of your service.

 warning
 Sending from any other address is rejected.

## Use an external SMTP provider ​ 
 To use a custom sender address or go beyond these limits, change the SMTP settings in your software web UI to point at another provider. Recommended options:

 AWS SES 

 Brevo (SendinBlue) 

 Mailgun 

 SendGrid 

 Previous
 SSH Keys
 Next
 Multi-Factor Authentication

 What is included 

 Use an external SMTP provider