https://docs.elest.io/platform/cloud-providers/netcup

Platform Features 

 Cloud Providers 

 Netcup 
 On this page 

# Netcup 
 Deploy on Netcup, a German provider with AMD EPYC servers, 20 TB bandwidth, and 7 remote backups included.

 Netcup is a well-established German hosting provider known for their high-performance virtual servers at competitive prices. They offer powerful AMD EPYC-based infrastructure with excellent value, especially in Europe. Netcup provides fully managed services with included remote backups, making them a solid choice for teams looking for reliability without the operational overhead.

 tip
 20 TB of bandwidth is included with all VM sizes.

### Supported Services ​ 
 Service Status 
 Compute ✅ 
 Private Network ✅ 
 Firewall ✅ 
 Volumes ❌ 
 Floating IP ❌ 
 Snapshots ❌ 
 Remote Backups ✅ (7 included) 

### Supported Regions ​ 
 Continent Country City Datacenter 
 Europe Germany Nuremberg NBG 
 North America United States Manassas, Virginia MNS 

### VM Sizes ​ 
 All VMs run on AMD EPYC 9645 processors and include 20 TB bandwidth and 7 remote backups . Available in Europe (Germany, Nuremberg) and North America (United States, Manassas).

 Size Cores RAM Storage Bandwidth 
 MEDIUM-2C-4G 2 4 GB 60 GB NVMe 20 TB 
 LARGE-4C-8G 4 8 GB 100 GB NVMe 20 TB 
 XLARGE-8C-16G 8 16 GB 200 GB NVMe 20 TB 
 2XLARGE-16C-32G 16 32 GB 400 GB NVMe 20 TB 
 3XLARGE-16C-64G 16 64 GB 600 GB NVMe 20 TB 

### Features ​ 

 Fully Managed : All servers come with full management included

 AMD EPYC 9645 : Latest generation AMD server processors

 7 Remote Backups : Automatic backup retention included

 20 TB Bandwidth : Generous bandwidth allocation on all plans

 NVMe Storage : Fast SSD storage on all VM sizes

 Previous
 Hetzner
 Next
 Digital Ocean

 Supported Services 

 Supported Regions 

 VM Sizes 

 Features