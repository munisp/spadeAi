https://docs.elest.io/developer-tools/elestio-cli/troubleshooting

Developer Tools 

 Elestio CLI 

 Troubleshooting and Errors 
 On this page 

# Troubleshooting and Errors 
 Diagnose authentication, deployment, ID, and pipeline issues with the Elestio CLI.

##### Error Reference Table ​ 
 Error message Cause Solution 
 Not configured No credentials stored Run elestio login --email X --token Y 
 Authentication failed Wrong credentials or expired token Regenerate token at dash.elest.io/account/security 
 Account not approved New account without approval Wait for approval or contact support@elest.io 
 Template not found Wrong name or ID Run elestio templates search 
 Invalid serverType Provider/region/size combo invalid Check elestio sizes --provider X 
 Service not found Wrong vmID or wrong project Run elestio services --project X 
 Deployment timeout Deployment is taking too long Check dashboard; contact support if > 10 min 
 Project not found Wrong projectId Run elestio projects to find the correct ID 

##### Authentication Issues ​ 

###### "Authentication failed" repeatedly ​ 
 # Step 1: Check current config 
 elestio config 

 # Step 2: Re-generate token in the Elestio dashboard 
 # Go to: https://dash.elest.io/account/security → Manage API Tokens → Create Token 

 # Step 3: Update credentials 
 elestio login --email "you@example.com" --token "new_token" 

 # Step 4: Verify 
 elestio auth test 

###### The wrong user is being used ​ 
 elestio whoami # Check which account is active 
 elestio config # See stored configuration 

##### Deployment Issues ​ 

###### Service stuck in "Deploying" state ​ 

Normal deployment takes 2–5 minutes 

CI/CD target deployment may take up to 10 minutes 

If > 10 minutes: check the Elestio dashboard for error messages

Contact support@elest.io if still stuck after 15+ minutes

 # Poll until deployed 
 elestio wait <vmID> 

 # Check current status 
 elestio service <vmID> 

###### "Service not found," but it exists ​ 
 # Verify you are using vmID (not serverID) 
 elestio services --project 112 

 # Both IDs are shown — ensure you use the correct one: 
 # vmID → most commands (firewall, ssl, power, etc.) 
 # id → backup endpoints 

###### "Invalid serverType" when deploying ​ 
 # Check valid combinations for your provider 
 elestio sizes --provider netcup 
 elestio sizes --provider hetzner 

##### Pipeline Issues ​ 

###### Pipeline not building ​ 
 # View build logs 
 elestio cicd pipeline-logs <vmID> <pipelineID> 

 # Restart the pipeline 
 elestio cicd pipeline-restart <vmID> <pipelineID> 

###### App deployed but not reachable in the browser ​ 

Check that your app is binding to the internal network, not 0.0.0.0 : 

Correct: 172.17.0.1:3000 

Wrong: 0.0.0.0:3000 

SSH in and check containers:

 ssh root@<ipv4> 
 cd /opt/app/<pipeline-name> 
 docker-compose ps 
 docker-compose logs 

###### Pipeline fails after code push ​ 
 # View deployment history 
 elestio cicd pipeline-history <vmID> <pipelineID> 

 # Check latest logs 
 elestio cicd pipeline-logs <vmID> <pipelineID> 

##### Firewall Issues ​ 

###### Can't reach the service after enabling the firewall ​ 

Ensure port 443 (HTTPS) is in the rules

Ensure port 22 (SSH) is included if you need SSH access

Re-check rules:

 elestio firewall get <vmID> 

Temporarily disable to test:

 elestio firewall disable <vmID> 

##### SSL/Domain Issues ​ 

###### SSL certificate not provisioning ​ 

Ensure your DNS A record points to the service's IPv4 before running ssl add 

DNS propagation can take up to 48 hours (typically 5–30 minutes)

Check: elestio ssl list 

Remove and re-add if stuck: elestio ssl remove then re-add

##### Resize/Downgrade Issues ​ 

###### Service blocked after downgrade attempt ​ 
 This happens when trying to downgrade on a provider that doesn't support it (Hetzner, GCP).

 Supported for downgrade: Netcup, AWS, Azure, and Scaleway only.

 Resolution: Contact support@elest.io with the vmID. They can restore the service.

##### General Debugging Flow ​ 
 # 1. Verify authentication 
 elestio auth test 

 # 2. Check service status 
 elestio service <vmID> 

 # 3. Restart the application stack (fastest recovery) 
 elestio restart-stack <vmID> 

 # 4. If pipeline involved, check logs 
 elestio cicd pipeline-logs <vmID> <pipelineID> 

 # 5. Full reboot if restart-stack doesn't help 
 elestio reboot <vmID> 

##### Getting Help ​ 
 Channel Details 
 Email support support@elest.io 
 Dashboard https://dash.elest.io 
 API Docs https://api-doc.elest.io 
 Templates https://elest.io/fully-managed-services 

 Previous
 Cloud Provider Guide
 Next
 Elestio Terraform provider