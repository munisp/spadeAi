https://docs.elest.io/platform/object-storage/lifecycle-rules

Platform Features 

 Object Storage 

 Lifecycle rules 
 On this page 

# Lifecycle rules 
 Lifecycle rules delete old files after a number of days. Perfect for logs, exports and old backups you do not need to keep for ever.

 In the bucket, open Settings > Lifecycle rules and click Add a rule .

 Folder : the rule applies to the files of this folder. Leave empty for every file of the bucket.

 Delete the files after a number of days (deleted for good).

Click Save the rule .

 Rules run once a day, at midnight UTC. A bucket can have up to 10 rules.

## Good to know ​ 

Without any rule, files stay until you delete them.

 Previous
 Custom domain and public access
 Next
 Recycle bin

 Good to know