https://docs.elest.io/frequently-asked-questions/system-maintenance-faq

FAQ 

 System Maintenance 
 On this page 

# System Maintenance 
 This section covers frequently asked questions about system maintenance, OS updates, log management, and disk space optimization.

## How can I automatically remove system log files in order to free up disk space? ​ 
 By default, new instances are automatically configured to delete log files on a daily basis.

 However, if your virtual machine (VM) does not have these files at /opt/maintenance-daily.sh or if you have deleted them, you can easily configure the deletion process by following the steps below.

 To create a script that deletes log files on your VM, begin by accessing the terminal (Open Terminal). You can find it within the service details on the top right side of the dashboard.

 Once the terminal is open, copy and paste the provided code below to create the script responsible for deleting log files.

 #Create a script to remove logs every day. 
 echo 'echo "$(tail -c 30m /tmp/appStack.log)" > /tmp/appStack.log' >> /opt/maintenance-daily.sh 
 echo 'echo "$(tail -c 30m /tmp/externalBackup.log)" > /tmp/externalBackup.log' >> /opt/maintenance-daily.sh 
 echo 'echo "$(tail -c 30m /var/log/syslog)" > /var/log/syslog' >> /opt/maintenance-daily.sh 
 echo 'journalctl --vacuum-time=10d --vacuum-size=500M;' >> /opt/maintenance-daily.sh 

 #Grant the script executable permissions. 
 chmod +x /opt/maintenance-daily.sh 

 #To run these scripts every day, create a cron job on the virtual machine. 
 crontab -l | { cat; echo "0 1 * * * /opt/maintenance-daily.sh"; } | crontab - 

 You can modify these cron execution times by replacing 0 1 * * * with your own cron execution times.

 We keep a 30-mb log file by default, however, you can change the 30m number to something else if you wish to keep a larger log file.

## How are operating system(OS) upgrades managed? ​ 

### Automatic Minor OS Updates: ​ 
 Minor operating system updates are automatically performed every Sunday by default. (Note: This setting can be modified or disabled in the service settings.)

### Major OS Updates: ​ 

For major updates, utilize our clone feature. This involves cloning the application stack and data from your current instance on an end-of-life OS (e.g., Ubuntu 20.04) and deploying it to a new instance with the latest OS version (e.g., Ubuntu 22.04).

This cloning feature is accessible to all our customers.

After cloning, review and ensure everything is functioning properly before redirecting your DNS from the old instance to the new one.

### In-Place Update (with Level 3 Support Plan): ​ 
 If you have a Level 3 support plan, our team can perform an in-place update on your existing instance (with up to 1 hour of downtime).

 Info: Feel free to contact our support team if you have any further questions or concerns about OS upgrades.

 Previous
 Database FAQ
 Next
 Troubleshooting

 How can I automatically remove system log files in order to free up disk space? 

 How are operating system(OS) upgrades managed? 
 Automatic Minor OS Updates: 

 Major OS Updates: 

 In-Place Update (with Level 3 Support Plan):