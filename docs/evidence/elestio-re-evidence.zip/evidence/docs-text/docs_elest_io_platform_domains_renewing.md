https://docs.elest.io/platform/domains/renewing

Platform Features 

 Domains 

 Renew a Domain 
 On this page 

# Renew a Domain 
 Renew a domain on Elestio for 1 to 10 years before it expires.

###### It is always best to renew a domain name before it expires so there is no interruption in service and there is no risk of losing ownership of the domain name. ​ 
 info
 You can renew a domain for a minimum of 1 year and up to a maximum of 10 (you cannot exceed 10 years).

###### You can renew your domain by following these simple steps: ​ 
 Step 1: Navigate to the ** Domains **page from the left sidebar.

 Step 2: Choose your domain from the list that you want to renew.

 Step 3: In the Domain Renewals row, click the Show Setting button.

 Step 4: Now you can review the domain's renewal pricing and select the number of years you want to renew before clicking the Renew domain button to proceed.

 Step 5: After selecting "Renew Domain," a confirmation window will now open where you can review the cost and number of years you choose.

 Step 6: By clicking the Accept button , you can confirm the renewal.

 Your domain will be renewed in a few seconds after you accept the renewal. 🚀

 Previous
 Transfer a Domain to Elestio
 Next
 Change Nameservers