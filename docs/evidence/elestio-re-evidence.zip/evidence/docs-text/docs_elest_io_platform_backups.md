https://docs.elest.io/platform/backups/

Platform Features 

 Backups 

 Backup Solutions - Automated Remote, VM Snapshots & S3 External Backups 
 On this page 

# Backup Solutions - Automated Remote, VM Snapshots & S3 External Backups 

#### A robust backup strategy is fundamental to keeping data safe. ​ 
 info
 By default, Elest.io automates a 3-2-1 backup strategy for all new services.

 3 copies of your data exist at all times.

 2 are kept in geographically distinct data centers in your selected region.

 1 backup is kept on-site for fast restoring.

 Automated remote backups 

 Automated VM Snapshots 

 Local backups 

 External Backups 

 Each backup type has different retention periods and characteristics.

 Previous
 DB Clusters
 Next
 Manual Local Backups