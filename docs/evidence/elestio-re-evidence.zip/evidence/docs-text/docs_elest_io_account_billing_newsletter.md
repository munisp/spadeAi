https://docs.elest.io/account-billing/newsletter

Account & Billing 

 Newsletter 
 On this page 

# Newsletter 
 Product updates, new software, and tips. One to two emails a month, never spam.

 Subscribe during sign-up by checking Sign up for our newsletter , or manage it anytime from your account settings.

## Subscribe ​ 

Open your account settings .

Check the Newsletter box.

Click Submit .

## Unsubscribe ​ 

Open your account settings .

Uncheck the Newsletter box.

Click Submit .

## What you get ​ 

 New features as they ship

 New software added to the catalog

 Tips and best practices for your deployments

 Security updates that matter

 Privacy and frequency
 We never share your email with third parties. Expect one to two emails per month, with one-click unsubscribe in every email.

 Previous
 Projects and Teams
 Next
 Elestio FAQ - Frequently Asked Questions & Troubleshooting

 Subscribe 

 Unsubscribe 

 What you get