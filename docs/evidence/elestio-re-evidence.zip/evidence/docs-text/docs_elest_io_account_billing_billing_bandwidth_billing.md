https://docs.elest.io/account-billing/billing/bandwidth-billing

Account & Billing 

 Billing 

 Bandwidth Billing 
 On this page 

# Bandwidth Billing 
 At Elestio, we're committed to transparency and simplicity when it comes to billing. One area where we often receive questions is bandwidth usage, especially what happens after your allocated free bandwidth is exceeded . This guide walks you through how bandwidth billing works on Elestio, depending on the cloud provider and region you're using.

## Understanding Bandwidth Allocation ​ 
 Every Elestio service comes with a generous amount of free bandwidth included in your service plan. This is usually sufficient for most typical workloads. However, if your usage exceeds this free allocation, additional bandwidth usage will be billed separately based on your cloud provider and region.

## Bandwidth Pricing Breakdown ​ 
 Here's how we calculate bandwidth charges after you exceed the free allocation :

### Hetzner (Except Singapore Region) ​ 

 $0.05 per GB after free bandwidth is used

Affordable and ideal for high-traffic workloads

### DigitalOcean (All Regions) ​ 

 $0.05 per GB after exceeding the free limit

Consistent pricing across all DigitalOcean regions

### Hetzner (Singapore Region) ​ 

 $0.15 per GB after free bandwidth is used

Higher costs due to Hetzner's pricing in Asia-based regions

### All Other Providers ​ 

 $0.15 per GB after the free bandwidth is used

This applies to providers not explicitly listed above

## How to Monitor Your Bandwidth Usage ​ 
 You can track your bandwidth usage easily via the Elestio dashboard:

Log in to your Elestio account

Navigate to your service details

Check the Bandwidth Usage section to view current usage and free limits

## Why the Difference in Pricing? ​ 
 Different cloud providers and regions have different network costs. For example:

Regions like Singapore have higher infrastructure and transit costs

Some providers, like Hetzner (EU) and DigitalOcean, offer more affordable network pricing, which we pass directly to you

 Our goal is to always keep pricing fair, transparent, and aligned with actual costs .

## Questions? ​ 
 If you have any questions about your bandwidth usage or billing, feel free to reach out to support@elest.io 
—we're here to help!

## Related Topics ​ 

 Project Billing - View bandwidth usage in your project billing details

 Billing Overview - Understanding the overall billing system

 Previous
 Per Project Details
 Next
 Legal & Compliance

 Understanding Bandwidth Allocation 

 Bandwidth Pricing Breakdown 
 Hetzner (Except Singapore Region) 

 DigitalOcean (All Regions) 

 Hetzner (Singapore Region) 

 All Other Providers 

 How to Monitor Your Bandwidth Usage 

 Why the Difference in Pricing? 

 Questions? 

 Related Topics