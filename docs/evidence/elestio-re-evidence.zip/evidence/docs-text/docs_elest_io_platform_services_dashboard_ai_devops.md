https://docs.elest.io/platform/services-dashboard/ai-devops

Platform Features 

 Service Dashboard 

 AI DevOps 
 On this page 

# AI DevOps 
 Describe a problem in plain English. AI DevOps analyzes it, connects to your server when a fix is needed, and works on it while you watch every command.

## Launch a session ​ 

Open your service and click AI DevOps at the top of the service overview.

Describe your issue, for example "My site returns a 502 error since this morning" .

Click Launch .

 AI DevOps first analyzes your issue:

If it can answer right away (a configuration tip, a command to run, an explanation), you get the answer directly.

If the fix needs access to your server, it opens a terminal on your service and starts working on it. You can follow every command in real time.

 When it's done, the agent summarizes what it found and what it changed. When you close the session, tell us whether your issue is fixed.

 tip
 You can also use AI DevOps when you open a support ticket: select the affected service and AI DevOps suggests a fix before the ticket is sent.

## Safe by design ​ 

A backup of your server is created automatically before any change.

Every command runs in a terminal you can watch live.

Sessions are time-boxed and expire after 1 hour .

## AI credits ​ 
 AI DevOps is included with your support plan. Each service gets a monthly pool of AI credits:

 Support plan AI credits per service per month 
 Level 1 60 
 Level 2 120 
 Level 3 300 

An answer without server access uses 1 credit .

A full intervention (the agent connects to your server) uses up to 6 credits : 1 for the analysis and 5 for the server access.

Credits reset on the 1st of each month .

 If fewer than 6 credits remain, your last session still runs, including server access, and uses what is left. Your counter stops at 0.

## Extra sessions ​ 
 Once a service has used all its AI credits for the month, you can still launch a session for $1 , debited from the project owner's Elestio balance. Click Launch ($1) to approve it.

If the AI answers without connecting to your server, only $0.10 is charged.

If it connects to your server to fix the issue, the session costs $1 in total.

Nothing is charged if the session fails to start.

Extra sessions appear in your project billing as AI DevOps .

 Only the project owner and project admins can launch an extra session, and the owner's balance must hold at least $1. If it doesn't, add credits to your account, or upgrade your support plan to get more AI credits every month.

 Previous
 Support and Plans
 Next
 Networking and Projects

 Launch a session 

 Safe by design 

 AI credits 

 Extra sessions