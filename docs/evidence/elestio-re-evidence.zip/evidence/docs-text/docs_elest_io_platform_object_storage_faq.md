https://docs.elest.io/platform/object-storage/faq

Platform Features 

 Object Storage 

 FAQ 
 On this page 

# FAQ 

### Is it compatible with Amazon S3? ​ 
 Yes. Any tool or SDK that works with Amazon S3 works with Elestio Object Storage: set the endpoint shown in Quick info and the region auto . See Connect your code .

### Do I pay for downloads? ​ 
 There is no fee for data going out. Each download is a read request, at $0.0005 per 1,000 in every region.

### Can I change the region of a bucket? ​ 
 No. Create a bucket in the new region and copy the files with any S3 tool (for example rclone sync or aws s3 sync ).

### Can I rename a bucket? ​ 
 No. Create a new bucket, copy the files with any S3 tool, then delete the old one.

### Can I restore a deleted bucket? ​ 
 No. Deleting a bucket is final, even with the recycle bin on. Use the recycle bin to protect your files.

### How do I restore a file I replaced by mistake? ​ 
 With the recycle bin on, a deleted file can be restored from Deleted files .

### Can my website upload files directly to a bucket? ​ 
 Yes: create a temporary upload link from your backend with an S3 SDK, and add your website in the CORS settings of the bucket.

### Who can manage a bucket? ​ 
 The owners and admins of the project manage buckets, keys, domains and settings. Read-only members of the project can browse and download files.

 Previous
 Billing and limits
 Next
 Supported Software

 Is it compatible with Amazon S3? 

 Do I pay for downloads? 

 Can I change the region of a bucket? 

 Can I rename a bucket? 

 Can I restore a deleted bucket? 

 How do I restore a file I replaced by mistake? 

 Can my website upload files directly to a bucket? 

 Who can manage a bucket?