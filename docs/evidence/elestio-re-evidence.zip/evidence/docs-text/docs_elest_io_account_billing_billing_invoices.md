https://docs.elest.io/account-billing/billing/invoices

Account & Billing 

 Billing 

 Invoices 
 On this page 

# Invoices 
 You can find you invoices. Easily view, open or download your invoices in one place via your User Profile.

 Navigate to your User Profile via the user icon at the top left of the Dashboard above the Main menu.
Select the Invoices tab

 Invoices are generated when you add credits to your account or when your account auto-refills.

## Related Topics ​ 

 Add Credits - Learn how to add funds that generate invoices

 Payment Options - Configure auto-refill that triggers invoices

 Project Billing - View detailed resource usage per project

 Previous
 Payment Options
 Next
 Free Trial

 Related Topics