https://docs.elest.io/developer-tools/elestio-cli/

Developer Tools 

 Elestio CLI 

 Elestio CLI 
 On this page 

# Elestio CLI 
 Install, authenticate, and use the Elestio CLI and AI agent skill to manage everything you can do in the dashboard.

##### What is the Elestio CLI? ​ 
 The Elestio CLI is the official command-line interface for the Elestio platform, installable as a global npm package:

 npm install -g elestio 

 It exposes every platform capability as a command: deploy services, manage firewall rules, configure SSL certificates, create CI/CD pipelines, handle backups, and monitor billing, all from your terminal without ever opening a browser.

##### Key capabilities ​ 
 Category What you can do 
 Catalog deployment Deploy any of 400+ open-source templates in one command 
 CI/CD Create automated pipelines from GitHub/GitLab repos 
 Service management Power on/off, reboot, resize, lock/unlock services 
 Firewall Add, update, and remove firewall rules 
 SSL & Domains Attach custom domains with auto-provisioned certificates 
 Backups Local, remote, and S3-based backup automation 
 Volumes & Snapshots Create and manage persistent storage (provider-dependent) 
 Billing Query costs per project or per service 

##### What is the Elestio Agent skill? ​ 
 The Elestio Agent Skill is an open-format instruction file that teaches AI coding agents (Claude Code, Cursor, Codex, and OpenCode) how to use the Elestio CLI on your behalf.

 Once installed, your AI agent gains the ability to:

Decide which template to deploy based on your natural language request

Walk you through provider, region, and size selection interactively

Execute the correct CLI commands end-to-end

Verify deployment success and return your service credentials

 The skill follows the Agent Skills open format , making it portable across all supported AI tools.

##### How they work together ​ 
 You (natural language) 
 ↓ 
 AI Agent reads SKILL.md → knows CLI commands, interactive procedures, and provider rules 
 ↓ 
 AI Agent runs: elestio deploy postgresql --project 112 --name my-db 
 ↓ 
 Elestio CLI → calls Elestio REST API → provisions VM on your chosen cloud 
 ↓ 
 Service is live at https://my-db-uxxx.vm.elestio.app 

##### Supported AI Agents ​ 
 Agent Skills Directory 
 Claude Code ~/.claude/skills/elestio/ 
 OpenAI Codex ~/.codex/skills/elestio/ 
 Cursor ~/.cursor/rules/ 
 OpenCode ~/.config/opencode/skills/elestio/ 

##### Quick links ​ 

 Dashboard: https://dash.elest.io 

 Elestio CLI (npm): https://www.npmjs.com/package/elestio 

 Agent Skill (GitHub): https://github.com/elestio/elestio-skill 

 API Docs: https://api-doc.elest.io 

 Templates (400+): https://elest.io/fully-managed-services 

 Previous
 Elestio REST API Documentation - Automate Cloud Deployments
 Next
 Installation and Setup