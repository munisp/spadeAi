https://docs.elest.io/account-billing/billing/free-trial-policy

Account & Billing 

 Billing 

 Elestio Free Trial Policy & Fair Use Statement 
 On this page 

# Elestio Free Trial Policy & Fair Use Statement 
 At Elestio, we're committed to empowering users by providing a fast, reliable and flexible platform for deploying services. As part of this commitment, we offer a 3-day free trial including $20 in credits , allowing new users to try up to 2 services at no cost.

 In addition to the services in our catalog, you have access to load balancers, volumes, and CI/CD pipelines. Domain names are the only thing that cannot be acquired with free credits.

 To ensure the sustainability and security of this program, Elestio enforces certain eligibility requirements which may include identity verification.

## Free Trial Eligibility and Abuse Prevention ​ 
 The Elestio free trial is not a right or entitlement but a voluntary offer made by Elestio for genuine new users looking to evaluate the Elestio platform. We reserve the full right to deny or revoke trial access to any user who does not meet our eligibility criteria or who is found to be using false, misleading, or unverifiable information in cases including, but not limited to:

 Duplicate or Multiple Accounts : Only one free trial is permitted per person.

 False or Misleading Information : Accounts registered using fake names, invalid or throwaway email addresses, or other false details, or using prepaid cards.

 Suspicious Activity : Patterns of behavior indicative of abuse, automation or fraudulent usage.

 Violation of Terms : Any breach of Elestio's Terms of Service or Acceptable Use Policy, such as spamming, malware hosting or other malicious behavior.

## KYC (Know Your Customer) Verification ​ 
 In situations where account information is flagged by our risk management system as warranting further enquiry, Elestio may require identity verification (KYC) before allowing continued access to the platform or approval of a free trial.

 This process may include submitting a government-issued photo ID to confirm the user's identity. If a customer refuses or fails to complete the requested identity verification, we reserve the right to deny free trial access and/or suspend the account .

## Geographic & Abuse-Related Restrictions ​ 
 While Elestio aims to provide fair global access, where our risk assessment systems identify disproportionately high numbers of requests that breach our eligibility criteria or Terms of Service from certain regions and IP ranges, we may temporarily restrict free trial access to accounts from regions or networks. These restrictions are based solely on risk patterns and abuse metrics and are regularly reviewed for accuracy. While unfortunately this can result in increased due diligence checks for legitimate customers from such regions or networks, the precaution is essential to protect all users and maintain platform integrity.

 If you believe your access was wrongly restricted, please reach out to support@elest.io for manual review.

## Final Note: Discretion to Deny Trial Access ​ 
 Elestio retains full discretion to deny or revoke free trial access to any customer.

 The free trial is a goodwill offering intended for evaluation purposes by legitimate users. It is not an entitlement, and its availability is subject to verification, compliance with platform rules and Elestio's discretion.

 Elestio is not responsible for any legal, commercial, operational or reputational consequences of denying trial access.

## We're Here to Help ​ 
 We understand that false positives can occur, and we remain committed to fair access. If your account has been affected and you believe it to be an error, please contact us with your details for review.

 We appreciate your understanding as we work to maintain a secure, abuse-free environment for all developers and teams.

## Related Topics ​ 

 Free Trial - Learn about the 3-day free trial offer

 Payment Options - Configure auto-refill settings

 Add Credits - Add funds to your account

 Previous
 Free Trial
 Next
 SEPA Direct Debit Payment Option

 Free Trial Eligibility and Abuse Prevention 

 KYC (Know Your Customer) Verification 

 Geographic & Abuse-Related Restrictions 

 Final Note: Discretion to Deny Trial Access 

 We're Here to Help 

 Related Topics