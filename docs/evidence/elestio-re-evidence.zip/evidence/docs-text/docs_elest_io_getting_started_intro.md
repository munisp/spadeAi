https://docs.elest.io/getting-started/intro

Getting Started 

 Getting Started 
 On this page 

# Getting Started 
 The fastest path from sign-up to a running service on Elestio.

## Quick start ​ 

 Create your account — Sign in with GitHub, GitLab, Google, or email. MFA is built in.

 Deploy your first service — Pick from 400+ open source apps and go live in under 5 minutes.

 Choose your cloud provider — Hetzner, Netcup, DigitalOcean, AWS, Vultr, Linode, Azure, or your own infrastructure.

 Configure your domain — Add custom domains and SSL certificates.

## Go further ​ 
 Deployment options 

 Bring your own AWS account — Deploy directly into your AWS account.

 Tor integration — Serve a service over a Tor onion address.

 Newsletter — Get product updates and tips.

 Automation 

 REST API — Automate deployments programmatically.

 Terraform provider — Manage infrastructure as code.

 CI/CD pipelines — Ship on every push.

## Need help? ​ 

 FAQ — Common questions and troubleshooting.

 Support — Reach our team from the dashboard.

 Discord community — Join the discussion and get help.

 Ready? Create your account and deploy your first service in minutes.

 Previous
 What is Elestio?
 Next
 Create Account

 Quick start 

 Go further 

 Need help?