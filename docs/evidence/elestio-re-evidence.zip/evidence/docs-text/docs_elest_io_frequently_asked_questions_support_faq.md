https://docs.elest.io/frequently-asked-questions/support-faq

FAQ 

 Support & Account FAQ 
 On this page 

# Support & Account FAQ 
 This section covers frequently asked questions about support plans, account management, and customer service options.

## What type of support does Elestio offer? ​ 
 Email and community support via our forum is available to everyone with our Test plan, with no SLA.

 Staging Support plans offers a guaranteed response within 2 business days and priority queueing for support tickets, and email support.

 Production Support plans offer a guaranteed response within 1 business day, highest priority queueing for support tickets, a dedicated customer success manager, and phone and email support.

 Learn more about our support plans 

 Previous
 Network & Security FAQ
 Next
 Database FAQ

 What type of support does Elestio offer?