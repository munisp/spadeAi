https://docs.elest.io/account-billing/legal-compliance/subcontractors

Account & Billing 

 Legal & Compliance 

 Subcontractors & Sub-processors 
 On this page 

# Subcontractors & Sub-processors 
 A sub-processor is a third-party data processor engaged by Elestio who has or potentially will have access to or process Protected Data. Elestio engages different types of sub-processors to perform various functions as explained below.

## Elestio Infrastructure ​ 
 Entity Purpose 
 Amazon Web Services Elestio management services DNS, Disaster Recover, and Backups. Ireland (Europe)
Elestio management services Elestio Dashboard, Elestio API, Monitoring, Audit Logs. Ireland (Europe) 
 Hetzner Cloud Backups, Monitoring, Audit Logs. Germany (Europe) 
 Cloudflare CDN, WAF 
 Openrouter.ai Used only for the optional "AI DevOps" feature 
 Microsoft Teams Internal operational messaging 
 Microsoft Outlook Email delivery service 
 Google Analytics Customer Analytics 
 PostHog Customer Analytics 
 Stripe Payment processor 

## Customer Data ​ 
 Customer Data will stay in the region selected by the Customer but will be copied for backup purposes in another data center within the same region. Subcontractors don't have logical access to data.

 Entity Purpose 
 Amazon Web Services Infrastructure, Email delivery service 
 Microsoft Azure Customer deployment target 
 Digital Ocean Customer deployment target 
 Hetzner Cloud Customer deployment target 
 Linode Customer deployment target 
 Vultr Customer deployment target 
 Scaleway Customer deployment target 
 NetCup Customer deployment target 
 T Cloud Public Customer deployment target 
 BorgBase Customer backups (encrypted) 
 Tigris Data S3 Buckets 
 MX Route Deployment Email delivery service 

 Previous
 Data Processing Agreement
 Next
 Projects and Teams

 Elestio Infrastructure 

 Customer Data