https://docs.elest.io/platform/cloud-providers/digitalocean

Platform Features 

 Cloud Providers 

 Digital Ocean 
 On this page 

# Digital Ocean 
 Digital Ocean is a great cloud provider with a large number of regions and datacenters available. They provide good network and overall reliability.

## Supported Services ​ 
 Service Supported 
 Compute ✅ High Frequency CPU 
 Private network ✅ 
 Firewall ✅ 
 Volumes ✅ 
 Floating IP ✅ 
 Snapshots ✅ 

## Supported Regions ​ 
 Continent Country City Datacenter 
 Asia Singapore Singapore sgp1 
 Asia India Bangalore blr1 
 Europe Netherlands Amsterdam ams2 
 Europe Netherlands Amsterdam ams3 
 Europe United Kingdom London lon1 
 Europe Germany Frankfurt fra1 
 North America USA New York City nyc1 
 North America USA New York City nyc2 
 North America USA New York City nyc3 
 North America USA San Francisco sfo1 
 North America USA San Francisco sfo2 
 North America USA San Francisco sfo3 
 North America Canada Toronto tor1 

## VM Sizes ​ 
 Size Cores Ram HDD Bandwidth 
 MICRO-1C-1G 1 1GB 25GB NVME 1 TB 
 SMALL-1C-2G 1 2GB 50GB NVME 2 TB 
 MEDIUM-2C-4G 2 4GB 80GB NVME 4 TB 
 LARGE-4C-8G 4 8GB 160GB NVME 5 TB 
 XLARGE-8C-16G 8 16GB 320GB NVME 6 TB 

## Why Choose Digital Ocean? ​ 

 High Frequency CPUs - Excellent performance for CPU-intensive applications

 Global reach - Multiple datacenters across continents

 Developer-friendly - Well-known and trusted by the developer community

 Reliable network - Consistent performance and uptime

 Multiple regions per city - Redundancy options in major cities

 Good bandwidth allocations - Generous transfer limits

## Getting Started ​ 

Select Digital Ocean as your provider in the Elestio dashboard

Choose your preferred region based on your users' location

Pick a VM size - consider the high-frequency CPUs for better performance

Deploy your service with confidence in DO's reliability

 Previous
 Netcup
 Next
 AWS Lightsail

 Supported Services 

 Supported Regions 

 VM Sizes 

 Why Choose Digital Ocean? 

 Getting Started