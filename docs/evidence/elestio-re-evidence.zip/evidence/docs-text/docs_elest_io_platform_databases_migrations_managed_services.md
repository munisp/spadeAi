https://docs.elest.io/platform/databases/migrations/managed-services

Platform Features 

 Databases 

 Migration Services 

 Migrate to Elestio Managed Services 
 On this page 

# Migrate to Elestio Managed Services 
 This migration document focuses on the migration of the applications supported by Elestio. Find the software list here 

 This document provides a step-by-step guide for migrating your existing system to Elestio managed services. Elestio is designed to enhance performance, scalability, and overall system efficiency. Before you begin the migration process, make sure to check the prerequisites.

## Prerequisites ​ 

Make sure the service you are trying to migrate from is being supported by Elestio. You can find the entire software catalogue here 

Create an account on Elestio 

Deploy the service you want to migrate to. Follow the simple steps to deploy your preferred services on Elestio's blogs 

Make sure the UI for the application is working fine and there are no critical errors detected in the application logs. If found otherwise please feel free to create a support ticket

When deploying the service on Elestio, use the same software version as your present service, or your data migration will fail.

## Step 1: Exporting the Data ​ 

Head over to the application you have deployed on the service

There will be either of two options - Migrate or Export

If it's a migration option then most probably it will make use of the API keys so you can keep an eye on the use of the API keys

If it's exported then you will get a file downloaded on your local machine having the config information of the application

Note that you might need to export the mounted data if you are running the service in a Docker container or personal VM.

 Don't forget to add mounted data to /opt/app the directory inside Elestio's file system

## Step 2: Importing the Data ​ 

After your service is deployed on Elestio, you can access the dashboard using the URL, username, and password in the admin credentials. You will also receive an email containing all credentials and the necessary service settings.

Once you log into the application, you can head over to migration or import settings.

If it's the migration then either on the application dashboard or the Elestio dashboard you will be asked to add the application ID, API keys etc. Provide all the keys wait for it to migrate and set your application on Elestio

If it's import then click on the import option and select the exported file from the previous file, wait for some time and you will find it running on Elestio!

If none of the settings are found then you have to manually download the data and upload it to opt/app directory of Elestio instance using File Explorer, VScode, or Filezilla

## Step 3: Testing the Migration ​ 

 You have successfully migrated to Elestio, now it's time for testing if your application is running as you intended

 Make use of integrated tools in Elestio like File Explorer, VScode, or Filezilla to set the additional data and assets

 If you find any issues with the migration, try to restart your instance and restart containers using the following commands

 docker-compose down; 

 docker-compose up -d --build 

 Checkout logs if something is failing. Note that there can be a version lapse between your currently hosted application and the running instance on Elestio (Latest version) as mentioned in the Prerequisites section

## Need Additional Help? ​ 
 Stuck somewhere? We are here to help you, go ahead and create a support ticket and we will get back to you in no time.

## Related Guides ​ 

 Custom Applications Migration - For unsupported services

 Database Migration - Database-specific migration guides

 Best Practices - Tips and troubleshooting

 Previous
 Database Migration Guides
 Next
 Migrate Your Custom Application to Elestio

 Prerequisites 

 Step 1: Exporting the Data 

 Step 2: Importing the Data 

 Step 3: Testing the Migration 

 Need Additional Help? 

 Related Guides