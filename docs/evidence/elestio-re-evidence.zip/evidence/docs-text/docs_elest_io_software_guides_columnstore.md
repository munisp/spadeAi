https://docs.elest.io/software-guides/columnstore

Software Guides 

 ColumnStore Database Migration to Elestio 
 On this page 

# ColumnStore Database Migration to Elestio 
 Elestio provides a robust and user-friendly platform for managing your database migrations seamlessly. Whether you are migrating from an on-premises ColumnStore database or from another cloud provider, Elestio's migration tool simplifies the process. By following a few straightforward steps, you can securely and efficiently move your ColumnStore databases to Elestio, ensuring minimal downtime and disruption to your operations.

 This guide will walk you through the process of migrating your ColumnStore database from an external source to Elestio. We will cover everything from configuring your migration settings, validating the connection to your source database, and finally starting the migration process while monitoring its progress.

## Step 1 - Configure ​ 

Go to the overview of your ColumnStore service on Elestio. 

Click on the Migrate Database button.

A modal window will open, ensure that your target service has enough disk space to accommodate your database

Click on Get started button**.**

## Step 2 - Validation ​ 

You need to provide the connection details to establish a connection to your source database, enter the required details: 

 Hostname 

 Port 

 Database name 

 Username 

 Password 

Click on Run Check to validate the connection.

## Step 3 - Migration ​ 

 If all checks pass with no errors, you can trigger the migration by selecting Start migration .

 Once the migration starts, you can monitor the progress through the migration logs displayed in real-time.

 Previous
 ClickHouse Cluster Management
 Next
 Hydra

 Step 1 - Configure 

 Step 2 - Validation 

 Step 3 - Migration