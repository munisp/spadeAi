https://docs.elest.io/developer-tools/elestio-cli/installation

Developer Tools 

 Elestio CLI 

 Installation and Setup 
 On this page 

# Installation and Setup 
 Install the Elestio CLI, authenticate with an API token, and set a default project.

#### Requirements ​ 

 Node.js >= 18 (check with node --version )

An active Elestio account with a verified email, payment method, and API token

 Git (required only for the Agent Skill installer)

##### Step 1 – Create an Elestio account (manual) ​ 
 *] :pointer-events-auto scroll-mt-[calc(var(--header-height)+min(200px,max(70px,20svh)))]" dir="auto" tabindex="-1">You need to do these steps yourself, manually, using a web browser. They cannot be done automatically or through the command line (CLI).

Sign up at Dashboard 

Verify your email address

Add a credit card at https://dash.elest.io/account/payment-options 

Wait for account approval (usually instant; can take up to 30 minutes to 48 hours for new accounts)

##### Step 2 – Generate an API token ​ 

Go to https://dash.elest.io/account/security 

Click Manage API Tokens → Create Token 

Copy the token value (it is shown only once)

##### Step 3 – Install the Elestio CLI ​ 
 npm install -g elestio 

 Verify the installation:

 elestio --version 

##### Step 4 – Configure credentials ​ 
 elestio login --email "you@example.com" --token "your_api_token" 

 Test that authentication works:

 elestio auth test 
 # Expected: [SUCCESS] Authenticated as you@example.com 

##### Step 5 – (Optional) Set a default project ​ 
 Avoid passing --project on every command by setting a default:

 # List your projects to find the ID 
 elestio projects 

 # Set the default 
 elestio config --set-default-project 112 

#### Installing the Agent Skill ​ 

##### Automatic (recommended) ​ 
 curl -fsSL https://raw.githubusercontent.com/elestio/elestio-skill/main/scripts/install.sh | bash 

 The installer will:

Detect which AI tools you have installed (Claude Code, Codex, Cursor, OpenCode)

Install the Elestio CLI globally via npm

Copy SKILL.md to each detected agent's skills directory

##### Via skills.sh ​ 
 npx skills add elestio/elestio-skill 

##### Manual installation ​ 
 # 1. Install the CLI 
 npm install -g elestio 

 # 2. Clone the skill repo 
 git clone https://github.com/elestio/elestio-skill.git /tmp/elestio-skill 

 # 3. Copy SKILL.md to your agent 
 # Claude Code 
 mkdir -p ~/.claude/skills/elestio 
 cp /tmp/elestio-skill/SKILL.md ~/.claude/skills/elestio/ 

 # Cursor 
 mkdir -p ~/.cursor/rules 
 cp /tmp/elestio-skill/SKILL.md ~/.cursor/rules/elestio.md 

##### Update the skill ​ 
 Re-run the installer at any time to get the latest version:

 curl -fsSL https://raw.githubusercontent.com/elestio/elestio-skill/main/scripts/install.sh | bash 

##### Verify everything is working ​ 
 # Authentication 
 elestio auth test 

 # List your projects 
 elestio projects 

 # Browse the template catalog (no auth required) 
 elestio templates search postgresql 

 Previous
 Elestio CLI
 Next
 Command Reference