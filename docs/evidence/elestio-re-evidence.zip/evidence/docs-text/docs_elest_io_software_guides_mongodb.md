https://docs.elest.io/software-guides/mongodb

Software Guides 

 MongoDB Database Migration to Elestio 
 On this page 

# MongoDB Database Migration to Elestio 
 Elestio provides a robust and user-friendly platform for managing your database migrations seamlessly. Whether you are migrating from an on-premises MongoDB database or from another cloud provider, Elestio's migration tool simplifies the process. By following a few straightforward steps, you can securely and efficiently move your MongoDB databases to Elestio, ensuring minimal downtime and disruption to your operations.

 This guide will walk you through the process of migrating your MongoDB database from an external source to Elestio. We will cover everything from configuring your migration settings, validating the connection to your source database, and finally starting the migration process while monitoring its progress.

## Step 1 - Configure ​ 

Go to the overview of your MongoDB service on Elestio. 

Click on the Migrate Database button.

A modal window will open, ensure that your target service has enough disk space to accommodate your database

Click on Get started button**.**

## Step 2 - Validation ​ 

You need to provide the connection details to establish a connection to your source database, enter the required details: 

 Hostname 

 Port 

 Username 

 Password 

Click on Run Check to validate the connection.

## Step 3 - Migration ​ 

 If all checks pass with no errors, you can trigger the migration by selecting Start migration .

 Once the migration starts, you can monitor the progress through the migration logs displayed in real-time.

 Previous
 MariaDB Database Migration to Elestio
 Next
 MySQL

 Step 1 - Configure 

 Step 2 - Validation 

 Step 3 - Migration