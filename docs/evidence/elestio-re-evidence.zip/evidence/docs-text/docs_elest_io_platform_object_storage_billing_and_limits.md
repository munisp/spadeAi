https://docs.elest.io/platform/object-storage/billing-and-limits

Platform Features 

 Object Storage 

 Billing and limits 
 On this page 

# Billing and limits 

## How it is billed ​ 
 Object Storage is billed on real usage , every day, from your Elestio credits. Each project has one Object Storage line per month on the Billing page. There is nothing free: every GB stored and every request is billed.

## Prices ​ 
 Single region or Global Multi-region 
 Storage (per GB per month) $0.02 $0.025 
 Writes and lists: PUT, COPY, POST, LIST (per 1,000) $0.005 $0.01 
 Reads: GET and others (per 1,000) $0.0005 $0.0005 
 Deletions Free Free 
 Notifications (per 1,000 events) $0.01 $0.01 
 Data transfer out Free Free 

 The price depends on the region of the bucket: Global and the single cities, or Multi-region Europe and US.

 info
 Files in the recycle bin are billed like stored files. Downloads of a public bucket are read requests billed to you.

## Follow your consumption ​ 
 Owners and admins of a project see what its Object Storage costs, line by line, at the price billed.

 Object Storage page, Consumption tab : for the current month, the amount so far and an estimate of the whole month (the storage of your buckets at their size today until the end of the month, plus the requests at their daily pace so far); for a past month, its total. Then the four main figures (writes and lists, reads, storage, data out) and every line of the month (type, usage, amount). Use the arrows or the calendar to see another month. The Cost in tile of the Buckets tab shows the amount so far and the estimate of the month at a glance; click Details to open the tab.

 Billing page : each Object Storage line has a Details link that opens the Consumption tab on that month.

 Inside a bucket, Consumption tab : the size and number of objects of the bucket, read live from the storage, and what its storage costs per month at its current size (its size times the storage price of its region). It is an estimate: the real cost of the month, which follows the size day by day, is in the Consumption tab of the project.

 Requests and data transfer are measured for the whole project, not per bucket. The provider publishes them per day once the day is over, so today's requests appear tomorrow; the tab says up to which day the figures go. Files in the recycle bin and old versions kept by snapshots are part of the size: they are stored and billed.

## Limits ​ 

 10 buckets and 20 API keys per project.

 Storage : 100 GB per project during the free trial, 1 TB once you are a paying customer.

 You receive an email when a project reaches 80% of its storage quota. At 100%, uploads are blocked; reading and deleting files still work.

 To get more, click Request more on the Object Storage page. Only the project owner can ask.

## When the credit is exhausted ​ 

The Object Storage of the project is suspended : files are kept but cannot be read, and public buckets become private.

You receive reminders by email before the deletion date.

If the credit is not topped up in time, the buckets and their files are deleted: 3 days after the suspension during the free trial, 14 days for paying customers.

 As soon as you top up your credit, the Object Storage comes back within a few minutes and you receive an email. Public read stays off: turn it on again from the bucket settings if you need it.

## Deleting a project or an account ​ 
 The buckets of a project are deleted with the project, and the buckets of an account with the account. This is final.

 Previous
 Infinidisk
 Next
 FAQ

 How it is billed 

 Prices 

 Follow your consumption 

 Limits 

 When the credit is exhausted 

 Deleting a project or an account