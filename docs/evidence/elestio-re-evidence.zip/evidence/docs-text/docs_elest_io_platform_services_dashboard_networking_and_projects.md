https://docs.elest.io/platform/services-dashboard/networking-and-projects

Platform Features 

 Service Dashboard 

 Networking and Projects 
 On this page 

# Networking and Projects 
 Keep an eye on bandwidth and organize services across projects.

## Bandwidth and networks ​ 
 The Overview tab shows a recap of your bandwidth usage for the current month.

 info
 Bandwidth usage includes both inbound and outbound traffic.

## Move a service to another project ​ 

In the Overview tab, select Move Service .

Click Move to confirm.

 info
 You can only move services to projects you own.

 Previous
 AI DevOps
 Next
 Storage

 Bandwidth and networks 

 Move a service to another project