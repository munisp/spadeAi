https://docs.elest.io/developer-tools/elestio-cli/agent-skill

Developer Tools 

 Elestio CLI 

 Using the CLI as an AI Agent Skill 
 On this page 

# Using the CLI as an AI Agent Skill 
 Give AI agents (Claude Code, Cursor) the Elestio skill so they can deploy and manage services for you.

##### How it works ​ 
 The Elestio Agent Skill is a SKILL.md file placed in your AI agent's skills directory. When you ask your agent to deploy or manage infrastructure, it reads SKILL.md to understand:

Which CLI commands to run

The correct interactive deployment procedure (what to ask you before deploying)

Provider capabilities and limitations

Error-handling strategies

 The agent then runs the appropriate elestio commands on your behalf.

##### Trigger phrases ​ 
 Your agent will activate the Elestio skill when you say things like

 What you say What the agent does 
 "Deploy PostgreSQL" elestio deploy postgresql with guided setup 
 "I need a Redis cache" elestio deploy redis with guided setup 
 "Set up n8n for automation" elestio deploy n8n with guided setup 
 "Deploy my app from GitHub" Automated CI/CD pipeline workflow 
 "What services are running?" elestio services 
 "How much is this costing?" elestio billing 
 "Reboot my PostgreSQL server" elestio reboot 
 "Add a firewall rule for port 8080" elestio firewall update 

##### The Interactive Deployment Procedure ​ 
 The skill mandates that the agent ask you for each deployment parameter individually. It will never deploy with default values without your confirmation.

###### Parameters asked (in order): ​ 
 1. Cloud Provider 

 Netcup, Hetzner, AWS, Azure, GCP, DigitalOcean, Vultr, Scaleway, and Linode.

 info
 Recommended: Netcup, Hetzner, AWS, and Azure.

 2. Region (based on provider chosen) 

Netcup: nbg (Europe – Germany) | mns (North America – US)

Hetzner: fsn1 , nbg1 , hel1 (EU), ash (US)

AWS: us-east-1 , eu-west-1 , etc.

 3. Service Plan / Size 

 Starts at $14/month in the EU ($16 in the US) for a dedicated VM with 2 CPUs, 4 GB RAM, and 60 GB NVMe storage on Netcup.

 You can check more here: https://elest.io/pricing#pricing 

 4. Service Name 

 The agent suggests a default (e.g., "prod-postgresql") and waits for your text input.

 5. Admin Email 

 The agent proposes your email and lets you confirm or change it.

###### Example conversation ​ 
 You: "Deploy PostgreSQL" 
 Agent: Which cloud provider? (Netcup recommended for value, Hetzner for features) 
 You: "Netcup" 
 Agent: Which region? (nbg = Europe Germany, mns = North America US) 
 You: "nbg" 
 Agent: Which plan? SMALL ~$7/mo · MEDIUM ~$14/mo · LARGE ~$28/mo · XL ~$55/mo 
 You: "MEDIUM" 
 Agent: What name for this service? Suggestion: prod-postgresql 
 You: "demo-postgres" 
 Agent: Admin email? Suggestion: you@company.com 
 You: "Confirmed" 
 Agent: [runs elestio deploy postgresql --project 112 --name demo-postgres ...] 
 Agent: ✓ Service deployed! Credentials: ... 

##### What the agent CANNOT do for you ​ 
 The skill explicitly prohibits the agent from performing these steps (you must do them in a browser):

Creating an Elestio account (signup)

Adding a payment method

Waiting for account approval

###### After deployment: what the agent will do next ​ 
 Once a service is deployed, the agent follows this sequence automatically:

 Get credentials: elestio credentials 

 Enable auto-backups: elestio backups auto-enable 

 Add custom domain (if requested): elestio ssl add myapp.example.com 

 Configure firewall (if requested): elestio firewall enable --rules [...] 

 Enable auto-updates: elestio updates system-enable --security-only 

##### Supported agents & skill locations ​ 
 Agent Skill file location 
 Claude Code ~/.claude/skills/elestio/SKILL.md 
 OpenAI Codex ~/.codex/skills/elestio/SKILL.md 
 Cursor ~/.cursor/rules/elestio.md 
 OpenCode ~/.config/opencode/skills/elestio/SKILL.md 

 After installing or updating the skill, restart your agent tool to load the new instructions.

##### Version & source ​ 

 Skill version: 2.0

 GitHub: https://github.com/elestio/elestio-skill 

 Specification: https://agentskills.io/specification 

 Previous
 Command Reference
 Next
 Deploying Services