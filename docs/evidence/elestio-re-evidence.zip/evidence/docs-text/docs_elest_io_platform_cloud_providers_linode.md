https://docs.elest.io/platform/cloud-providers/linode

Platform Features 

 Cloud Providers 

 Linode 
 On this page 

# Linode 
 Linode is a great cloud provider with a large number of regions and datacenters available. They provide good network and overall reliability.

## Supported Services ​ 
 Service Supported 
 Compute ✅ 
 Private network ✅ 
 Firewall ✅ 
 Volumes ✅ 
 Floating IP ✅ 
 Snapshots ❌ 

## Supported Regions ​ 
 Continent Country City Datacenter 
 Asia India Mumbai ap-west 
 Asia Australia Sydney ap-southeast 
 Asia Singapore Singapore ap-south 
 Asia Japan Tokyo ap-northeast 
 Europe United Kingdom London eu-west 
 Europe Germany Frankfurt eu-central 
 North America Canada Toronto ca-central 
 North America USA Dallas us-central 
 North America USA Fremont us-west 
 North America USA Atlanta us-southeast 
 North America USA Newark us-east 

## VM Sizes ​ 
 Size Cores Ram HDD Bandwidth 
 MICRO-1C-1G 1 1GB 25GB SSD 1 TB 
 SMALL-1C-2G 1 2GB 50GB SSD 2 TB 
 MEDIUM-2C-4G 2 4GB 80GB SSD 4 TB 
 LARGE-4C-8G 4 8GB 160GB SSD 5 TB 
 XLARGE-6C-16G 6 16GB 320GB SSD 8 TB 
 2XLARGE-8C-32G 8 32GB 640GB SSD 16 TB 
 3XLARGE-16C-64G 16 64GB 1280GB SSD 20 TB 
 4XLARGE-24C-128G 24 128GB 2560GB SSD 20 TB 

## Why Choose Linode? ​ 

 Competitive pricing - Good value for money across all sizes

 Generous bandwidth - High transfer limits, especially on larger instances

 SSD storage - Fast and reliable solid-state drives

 Global presence - Strategic locations worldwide

 Established provider - Long-standing reputation in the industry

 Large storage options - Up to 2.5TB SSD on the largest instances

## Important Limitations ​ 

 No snapshots - VM snapshots are not supported on Linode

 Backup alternatives - Use file-level backups or external solutions

## Getting Started ​ 

Select Linode as your provider in the Elestio dashboard

Choose your preferred region based on your users' location

Pick a VM size - note the generous bandwidth allocations

Plan for alternative backup strategies since snapshots aren't available

 Previous
 Vultr
 Next
 Scaleway

 Supported Services 

 Supported Regions 

 VM Sizes 

 Why Choose Linode? 

 Important Limitations 

 Getting Started