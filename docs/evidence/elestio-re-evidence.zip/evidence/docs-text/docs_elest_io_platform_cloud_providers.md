https://docs.elest.io/platform/cloud-providers

Platform Features 

 Cloud Providers 

 Cloud Providers 
 On this page 

# Cloud Providers 
 Elestio supports deployment across multiple cloud providers, giving you the flexibility to choose the best infrastructure for your needs. Each provider offers different advantages in terms of pricing, performance, and geographic availability.

## Quick Navigation ​ 
 Choose your preferred cloud provider:

### Managed Cloud Providers ​ 
 Provider Best For Key Features 
 Hetzner Cost-conscious users Excellent price-performance, 20TB bandwidth, renewable energy 
 Digital Ocean Developers High frequency CPUs, developer-friendly, global reach 
 AWS Lightsail AWS ecosystem users AWS integration, enterprise reliability 
 Vultr High performance needs High frequency CPUs, extensive global network 
 Linode Budget-conscious users Competitive pricing, generous bandwidth 
 Scaleway European data, GPU and ARM workloads Paris, Amsterdam and Warsaw, disk from 10 GB to 10 TB, NVIDIA GPUs 

### Bring Your Own Infrastructure ​ 
 Option Best For Key Features 
 BYOVM (Any Provider) Flexibility & control Use any provider, first VM free, on-premise support 
 AWS EC2 (BYOAWS) Enterprise AWS users Direct AWS billing, full EC2 features, reserved instances 

## Provider Comparison ​ 
 Provider Pricing Performance Global Reach Special Features 
 Hetzner ⭐⭐⭐⭐⭐ ⭐⭐⭐⭐⭐ ⭐⭐⭐ 20TB bandwidth included, renewable energy 
 Digital Ocean ⭐⭐⭐⭐ ⭐⭐⭐⭐ ⭐⭐⭐⭐ High frequency CPU, developer-friendly 
 AWS Lightsail ⭐⭐⭐ ⭐⭐⭐⭐ ⭐⭐⭐⭐⭐ AWS ecosystem integration 
 Vultr ⭐⭐⭐⭐ ⭐⭐⭐⭐⭐ ⭐⭐⭐⭐ High frequency CPU, diverse locations 
 Linode ⭐⭐⭐⭐ ⭐⭐⭐⭐ ⭐⭐⭐ Competitive pricing, good performance 
 Scaleway ⭐⭐⭐ ⭐⭐⭐⭐ ⭐⭐ EU datacenters, resizable disk, ARM and GPU sizes 
 BYOVM Variable Variable ⭐⭐⭐⭐⭐ Use any provider, first VM free 
 AWS EC2 Variable ⭐⭐⭐⭐⭐ ⭐⭐⭐⭐⭐ Full AWS feature set, enterprise features 

## Choosing the Right Provider ​ 

### For Beginners ​ 

 Hetzner - Best value for money with excellent performance

 Digital Ocean - Developer-friendly with good documentation

### For Cost Optimization ​ 

 Hetzner - Exceptional price-performance ratio

 BYOVM - Use existing credits or negotiate better rates

### For Enterprise ​ 

 AWS EC2 (BYOAWS) - Full enterprise features and compliance

 AWS Lightsail - Simplified AWS with enterprise backing

### For Performance ​ 

 Vultr - High frequency CPUs and global network

 Digital Ocean - High frequency CPUs with good global reach

### For Flexibility ​ 

 BYOVM - Use any cloud provider or on-premise infrastructure

 AWS EC2 - Access to full AWS ecosystem

## Getting Started ​ 

 Choose your provider based on your requirements above

 Select a region closest to your users for optimal performance

 Pick a VM size appropriate for your application needs

 Deploy your service through the Elestio dashboard

 For detailed information about each provider including supported regions, VM sizes, pricing, and setup instructions, click on any provider link above.

## Need Help Choosing? ​ 
 If you're unsure which provider to choose, consider these questions:

 Where are your users located? Choose a provider with nearby regions

 What's your budget? Hetzner offers the best value, while BYOVM can leverage existing credits

 Do you need enterprise features? AWS options provide the most enterprise capabilities

 Is performance critical? Vultr and Digital Ocean offer high-frequency CPUs

 Do you want maximum flexibility? BYOVM lets you use any infrastructure

 Still not sure? Start with Hetzner for the best balance of price, performance, and reliability.

 Previous
 Deploy Service
 Next
 Hetzner

 Quick Navigation 
 Managed Cloud Providers 

 Bring Your Own Infrastructure 

 Provider Comparison 

 Choosing the Right Provider 
 For Beginners 

 For Cost Optimization 

 For Enterprise 

 For Performance 

 For Flexibility 

 Getting Started 

 Need Help Choosing?