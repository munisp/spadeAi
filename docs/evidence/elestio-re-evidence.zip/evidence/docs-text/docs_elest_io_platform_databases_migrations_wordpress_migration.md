https://docs.elest.io/platform/databases/migrations/wordpress-migration

Platform Features 

 Databases 

 Migration Services 

 Migrate WordPress to Elestio 
 On this page 

# Migrate WordPress to Elestio 
 This migration document focuses on the migration of WordPress sites to Elestio. WordPress is one of our fully supported services. Find the complete software list here 

 This document provides a step-by-step guide for migrating your existing WordPress site to Elestio. Elestio is designed to enhance performance, scalability, and overall system efficiency. Before you begin the migration process, make sure to check the prerequisites.

## Prerequisites ​ 

Create an account on Elestio 

Log in to your WordPress account where your current site/pages are hosted

Make sure the UI for the application is working fine and there are no critical errors detected in the application logs. If found otherwise please feel free to create a support ticket

When deploying the service on Elestio, use the same software version as your present service, or your data migration will fail.

## Step 1: Exporting the Data ​ 
 There are two primary ways to export your data from WordPress, we will focus on the native one but you can consider using plugins like WPvivid to carry out the migration.

Here we are going to migrate a simple kangaroo site with 2 pages as you can see in the image below

Head over to the dashboard of your WordPress go to the "Tools" option in the left panel and select the "Export" option

Click on "Download Export Files" as shown in the image above, here we are exporting all content but you can choose to export selectively if you want.

The exported file will be saved on your local machine. The exported file will be in XML format.

You can additionally make a copy of this exported data and store it as a backup on local disks. This is totally optional step if you want additional backup than what WordPress natively offers.

## Step 2: Setup Elestio ​ 

Head over to the Elestio Dashboard and search for WordPress service

Select the service and head over to the service provider, region and service plan. If you have no preferences, simply hit the next

Name the service as you want and click "Create Service"

Head over to this service, and head over to the link provided under the Admin UI button

Create your site with the details provided here and log in to the WordPress instance. You will see a similar dashboard below

## Step 3: Importing the Data ​ 

Head over to the new instance of WordPress head over to "Tools" and click on the "Import" option.

Click on "Install Now" for WordPress as shown in the image above.

Run importer after getting installed

Choose the XML file you exported from the previous step. and click on "Upload file and Import"

Fill out the author information and click on "Submit"

Voila! It's imported and your site is migrated safely. You can check if it's working from the options above.

## Step 4: Testing the Migration ​ 

Go to the top left of the screen where you can see the site name, in this case, "Migrate to this". Upon clicking on the name, you should see the site as it was before the migration.

Enjoy your newly migrated WordPress site on Elestio!

## Need Additional Help? ​ 
 Stuck somewhere? We are here to help you, go ahead and create a support ticket and we will get back to you in no time.

## Related Guides ​ 

 Managed Services Migration - General guide for supported services

 Database Migration - Database-specific migration guides

 Best Practices - Tips and troubleshooting

 Previous
 Migrate Your Custom Application to Elestio
 Next
 Migrate Jenkins Pipeline to Elestio

 Prerequisites 

 Step 1: Exporting the Data 

 Step 2: Setup Elestio 

 Step 3: Importing the Data 

 Step 4: Testing the Migration 

 Need Additional Help? 

 Related Guides