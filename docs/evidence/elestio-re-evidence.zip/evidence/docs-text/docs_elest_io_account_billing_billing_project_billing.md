https://docs.elest.io/account-billing/billing/project-billing

Account & Billing 

 Billing 

 Per Project Details 
 On this page 

# Per Project Details 
 To view a project's billing details, select Billing from the left menu, where you'll find a recap and details of all billable items.

## Related Topics ​ 

 Billing Overview - Understanding the overall billing system

 Bandwidth Billing - Understanding bandwidth costs per project

 Invoices - View credit additions separate from project usage

 Previous
 SEPA Direct Debit Payment Option
 Next
 Bandwidth Billing

 Related Topics