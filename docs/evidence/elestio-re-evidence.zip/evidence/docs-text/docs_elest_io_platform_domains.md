https://docs.elest.io/platform/domains/

Platform Features 

 Domains 

 Domains 
 On this page 

# Domains 
 Register, transfer, renew, and manage domains directly from your Elestio dashboard.

## What you can do ​ 

 Buy a domain — Register a new domain from Elestio.

 Transfer a domain in — Move a domain from GoDaddy or another registrar.

 Renew a domain — Extend your domain for up to 10 years.

 Change nameservers — Point your domain at Elestio DNS or your own.

 Lock or unlock a domain — Protect against unauthorized transfers.

 Previous
 PTR Record
 Next
 Buy a Domain

 What you can do