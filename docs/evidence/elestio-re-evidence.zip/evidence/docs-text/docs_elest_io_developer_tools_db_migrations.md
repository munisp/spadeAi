https://docs.elest.io/developer-tools/db-migrations/

Developer Tools 

 Database Migrations 

 DB Migrations 
 On this page 

# Database Migrations 
 Need help migrating to Elestio? This section provides comprehensive guides for migrating databases and applications to the Elestio platform.

## Migration Categories ​ 

### 📦 Managed Services ​ 
 For applications supported by Elestio's fully managed services:

 General Migration Guide - Step-by-step process for migrating supported applications

 WordPress Migration - Complete WordPress site migration

 MySQL Migration - Database migration with phpMyAdmin

 Jenkins Migration - CI/CD pipeline migration

 Superset Migration - Business intelligence dashboard migration

 Mastodon Migration - Social media server migration

### 🛠️ Custom Applications ​ 
 For applications not directly supported as managed services:

 Custom Applications - Git repositories, Docker containers, and manual migration

 Best Practices - Essential migration tips and guidelines

## Quick Start ​ 

 Check Compatibility : Verify your application is supported by Elestio 

 Create Account : Set up your Elestio account 

 Choose Guide : Select the appropriate migration guide for your use case

 Follow Steps : Complete the migration following our detailed instructions

## Before You Begin ​ 

 Create Backups : Always backup your data before starting migration

 Plan Downtime : Schedule migration during low-traffic periods

 Test First : Use a staging environment to test the migration process

 Version Matching : Use the same software versions to avoid compatibility issues

## Need Help? ​ 
 If you encounter any issues during migration:

 Review Best Practices : Check our migration best practices 

 Search Documentation : Look for solutions in our comprehensive guides

 Contact Support : Create a support ticket for personalized assistance

 View all migration guides → 

 Previous
 Deploy a CI/CD Pipeline via GitLab Self-Hosted
 Next
 Managed Services Migration

 Migration Categories 
 📦 Managed Services 

 🛠️ Custom Applications 

 Quick Start 

 Before You Begin 

 Need Help?