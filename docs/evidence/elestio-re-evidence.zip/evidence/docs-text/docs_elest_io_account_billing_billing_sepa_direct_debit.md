https://docs.elest.io/account-billing/billing/sepa-direct-debit

Account & Billing 

 Billing 

 SEPA Direct Debit Payment Option 
 On this page 

# SEPA Direct Debit Payment Option 
 At Elestio, we aim to make payment processing as convenient and accessible as possible for our customers. We're pleased to offer SEPA Direct Debit as a payment option, available to our eligible European customers. This method ensures a secure, easy, and efficient way to manage payments directly from your bank account, adhering to European Union standards.

## Eligibility Criteria for SEPA Direct Debit ​ 
 To maintain secure and streamlined transactions, SEPA Direct Debit is available under the following eligibility criteria:

### Available for European Customers Only ​ 
 The SEPA Direct Debit option is exclusively available for customers within the Single Euro Payments Area (SEPA). This area covers all EU countries and a few additional European territories.

### Minimum Hourly Spending Rate ​ 
 Eligible customers must maintain an hourly spending rate of at least $0.15. This spending rate is calculated based on your active services and ensures that SEPA Direct Debit aligns with recurring payments for ongoing services.

### Account Age Requirement ​ 
 Customers must have been with Elestio for at least one month to qualify for SEPA Direct Debit. This requirement is in place to establish a consistent and reliable payment history, providing a seamless experience for both you and our billing system.

## Setting Up SEPA Direct Debit ​ 
 If you meet the eligibility criteria and are interested in setting up SEPA Direct Debit, you can do it in the Add Credits tab. Once enabled, SEPA will be your new secure and convenient method for managing payments on Elestio.

## Related Topics ​ 

 Add Credits - Where to configure SEPA Direct Debit

 Payment Options - Alternative payment methods

 Project Billing - Understanding your spending rate

 Previous
 Elestio Free Trial Policy & Fair Use Statement
 Next
 Per Project Details

 Eligibility Criteria for SEPA Direct Debit 
 Available for European Customers Only 

 Minimum Hourly Spending Rate 

 Account Age Requirement 

 Setting Up SEPA Direct Debit 

 Related Topics