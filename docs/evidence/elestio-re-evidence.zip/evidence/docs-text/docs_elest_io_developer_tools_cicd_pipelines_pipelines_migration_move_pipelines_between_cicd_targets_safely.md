https://docs.elest.io/developer-tools/cicd-pipelines/pipelines-migration-move-pipelines-between-cicd-targets-safely

Developer Tools 

 CI/CD Pipelines 

 Configuration & Management 

 Pipelines migration, move pipelines between CI/CD targets safely 
 On this page 

# Pipelines migration, move pipelines between CI/CD targets safely In several situations, you might want to move a deployed CI/CD pipeline from one target to another one. On Elestio, you can safely move a pipeline between targets even if the pipeline contains data.
Let's consider a few situations:

Your CI/CD target is overloaded (too much CPU/RAM usage)

You want to move a workload from one location to another

Your CI/CD target is down
In all those situations you will want to move some or all of your pipelines to another CI/CD target (new or existing one).

##### Move a CI/CD Pipeline to another CI/CD Target ​ 

From the Elestio dashboard, click on CI/CD in the left menu then click on your pipeline to open the overview.

Click on the Move Pipeline button

From there you can indicate if you want to move your pipeline to new infrastructure or existing infrastructure.
If you select Existing infrastructure you have to select in the list the existing CI/CD target, for a new infrastructure you will have to indicate the Provider / Region / VM Size to create.

Moving a pipeline to an existing CI/CD target is FREE.
When you move a pipeline we are automating those operations:

Do a fresh backup of your data on S3 (Backups must be activated before moving your pipeline)

Shutting down the app stack of the pipeline.

(New infrastructure only): Deploying a new VM that will be used as the new CI/CD target

Deploy the pipeline (from source or from docker registry) on the new target

Restore the latest backup we took at step one from S3

Check if the pipeline is running correctly on the new target, if not cancel the operation and send a warning email

Change the DNS entry to point to the new target IP address

Send a confirmation email when the pipeline is restored and ready
The whole process usually takes less than 3 minutes, but it can last longer if there is a lot of data to back up/restore.

 Previous
 Clone CI/CD pipeline
 Next
 Enable or Disable Webhook Triggers