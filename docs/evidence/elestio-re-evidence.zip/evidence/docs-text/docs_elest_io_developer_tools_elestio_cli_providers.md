https://docs.elest.io/developer-tools/elestio-cli/providers

Developer Tools 

 Elestio CLI 

 Cloud Provider Guide 
 On this page 

# Cloud Provider Guide 
 Browse providers, regions, and sizes available through the Elestio CLI.

##### Elestio supports 9 cloud providers across 100+ regions. Each provider has different features, pricing, and capabilities. ​ 

##### Provider Comparison ​ 
 Feature Netcup Hetzner AWS Azure Scaleway Vultr Linode DO 
 Catalog deploy ✓ ✓ ✓ ✓ ✓ ✓ ✓ ✓ 
 CI/CD deploy ✓ ✓ ✓ ✓ ✓ ✓ ✓ ✓ 
 Volumes ✗ ✓ ✓ ✓ ✓ ✓ ✓ ✓ 
 Snapshots ✗ ✓ ✓ ✓ ✓ ✓ ✓ ✓ 
 Size downgrade ✓ Only If last upgraded without disk ✓ ✓ ✓ — — — 
 Firewall ✓ ✓ ✓ ✓ ✓ ✓ ✓ ✓ 
 SSL/Domains ✓ ✓ ✓ ✓ ✓ ✓ ✓ ✓ 

##### Choosing a Provider ​ 

###### Use Netcup when: ​ 

You want the best price/performance ratio 

You don't need block volumes or full snapshots

You may need to downgrade your instance size later

EU-based (Germany) is acceptable

###### Use Hetzner when: ​ 

You need block volumes for persistent storage

You need reliable snapshots and power management

You want a strong EU-based infrastructure (Germany, Finland)

Note: Hetzner does not support size downgrades

###### Use AWS when: ​ 

You need global reach (many regions worldwide)

You need size-downgrade flexibility

You're already in the AWS ecosystem

###### Use Azure when: ​ 

You need Microsoft cloud infrastructure

You need size-downgrade flexibility

You need specific Azure regions (e.g., germanywestcentral )

##### Available Regions ​ 
 # See all regions for a provider 
 elestio sizes --provider netcup 
 elestio sizes --provider hetzner 
 elestio sizes --provider aws 
 elestio sizes --provider azure 

###### Common regions ​ 
 Netcup: 

 Region Location 
 nbg Nuremberg, Germany (EU) 
 mns Manassas, Virginia, USA 

 Hetzner: 

 Region Location 
 fsn1 Falkenstein, Germany 
 nbg1 Nuremberg, Germany 
 hel1 Helsinki, Finland 
 ash Ashburn, Virginia, USA 

 AWS: us-east-1 , us-west-2 , eu-west-1 , eu-central-1 , ap-southeast-1 , ap-northeast-1 , and more.

##### Specifying a Provider at Deploy Time ​ 
 elestio deploy postgresql \ 
 --project 112 \ 
 --name my-db \ 
 --provider hetzner \ 
 --region fsn1 \ 
 --size LARGE-4C-8G 

##### Size Downgrade Warning ​ 
 Attempting to downgrade on an unsupported provider (Hetzner, GCP) can permanently block the service and require Elestio support intervention. The CLI will automatically refuse downgrade requests on unsupported providers.

 Only these providers support downgrading: 

Netcup

AWS

Azure

Scaleway

##### Support Tiers ​ 
 Available on all providers:

 Tier Monthly Cost Response Time Channel 
 level1 Included 48 hours Email 
 level2 +$50/service/mo 24 hours Priority email 
 level3 +$200/service/mo 4 hours Dedicated engineer 

 elestio deploy postgresql --project 112 --support level2 

 Previous
 CI/CD Pipelines
 Next
 Troubleshooting and Errors