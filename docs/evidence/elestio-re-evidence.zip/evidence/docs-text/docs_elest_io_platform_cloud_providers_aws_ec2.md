https://docs.elest.io/platform/cloud-providers/aws-ec2

Platform Features 

 Cloud Providers 

 AWS EC2 (BYOAWS - Bring Your Own AWS Account) 
 On this page 

# AWS EC2 (BYOAWS - Bring Your Own AWS Account) 
 AWS is the largest cloud provider with one of the best networks available and a large number of regions and data centers.

## Supported Services ​ 
 Service Supported 
 Compute ✅ 
 Private network ✅ 
 Firewall ✅ 
 Volumes ✅ 
 Elastic IP ✅ 
 Snapshots ✅ 

 SMTP Limitation
 SMTP Services are not supported in BYOAWS (Mailcow, Postal, etc.).

## Supported Regions ​ 
 Continent Country City Datacenter 
 Africa South Africa Cape Town af-south-1 
 Asia Australia Sydney ap-southeast-2 
 Asia Australia Melbourne ap-southeast-4 
 Asia Hong Kong Hong Kong ap-east-1 
 Asia India Mumbai ap-south-1 
 Asia India Hyderabad ap-south-2 
 Asia Indonesia Jakarta ap-southeast-3 
 Asia Japan Tokyo ap-northeast-1 
 Asia Japan Osaka ap-northeast-3 
 Asia Korea Seoul ap-northeast-2 
 Asia Singapore Singapore ap-southeast-1 
 Europe France Paris eu-west-3 
 Europe Germany Frankfurt eu-central-1 
 Europe Ireland Dublin eu-west-1 
 Europe Italy Milan eu-south-1 
 Europe Spain Spain eu-south-2 
 Europe Sweden Stockholm eu-north-1 
 Europe Switzerland Zurich eu-central-2 
 Europe United Kingdom London eu-west-2 
 Middle East Bahrain Bahrain me-south-1 
 Middle East United Arab Emirates UAE me-central-1 
 North America Canada Montreal ca-central-1 
 North America USA N. Virginia us-east-1 
 North America USA Ohio us-east-2 
 North America USA N. California us-west-1 
 North America USA Oregon us-west-2 
 South America Brazil Sao Paulo sa-east-1 

## VM Sizes ​ 
 Size Cores Ram HDD 
 MICRO-2C-1G 2 1GB 10 GB to 10 TB 
 SMALL-2C-2G 2 2GB 10 GB to 10 TB 
 MEDIUM-2C-4G 2 4GB 10 GB to 10 TB 
 LARGE-2C-8G 2 8GB 10 GB to 10 TB 
 XLARGE-4C-16G 4 16GB 10 GB to 10 TB 
 2XLARGE-8C-32G 8 32GB 10 GB to 10 TB 
 3XLARGE-16C-64G 16 64GB 10 GB to 10 TB 
 4XLARGE-32C-128G 32 128GB 10 GB to 10 TB 

## What is BYOAWS? ​ 
 BYOAWS (Bring Your Own AWS) allows you to deploy Elestio services directly in your own AWS account, giving you:

 Direct AWS billing - Pay AWS directly for infrastructure costs

 Full AWS integration - Access to all AWS services and features

 Enterprise compliance - Meet organizational AWS requirements

 Cost optimization - Use reserved instances, spot instances, and AWS credits

 Global reach - Deploy in any AWS region worldwide

## Key Differences from AWS Lightsail ​ 
 Feature AWS Lightsail AWS EC2 (BYOAWS) 
 Account Elestio's AWS account Your AWS account 
 Billing Through Elestio Direct from AWS 
 Instance types Limited selection Full EC2 catalog 
 Storage Fixed SSD sizes 10GB to 10TB flexible 
 AWS services Limited integration Full AWS ecosystem 
 Reserved instances Not available Available 
 Spot instances Not available Available 

## Benefits of BYOAWS ​ 

### Cost Control ​ 

 Reserved instances - Save up to 75% with 1-3 year commitments

 Spot instances - Save up to 90% for fault-tolerant workloads

 AWS credits - Use existing credits and promotional offers

 Direct billing - No markup, pay AWS rates directly

### Compliance & Security ​ 

 Your AWS account - Full control and ownership

 AWS compliance - SOC, PCI, HIPAA, and other certifications

 VPC integration - Connect to existing AWS infrastructure

 IAM policies - Fine-grained access control

### Enterprise Features ​ 

 AWS Support - Direct access to AWS enterprise support

 CloudTrail integration - Complete audit logs

 Cost allocation tags - Detailed billing breakdowns

 Multi-account support - Use AWS Organizations

## Setup Requirements ​ 

### AWS Account Prerequisites ​ 

 Active AWS account with administrative access

 VPC with public subnet (default VPC works)

 Internet Gateway attached to VPC

 Appropriate IAM permissions for EC2, VPC, EBS operations

### Elestio Configuration ​ 

 Connect AWS account to Elestio platform

 Configure deployment region and availability zone

 Set up service roles and permissions

 Choose instance types and storage options

## Storage Options ​ 
 Unlike other providers, BYOAWS offers flexible storage:

 EBS volumes from 10GB to 10TB per instance

 Multiple volume types - gp2, gp3, io1, io2 for different performance needs

 Snapshot backups - Point-in-time recovery

 Encryption at rest - AWS KMS integration

## Pricing Model ​ 
 With BYOAWS, you pay:

 AWS directly for infrastructure (EC2, EBS, data transfer)

 Elestio for management services (same as other providers)

 This often results in significant cost savings, especially with:

Reserved instances

Spot instances

AWS credits and enterprise agreements

## Getting Started ​ 

 Prepare AWS account with necessary permissions

 Contact Elestio support to enable BYOAWS

 Connect your AWS account through Elestio dashboard

 Choose region and instance types 

 Deploy services with full AWS integration

## Best Practices ​ 

### Security ​ 

 Use IAM roles instead of access keys where possible

 Enable CloudTrail for complete audit logging

 Configure VPC security groups properly

 Enable encryption for EBS volumes

### Cost Optimization ​ 

 Right-size instances based on monitoring data

 Use reserved instances for predictable workloads

 Consider spot instances for development/testing

 Monitor with AWS Cost Explorer 

### Operations ​ 

 Tag resources for cost allocation

 Set up CloudWatch monitoring and alerts

 Use AWS Backup for additional data protection

 Plan for disaster recovery across availability zones

## Important Considerations ​ 

 SMTP restrictions - AWS blocks port 25 by default

 Email services - Use AWS SES or external providers

 Billing complexity - AWS billing can be complex for beginners

 Account limits - New AWS accounts have service limits that may need increases

 BYOAWS is ideal for organizations already using AWS or those requiring enterprise-grade compliance and cost optimization features.

 Previous
 BYOAWS
 Next
 Microsoft Azure (BYO-AZURE)

 Supported Services 

 Supported Regions 

 VM Sizes 

 What is BYOAWS? 

 Key Differences from AWS Lightsail 

 Benefits of BYOAWS 
 Cost Control 

 Compliance & Security 

 Enterprise Features 

 Setup Requirements 
 AWS Account Prerequisites 

 Elestio Configuration 

 Storage Options 

 Pricing Model 

 Getting Started 

 Best Practices 
 Security 

 Cost Optimization 

 Operations 

 Important Considerations