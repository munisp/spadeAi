https://docs.elest.io/account-billing/billing/add-credits

Account & Billing 

 Billing 

 Add Credits 
 On this page 

# Add Credits 

## Add money to your elestio balance ​ 
 You can easily add credits to your elestio account from your User Profile.

Click on the User Icon to access your User Profile in the top left above the Main Navigation menu.

Select the Add Credits tab.

Enter the amount you wish to add to your account, in US dollars (USD).

Click the Pay Now. You will be redirected to the Stripe checkout site to complete your payment.

 success
 Funds are automatically added to your account upon successful payment. This can take up to a few minutes, but is usually instantaneous.

 info
 elestio has a $10 minimum, and a $1,000 maximum per transaction.
 If you would like to add a larger amount to your account, contact our sales team and we'd be happy to talk volume discounts!

 warning
 If you are a company, please fill out the company relevant fields. This helps us to determine your tax status and whether or not you need to pay VAT.

## Related Topics ​ 

 Payment Options - Configure auto-refill settings

 SEPA Direct Debit - European payment option

 Invoices - View your payment invoices

 Previous
 Billing Overview
 Next
 Payment Options

 Add money to your elestio balance 

 Related Topics