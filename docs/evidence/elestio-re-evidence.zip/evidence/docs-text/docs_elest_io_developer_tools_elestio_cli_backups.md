https://docs.elest.io/developer-tools/elestio-cli/backups

Developer Tools 

 Elestio CLI 

 Backups and Storage 
 On this page 

# Backups and Storage 
 Manage local, remote, S3, and snapshot backups, and standalone volumes, from the CLI.

###### Elestio provides three backup tiers and two storage extension types (volumes and snapshots). ​ 

##### Local Backups (Application-Level) ​ 
 Application-consistent backups are stored on the service VM itself. Created using pre/post-backup scripts specific to each template.

 # List local backups 
 elestio backups local-list <vmID> 

 # Create a local backup now 
 elestio backups local-take <vmID> 

 # Restore from a local backup 
 elestio backups local-restore <vmID> /opt/app-backups/backup.zst 

 # Delete a local backup 
 elestio backups local-delete <vmID> /opt/app-backups/backup.zst 

##### Remote Backups (Elestio Managed) ​ 
 Backups are stored in Elestio's managed storage infrastructure, separate from the VM.

 # List remote backups 
 elestio backups remote-list <vmID> 

 # Take a remote backup now 
 elestio backups remote-take <vmID> 

 # Restore from a remote backup 
 elestio backups remote-restore <vmID> <snapshot-name> 

 # Enable automatic remote backups (daily) 
 elestio backups auto-enable <vmID> 

 # Disable automatic remote backups 
 elestio backups auto-disable <vmID> 

##### S3 External Backups ​ 
 Store backups in your own S3-compatible bucket (AWS S3, MinIO, Backblaze B2, etc.).

 # Test S3 connectivity before enabling 
 elestio s3-backup verify <vmID> \ 
 --key ACCESS_KEY \ 
 --secret SECRET_KEY \ 
 --bucket my-backups \ 
 --endpoint s3.amazonaws.com 

 # Enable S3 backups 
 elestio s3-backup enable <vmID> \ 
 --key ACCESS_KEY \ 
 --secret SECRET_KEY \ 
 --bucket my-backups \ 
 --endpoint s3.amazonaws.com 

 # Take an S3 backup now 
 elestio s3-backup take <vmID> 

 # List S3 backups 
 elestio s3-backup list <vmID> 

 # Restore from S3 
 elestio s3-backup restore <vmID> <backup-key> 

 # Delete an S3 backup 
 elestio s3-backup delete <vmID> <backup-key> 

 # Disable S3 backups 
 elestio s3-backup disable <vmID> 

##### Snapshots (Provider-Level) ​ 
 Point-in-time disk snapshots. Support varies by provider. Hetzner has full snapshot support; Netcup has limited support.

 # List all snapshots 
 elestio snapshots list <vmID> 

 # Create a manual snapshot 
 elestio snapshots take <vmID> 

 # Restore a snapshot (use 0 for the most recent) 
 elestio snapshots restore <vmID> <snapshotId> 
 elestio snapshots restore <vmID> 0 

 # Delete a snapshot 
 elestio snapshots delete <vmID> <snapshotId> 

 # Enable automatic snapshots 
 elestio snapshots auto-enable <vmID> 

 # Disable automatic snapshots 
 elestio snapshots auto-disable <vmID> 

##### Volumes (Block Storage) ​ 
 Persistent storage volumes that can be attached to services. Hetzner provides full volume operations; other providers may have limited or no support.

 # List all volumes in a project 
 elestio volumes 

 # Create a standalone volume 
 elestio volumes create --name my-volume --size 20 

 # List volumes attached to a service 
 elestio volumes service-list <vmID> 

 # Create and attach a volume to a service 
 elestio volumes service-create <vmID> --name app-data --size 50 

 # Resize a volume 
 elestio volumes resize <vmID> <volumeID> --size 100 

 # Detach a volume from a service 
 elestio volumes detach <vmID> <volumeID> 

 # Delete a volume 
 elestio volumes delete <vmID> <volumeID> 

 # Protect a volume from accidental deletion 
 elestio volumes protect <vmID> <volumeID> 

##### Recommended Backup Strategy ​ 
 Tier Frequency Retention Use for 
 Local Manual No Fast restore, same VM 
 Remote Borg (auto) Daily Based on the support plan VM failure, corruption, restore 
 S3 external Daily Customizable Compliance, cross-region 

 Enable all three for production services:

 # Enable auto remote backups 
 elestio backups auto-enable <vmID> 

 # Enable S3 backups 
 elestio s3-backup enable <vmID> --key X --secret Y --bucket Z --endpoint S 

 # Enable auto snapshots (Hetzner only) 
 elestio snapshots auto-enable <vmID> 

 Previous
 Managing Services
 Next
 CI/CD Pipelines