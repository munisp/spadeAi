https://docs.elest.io/platform/security/ptr-record

Platform Features 

 Security 

 PTR Record 
 On this page 

# PTR Record 
 A PTR (reverse DNS) record maps your service IP back to a hostname, which improves email deliverability and some service checks.

## Open the configuration ​ 

Go to the Overview tab of your service dashboard.

Find the Manage PTR Record section.

Click Manage PTR Record .

## Steps ​ 

 Enter your domain (pre-filled if an existing PTR or CNAME is available).

 Create these DNS records:

 A record points to your service IPv4.

 AAAA record points to your service IPv6.

 Verify propagation with DNSChecker .

 Click Update to apply.

## Provider notes ​ 

 DigitalOcean — The system reboots after applying changes. PTR updates can take a few hours due to DNS caching.

 Other providers — Reverse DNS applies through the provider's own flow, and propagation timing can vary.

 Previous
 Custom Domain and SSL/TLS
 Next
 Domains

 Open the configuration 

 Steps 

 Provider notes