https://docs.elest.io/platform/cloud-providers/scaleway

Platform Features 

 Cloud Providers 

 Scaleway 
 On this page 

# Scaleway 
 Scaleway is a European cloud provider founded in France, with datacenters in Paris , Amsterdam and Warsaw . It is a good fit when your data must stay in the European Union, when you want to pick the exact disk size you need, or when you need ARM or NVIDIA GPU instances.

 On Elestio, Scaleway is a managed provider: the VM runs on Elestio's Scaleway account, you do not need your own Scaleway account, and everything is billed by Elestio, per hour, like any other service.

 Choose your disk size
 On Scaleway, the disk is not tied to the VM size. You choose it at deployment, from 10 GB to 10 TB , and you can grow it later from the dashboard. Disk storage is billed separately at $0.15 per GB per month , and the total is shown in the price summary before you deploy.

## Supported Services ​ 
 Service Supported 
 Compute ✅ 
 Global private network (Global Private IP) ✅ 
 Firewall ✅ 
 Resizable main disk (10 GB to 10 TB) ✅ 
 Separate volumes ❌ (coming soon) 
 Snapshots ✅ 
 Load balancer ✅ 
 Historical metrics ❌ (live metrics only) 
 GPU instances ✅ 
 ARM instances ✅ 

## Supported Regions ​ 
 Continent Country City Datacenter 
 Europe France Paris fr-par-1 
 Europe France Paris fr-par-2 
 Europe France Paris fr-par-3 
 Europe Netherlands Amsterdam nl-ams-1 
 Europe Netherlands Amsterdam nl-ams-2 
 Europe Poland Warsaw pl-waw-1 
 Europe Poland Warsaw pl-waw-2 

 Not every size is available in every datacenter: the dashboard only lists the sizes offered in the region you select. The tables below show where each size is available.

## VM Sizes ​ 
 On Scaleway, Bandwidth is the network throughput of the VM (its connection speed), not a monthly data allowance. Storage is the disk you choose at deployment, from 10 GB to 10 TB, for every size.

### General purpose (Intel, x86) ​ 
 Size Cores RAM Storage Bandwidth Datacenters 
 SMALL-2C-2G 2 2 GB 10 GB to 10 TB 200 Mbps fr-par-1, fr-par-2, nl-ams-1, nl-ams-2, pl-waw-1, pl-waw-2 
 MEDIUM-3C-4G 3 4 GB 10 GB to 10 TB 300 Mbps fr-par-1, fr-par-2, nl-ams-1, nl-ams-2, pl-waw-1, pl-waw-2 
 LARGE-4C-8G 4 8 GB 10 GB to 10 TB 400 Mbps fr-par-1, fr-par-2, nl-ams-1, nl-ams-2, pl-waw-1, pl-waw-2 
 XMLARGE-4C-12G 4 12 GB 10 GB to 10 TB 500 Mbps fr-par-1, fr-par-2, nl-ams-1, nl-ams-2, pl-waw-1, pl-waw-2 
 XLARGE-4C-16G 4 16 GB 10 GB to 10 TB 700 Mbps All datacenters 
 2XLARGE-8C-32G 8 32 GB 10 GB to 10 TB 1.5 Gbps All datacenters 
 3XLARGE-16C-64G 16 64 GB 10 GB to 10 TB 3 Gbps All datacenters 

### ARM (Ampere Altra Max) ​ 
 Size Cores RAM Storage Bandwidth Datacenters 
 LARGE-2C-8G-COPARM1 2 8 GB 10 GB to 10 TB 200 Mbps fr-par-2 
 XLARGE-4C-16G-COPARM1 4 16 GB 10 GB to 10 TB 400 Mbps fr-par-2 
 2XLARGE-8C-32G-COPARM1 8 32 GB 10 GB to 10 TB 800 Mbps fr-par-2 
 3XLARGE-16C-64G-COPARM1 16 64 GB 10 GB to 10 TB 1.6 Gbps fr-par-2 

 ARM compatibility
 ARM sizes run the arm64 architecture. Check that the software you deploy publishes arm64 Docker images, otherwise use an Intel size.

### GPU (NVIDIA) ​ 
 Size Cores RAM GPU Storage Bandwidth Datacenters 
 2XPLARGE-8C-48G 8 48 GB 1x NVIDIA L4 (24 GB) 10 GB to 10 TB 2.5 Gbps fr-par-2, pl-waw-2 
 2XMPLARGE-10C-42G 10 42 GB 1x NVIDIA Tesla P100 10 GB to 10 TB 1 Gbps fr-par-1 

 GPU sizes are locked by default
 GPU sizes show a lock in the size list. The project owner can unlock them by clicking the lock. Unlocking is not available while promotional credits are active.

## Why Choose Scaleway? ​ 

 European data sovereignty - French provider, every datacenter is in the European Union

 Disk sized to your needs - From 10 GB to 10 TB, independent of CPU and RAM

 Flexible plan changes - Move to a larger or a smaller size, your disk stays the same

 ARM instances - Ampere Altra Max processors in Paris

 NVIDIA GPUs - L4 and Tesla P100 for AI inference, rendering and compute workloads

 Load balancers - Put a managed load balancer in front of your Scaleway services

## Important Considerations ​ 

 Disk is billed separately - $0.15 per GB per month on top of the VM price, included in the price shown before you deploy

 The disk can only grow - You can increase the disk size from the service overview, never decrease it

 No separate volumes yet - Attaching an extra volume is not available on Scaleway for now; increase the main disk instead

 Live metrics only - The Metrics tab shows live usage; historical graphs are not available on Scaleway

 Changing the size stops the service - Elestio powers off the VM, applies the new size and starts it again

 SSH keys - Keys added from the dashboard are stored in /root/.ssh/instance_keys (Scaleway's format), not in authorized_keys 

 Snapshot restore - Restoring a snapshot takes a few minutes, usually 3 to 5. Keep the page open until it finishes

 SMTP servers - If you host a mail server and run into IPv6 delivery issues, you can disable IPv6 on the VM

## Getting Started ​ 

Select Scaleway as your provider in the Elestio dashboard

Choose your datacenter: Paris, Amsterdam or Warsaw, closest to your users

Pick a VM size: Intel for most software, ARM for arm64 compatible software, GPU for AI and rendering

Set the disk size you need (10 GB to 10 TB) and check the price summary

Deploy your service

 Previous
 Linode
 Next
 BYOVM (Bring Your Own VM)

 Supported Services 

 Supported Regions 

 VM Sizes 
 General purpose (Intel, x86) 

 ARM (Ampere Altra Max) 

 GPU (NVIDIA) 

 Why Choose Scaleway? 

 Important Considerations 

 Getting Started