https://docs.elest.io/developer-tools/cicd-pipelines/custom-domains-on-cicd-pipelines

Developer Tools 

 CI/CD Pipelines 

 Configuration & Management 

 Custom domains on CI/CD pipelines 

# Custom domains on CI/CD pipelines You can add any number of custom domain names on your CI/CD pipeline, Elestio will automatically configure the routing of the traffic and SSL termination / certificate creation and renewals.
To add a custom domain on your pipeline click on "Domain Management" in the details screen of your pipeline

Then click on the "Manage Domains" button

There you can click inside the input, type your custom domain name (Eg: mydomain.com) and press enter
Finally, go to your domain registrar, create a new DNS record of type CNAME (Eg: www) and in the value put the value in bold from the popup (Eg: xxxxxxxxxx-u3.vm.elestio.app)
Wait until the DNS entry is propagated (usually anywhere between 15 min up to 2 hours), you can check if your DNS entry is propagated with this free online tool: https://dnschecker.org/ 
We recommend to use CNAME records instead of A, that way if later you decide to move your pipeline in 1 click from our UI it will work right away. If you used an A record, you will have to go back to your registrar to update the A record to point to the new IP address.

 Previous
 Create your own template (elestio.yml)
 Next
 Clone CI/CD pipeline