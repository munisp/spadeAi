https://docs.elest.io/platform/object-storage/recycle-bin

Platform Features 

 Object Storage 

 Recycle bin 
 On this page 

# Recycle bin 
 With the recycle bin on, a deleted file is kept for a while, so you can restore it after a mistake.

## Turn it on ​ 
 In the bucket, open Settings > Recycle bin , choose how long deleted files are kept ( 7 to 90 days ), and turn it on.

 info
 Kept files are billed like stored files until they leave the bin.

## Restore a deleted file ​ 
 In the Files tab, click Deleted files . For each file: Restore it, or Delete for good .

 warning
 Deleting the bucket itself is still final: the recycle bin does not keep a deleted bucket.

 Previous
 Lifecycle rules
 Next
 CORS

 Turn it on 

 Restore a deleted file