https://docs.elest.io/platform/backups/automated-external-s3

Platform Features 

 Backups 

 Automated External Backups (S3) 

# Automated External Backups (S3) External backups are stored in your S3 bucket, so you own your backups directly. Elestio's external backup service is compatible with AWS S3 and any S3-compatible provider.

 To enable external backups from the service dashboard click on the Backups tab, then click on Automated External Backups .

 You will have to provide your S3 details. (endpoint, bucket name, API key, secret key)

 Before entering the bucket

 You can click on the "Verify Config" button to validate your settings.

 Once activated, you will be able to click on Settings to configure the backups schedule. You can also take an external backup at any time with the "Take a backup" button.

 If you click on Settings, you can configure the backups schedule and a number of backups to retain.

 info
 If you don't have access to an AWS S3 bucket or an S3 bucket from another provider, you can deploy Minio to get your own S3 Bucket

 Previous
 Automated VM Snapshots
 Next
 How to Create AWS Access and Secret Key for External backups (S3)