https://docs.elest.io/platform/object-storage/

Platform Features 

 Object Storage 

 Object Storage 
 On this page 

# Object Storage 
 Elestio Object Storage keeps your files in buckets that any S3 tool or SDK can use. It is managed for you: no server to run, no disk to resize, and you pay only for what you store and use.

## What you can do ​ 

 Create a bucket in the region of your choice, in a few seconds.

 Manage your files from the dashboard: upload, folders, preview, download and share links.

 Create API keys with read only or read and write access, limited to some folders, IP addresses or a date if you want.

 Connect your code with any S3 tool: AWS CLI, Node.js, Python, rclone, Cyberduck and more.

 Serve files on your own domain , with HTTPS, and make a bucket public if you need to.

 Delete old files automatically with lifecycle rules.

 Recover deleted files from the recycle bin.

 Allow your websites to upload or read files from the browser (CORS).

 Get notified on your webhook when files change.

 Use a bucket as a Linux disk with Infinidisk.

## Pricing in short ​ 
 You pay the real usage, every day, from your Elestio credits. There is no fee for data going out.

 Single region or Global Multi-region 
 Storage (Standard) $0.02 per GB per month $0.025 per GB per month 
 Writes and lists (PUT, COPY, POST, LIST) $0.005 per 1,000 requests $0.01 per 1,000 requests 
 Reads (GET and others) $0.0005 per 1,000 requests $0.0005 per 1,000 requests 
 Data transfer out Free Free 

 Every detail, and how to follow your consumption: see Billing and limits .

## Limits in short ​ 

 10 buckets and 20 API keys per project.

 100 GB of storage per project during the free trial, 1 TB once you are a paying customer.

Need more? Click Request more on the Object Storage page (project owner only).

 Previous
 Volumes
 Next
 Create a bucket

 What you can do 

 Pricing in short 

 Limits in short