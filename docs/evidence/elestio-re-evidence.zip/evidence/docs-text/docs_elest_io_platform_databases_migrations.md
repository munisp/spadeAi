https://docs.elest.io/platform/databases/migrations/

Platform Features 

 Databases 

 Migration Services 

 Database Migrations 
 On this page 

# Database Migrations 
 Need help to migrate to Elestio? Follow the comprehensive guides in this section to seamlessly move your databases and applications to our platform.

## Overview ​ 
 Elestio provides robust migration tools and comprehensive documentation to help you move your existing systems to our platform with minimal downtime. Whether you're migrating supported services, custom applications, or databases, we have the tools and guides to make your transition smooth and efficient.

## Migration Types ​ 

### Supported Services Migration ​ 
 For applications and databases that are fully supported by Elestio, we provide streamlined migration processes with built-in tools and automated features.

 → Migrate Supported Services 

### Custom Applications Migration ​ 
 For custom applications or services not directly supported by Elestio, we offer flexible migration options including Git repository imports, containerized deployments, and manual migration paths.

 → Migrate Custom Applications 

### Database-Specific Migration ​ 
 Comprehensive guides for migrating specific database types including MySQL, PostgreSQL, and other supported databases.

 → Database Migration Guides 

### Specialized Migration Guides ​ 
 Step-by-step instructions for popular applications with specific migration requirements:

 WordPress Migration - Complete guide for WordPress sites

 Jenkins Pipeline Migration - CI/CD pipeline migration

 Superset Migration - Analytics dashboard migration

 Mastodon Server Migration - Social media server migration

## Migration Tools and Features ​ 

### Elestio Migration Service ​ 
 Our platform includes a built-in migration tool that provides:

 Automated Data Transfer - Direct database-to-database migration

 Connection Validation - Pre-migration connectivity checks

 Real-time Monitoring - Live progress tracking and logs

 Minimal Downtime - Optimized for production environments

### Additional Tools ​ 

 File Explorer - Web-based file management

 VSCode Integration - Direct code editing capabilities

 Filezilla Support - FTP/SFTP file transfers

 Docker Container Management - Container lifecycle management

## Getting Started ​ 

 Choose Your Migration Type - Select from the options above based on your needs

 Review Prerequisites - Ensure you have the necessary access and information

 Prepare Your Data - Follow the export/backup procedures for your source system

 Deploy Target Service - Set up your destination service on Elestio

 Execute Migration - Use our tools and guides to transfer your data

 Test and Validate - Verify your migration was successful

## Best Practices and Troubleshooting ​ 
 For migration best practices, common issues, and troubleshooting guidance:

 → Best Practices and Troubleshooting 

## Need Help? ​ 
 If you encounter any issues during migration or need additional assistance:

Create a support ticket 

Our team will get back to you promptly with personalized help

## Migration Process Overview ​ 
 Each migration guide follows a consistent structure:

 Prerequisites - Requirements and preparation steps

 Data Export - How to extract data from your source system

 Service Setup - Deploying and configuring your Elestio service

 Data Import - Importing your data to the new service

 Testing - Validation and verification steps

 Support - Additional help and resources

 This structured approach ensures a reliable and predictable migration experience regardless of which service or application you're migrating.

 Previous
 Databases
 Next
 Database Migration Guides

 Overview 

 Migration Types 
 Supported Services Migration 

 Custom Applications Migration 

 Database-Specific Migration 

 Specialized Migration Guides 

 Migration Tools and Features 
 Elestio Migration Service 

 Additional Tools 

 Getting Started 

 Best Practices and Troubleshooting 

 Need Help? 

 Migration Process Overview