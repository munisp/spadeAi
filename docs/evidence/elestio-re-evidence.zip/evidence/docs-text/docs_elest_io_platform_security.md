https://docs.elest.io/platform/security/

Platform Features 

 Security 

 Security 
 On this page 

# Security 
 Every service is set up with several layers of security, enabled by default. You manage all of them from the Security tab in your dashboard.

 What you get out of the box:

 Automated SSL/TLS — Certificates generated and renewed automatically.

 Network firewall — Only the ports your app needs are open.

 IP rate limiter — Throttles abusive web traffic.

 Output cache — Absorbs traffic spikes and basic DoS.

 Termination protection and grace period — Guards against accidental deletion.

 SSH key management — Control which keys can reach your server.

## More security topics ​ 

 Nginx configuration — Customize the reverse proxy, per-site and globally.

 Using Cloudflare and Cloudflare Tunnel — Proxy and protect your traffic.

 SMTP service — Send transactional email from your service.

 Multi-factor authentication — Protect your Elestio account.

 IPv6 — Enable or disable IPv6, and make Nginx listen on it.

 PTR records — Configure reverse DNS.

 Previous
 Monitoring
 Next
 Nginx Configuration

 More security topics