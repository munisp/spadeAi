https://docs.elest.io/platform/databases/migrations/custom-applications

Platform Features 

 Databases 

 Migration Services 

 Migrate Your Custom Application to Elestio 
 On this page 

# Migrate Your Custom Application to Elestio 
 This migration document is only for services that are not being supported by Elestio as a fully managed option. If you are unaware of the software supported, take a look here . If Elestio is supporting the software then you can follow this migration document 

 This guide covers migrating custom applications or services that are not directly supported by Elestio's managed services catalog.

## Prerequisites ​ 

Make sure the service you are trying to migrate from is being supported by Elestio. You can find the entire software catalogue here 

Create an account on Elestio 

Make sure the UI for the application is working fine and there are no critical errors detected in the application logs. If found otherwise please feel free to create a support ticket

When deploying the service on Elestio, use the same software version as your present service, or your data migration will fail.

## Migration Method 1: Using Git Repository ​ 
 If your service/application is hosted on Git repositories (public & private) you can follow the following steps to migrate easily to Elestio.

 Head over to the CI/CD section and choose and import your Git repository

 Choose the cloud of your choice, region and service plan.

 Select the tech-stack or docker-compose in case you have that on your git-repository

 You can add additional configurations to your application by going to the "Build and Deploy" option.

 In case you need to add something that is not available on your git repository then you can add it manually with the given steps in the "Manual Migration" from below.

## Migration Method 2: Containerized Migration ​ 
 If your application is containerized and you want to use pre-built docker images. If you have a git repository you use to build these images then you can directly use these git repositories to deploy your application to Elestio from the steps given above

 Go to the Elestio dashboard and use the Docker Compose option in the CI/CD section choose a custom docker-compose and click on Deploy.

 Choose the cloud service provider, region and service plan of your choice 

 Add your docker-compose configuration code in the given area. Additionally, if you are using a private Docker repository then you can use the checkbox to indicate that.

## Migration Method 3: Manual Migration ​ 
 If you don't use containerization then you will be guided to do a manual migration. Follow the following steps to effortlessly migrate to Elestio.

 You should head over to the dashboard and select the template that works with your application tech stack

 After the service is deployed, you can go ahead to the "Tools" tab and select any method of your choice to upload the assets and data 

 For example, the following image is from File Explorer. You should navigate to /opt/app/PIPELINE_NAME and upload your code files and other assets exactly like you have in your project directory

 After successful upload, you can update the settings in the dashboard

## Database Migration for Custom Applications ​ 
 If you are trying to migrate the database data then follow the instructions below to complete the migration without any data loss

If you are using a database that provides a UI option eg: phpMyAdmin or pgAdmin then you can go ahead with to export setting of the original database export the data in the file and import that data from the file inside the Elestio instance

If the database does not have UI or provide dedicated options for import and export in UI then follow the same above steps to manually add the exported data file to the VM and then restore the file in the database

 For detailed database migration guides, see our Database Migration section .

## Testing the Migration ​ 

 You have successfully migrated to Elestio, now it's time for testing if your database is running as you intended

 Make use of integrated tools in Elestio like File Explorer, VScode, or Filezilla to set the additional data and assets

 If you find any issues with the migration, try to restart your instance and restart containers using the following commands

 docker-compose down; 

 docker-compose up -d --build 

 Checkout logs if something is failing. Note that there can be a version lapse between your currently hosted database and the running instance on Elestio (Latest version) as mentioned in the Prerequisites section

## Need Additional Help? ​ 
 Stuck somewhere? We are here to help you, go ahead and create a support ticket and we will get back to you in no time.

## Related Guides ​ 

 Managed Services Migration - For supported services

 Database Migration - Database-specific guides

 Best Practices - Tips and troubleshooting

 Previous
 Migrate to Elestio Managed Services
 Next
 Migrate WordPress to Elestio

 Prerequisites 

 Migration Method 1: Using Git Repository 

 Migration Method 2: Containerized Migration 

 Migration Method 3: Manual Migration 

 Database Migration for Custom Applications 

 Testing the Migration 

 Need Additional Help? 

 Related Guides