https://elest.io/tcloud-managed-services

Enterprise managed services for T Cloud 

# Your T Cloud account. Our operations team. 
 You already made the sovereignty decision. Elestio deploys and operates 400+ open-source services inside the T Cloud Public (formerly Open Telekom Cloud) account you already have. Nothing migrates. Your virtual machines, your Deutsche Telekom contract and your compliance posture stay exactly where they are.

 Connect Your T Cloud Account 
 Managed services for T Cloud 

 No migration, your account stays yours 
 Scoped IAM access, revocable at any time 
 Your Telekom contract untouched 

 The gap

## You bought sovereign infrastructure. You did not buy an operations team. 
 T Cloud gives you German data centers, EU jurisdiction and an OpenStack platform. What it does not give you is the team that patches, backs up, renews certificates and answers at 3 in the morning. That is the work Elestio takes over, inside your own account.

### The capacity problem, not the infrastructure problem 
 Your infrastructure decision is made. What is missing is the headcount to operate twenty open-source services properly, week after week, without pulling engineers off product work.

### Open source has an operational tax 
 Every service you self-host carries CVE monitoring, OS patching, version upgrades, certificate rotation, backup verification and out-of-hours response. Multiply that by your catalog and it becomes a full-time role nobody was hired for.

### Your compliance posture does not move 
 Because this is a bring your own account model, your virtual machines never leave your T Cloud tenancy. Your contract with Deutsche Telekom, your data residency and your regulatory position stay exactly as your auditors already documented them.

### Nothing to migrate, ever 
 There is no lift and shift phase, no cutover weekend and no parallel run. Elestio provisions and operates inside the account you already have. If you stop tomorrow, the infrastructure stays where it is.

 How it starts

## Three steps, and none of them is a migration 
 Most engagements are running the same week they are approved.

### You create a scoped IAM user 
 A dedicated user in your T Cloud console with six explicit policies. Not your root credentials, not a shared account. You hand over an Access Key, a Secret Key and your account Domain Name.

### You choose what we operate 
 Pick from 400+ open-source services, or point us at what you already run. Select the Elastic Cloud Server size and the region inside your own tenancy.

### We take over the operations 
 Deployment, daily backups, OS and software updates, SSL certificates, firewall rules, 24/7 monitoring and security hardening. You keep root access throughout.

 Day to day

## What actually changes on Monday morning 
 The same work still has to happen. The question is who is accountable for it and what it costs you in attention.

 Operational task

 Handled in-house

 With Elestio

 Deployment of a new service

 Days of setup, hardening and documentation

 ✓ One click from a catalog of 400+

 OS patching and CVE response

 Manual, and it slips when the team is busy

 ✓ Automated and continuous

 Software version upgrades

 Researched and executed per service

 ✓ Reviewed and applied from the dashboard

 Daily backups

 Scripted, and rarely restore-tested

 ✓ Automated daily backups

 SSL certificate lifecycle

 A calendar reminder and an outage when it is missed

 ✓ Issued and renewed automatically

 24/7 monitoring and alerting

 On-call rota you have to staff

 ✓ Included, with proactive intervention

 Firewall and network rules

 Hand-maintained security groups

 ✓ Configured and maintained

 Where the virtual machines live

 Your T Cloud account

 ✓ Your T Cloud account, unchanged

 Who holds the infrastructure contract

 You, with Deutsche Telekom

 ✓ You, with Deutsche Telekom

 Root access to your servers

 Yours

 ✓ Still yours

 Access model

## A scoped, auditable, revocable access model 
 The first question every security team asks is what exactly we can reach. Here is the whole answer.

### Six policies, and the reason each one exists 

 ECS Admin to create and delete the virtual machines we operate, and to manage their SSH keypairs.

 ECS FullAccess to handle reboot, power control, resizing and instance state APIs.

 EVS FullAccess to attach root volumes, expand storage and manage backups.

 VPC Administrator to create subnets, maintain security groups and automate firewall rules and Elastic IPs.

 KMS CMKReadOnlyAccess , and note that this one is read only . Elestio never creates an encryption key. We read the evs/default key that already exists in your account so your volumes are encrypted with a key you own and we cannot rotate or delete.

 DNS Administrator to maintain reverse DNS records, which is what keeps email deliverability and SSL validation working.

 Access lives in a dedicated IAM user, isolated from your existing resources. Every action it performs is attributable to that user in your own T Cloud audit trail. You revoke it in your console, at any time, without asking us. Full setup guide in the documentation .

 Read the full access and security model 

 Support

## Support levels and service commitments 
 Level 1 is included with every service. Higher levels add response commitments, longer backup retention and an uptime SLA.

 Level 1

 Level 2

 Level 3

 Price per service, per month

 Included

 $50

 $200

 Uptime SLA

 No SLA

 99.5%

 ✓ 99.9%

 Response time

 Email, human engineers

 24 hours (business hours)

 ✓ 4 hours (business hours)

 Remote backup retention

 7 days

 14 days

 ✓ 30 days

 Dedicated Customer Success Manager

 ✗ 

 ✗ 

 ✓ Included

 Commercial model

## Two invoices, and yours with Telekom does not change 
 Elestio never sits between you and Deutsche Telekom. You keep your own commercial relationship, your committed volume and any negotiated discount.

 $5
 per vCPU

 $2.50
 per GB RAM

 $0.025
 per GB disk

 Elestio management fees are billed hourly. T Cloud infrastructure is billed separately and directly by Deutsche Telekom on your existing account, so your commitments and discounts there are untouched. A 2 vCPU, 4 GB RAM, 80 GB service costs $22 per month in management fees. 

 Reviews

## Trusted by 10,000+ Developers Worldwide 
 Real reviews from real users on Trustpilot.

 “

 ★★★★★

 "I'm in the IT industry for over 25 years and Elestio stands out in many ways. The managed services are top-notch, support is incredibly fast, and the platform just works. Couldn't be better!"

 Conflock 
 IT Director · Germany · Verified on Trustpilot 

 See all reviews on Trustpilot

 FAQ

## Frequently Asked Questions 

 We already run T Cloud. What does Elestio actually change? 

 Operationally, a lot. Contractually, nothing. Elestio connects to your existing T Cloud account through a scoped IAM user and takes over deployment, patching, backups, SSL, monitoring and security hardening for the services we manage. Your virtual machines stay in your tenancy, your invoice still comes from Deutsche Telekom, and your data never moves.

 Is there a migration project? 

 No. That is the structural advantage of the bring your own account model. Elestio provisions inside the account you already have, so there is no lift and shift, no cutover window and no parallel run. New services are deployed directly into your tenancy.

 Does this affect our compliance or our audits? 

 Your infrastructure does not move, so your data residency and your contractual position with Deutsche Telekom are unchanged. T Cloud remains the operator of the underlying platform under German and EU jurisdiction. Elestio operates the software layer on top and acts as a service provider, not as your hosting provider.

 What exactly can Elestio access in our account? 

 A dedicated IAM user with six policies: ECS Admin, ECS FullAccess, EVS FullAccess, VPC Administrator, KMS CMKReadOnlyAccess and DNS Administrator. KMS is read only, because Elestio never creates encryption keys and instead uses the evs/default key that already exists in your account. Every action is attributable to that user in your own audit trail, and you can revoke it from your console without contacting us.

 What support commitments are available? 

 Level 1 is included with every service and covers email support from real engineers, with 7 days of remote backup retention. Level 2 is $50 per service per month and adds a 99.5% uptime SLA, a 24 hour response commitment (business hours) and 14 days of retention. Level 3 is $200 per service per month with 99.9% uptime, a 4 hour response commitment (business hours), 30 days of retention and a dedicated Customer Success Manager. Custom SLAs are available on request.

 How is it billed? 

 Two separate invoices. Deutsche Telekom bills your T Cloud infrastructure directly on your existing account, so your committed volume and negotiated discounts still apply. Elestio bills the management fee hourly, calculated as $5 per vCPU plus $2.50 per GB RAM plus $0.025 per GB disk.

 What happens if we stop the service? 

 The infrastructure is yours and stays where it is. You keep full root access to your servers throughout the engagement, and you can revoke Elestio access from your own T Cloud console at any time. You can also clone or migrate managed services to any of the 9 cloud providers Elestio supports.

 More on T Cloud

 Access and security model Shared responsibility and SLA In-house vs managed Public sector Managed PostgreSQL Deploy on T Cloud Bring your own T Cloud account AWS vs T Cloud Azure vs T Cloud 

## Your infrastructure is already sovereign. Make it operated. 
 Connect your existing T Cloud account and let Elestio run the open-source layer on top.

 Get Started