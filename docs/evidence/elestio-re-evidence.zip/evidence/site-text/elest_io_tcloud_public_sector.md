https://elest.io/tcloud-public-sector

Public sector, healthcare and research 

# Managed open source for the public sector on T Cloud 
 Your institution already chose sovereign infrastructure. Elestio operates the open-source layer inside the T Cloud Public (formerly Open Telekom Cloud) account you already hold, without changing where the data lives, who holds the encryption keys, or who your infrastructure contract is with.

 Connect Your T Cloud Account 
 Managed services for T Cloud 

 No new hosting supplier to procure 
 Residency follows your own tenancy 
 Key custody stays with your institution 

 Why this fits

## Why the model suits public sector procurement 
 Public bodies, healthcare providers and research institutions are among the sectors T Cloud itself targets. The bring your own account model fits how they are required to buy.

### The hosting relationship does not change hands 
 Your infrastructure contract stays directly with Deutsche Telekom. Elestio is engaged as a service provider for operations, not as a new hosting supplier. That is usually a materially simpler thing to procure and to document.

### Residency follows your own tenancy 
 T Cloud operates data centers in Germany and the Netherlands, with a separate Swiss offering. Elestio deploys into whichever region your account already uses, so data residency is determined by your tenancy rather than by a provider platform.

### Key custody stays inside the institution 
 Root volumes are encrypted with the evs/default key that lives in your own account. Elestio holds read-only access and cannot rotate or delete it. When a data protection officer asks who holds the keys, the answer is your organisation.

### Auditability without depending on the supplier 
 Elestio operates through a single dedicated IAM user, so every action is attributable in your own T Cloud audit trail. You do not have to request logs from a third party to evidence what happened.

 Workloads

## Open-source software commonly deployed in the sector 
 All of it deployed and operated inside your own T Cloud account, from a catalog of 400+ services.

 Software

 What it is used for

 Nextcloud

 File sharing and collaboration under your own control

 Keycloak

 Single sign-on and identity federation

 Moodle

 Learning management for education and training

 Matomo

 Web analytics without sending visitor data to a third party

 GitLab

 Source control, CI/CD and internal developer platform

 PostgreSQL

 The general purpose relational database for line of business systems

 Grafana

 Dashboards and operational reporting

 Mattermost

 Internal messaging retained on your own infrastructure

 OpenProject

 Project and portfolio management

 Metabase

 Self-service analytics for non-technical teams

 Engagement

## What an engagement looks like in practice 
 Nothing about this requires a migration project or a procurement of new infrastructure.

### From approval to running 

Your team creates a dedicated IAM user in your existing T Cloud console with six scoped policies. No root credentials are shared.

You select the services to be operated and the region inside your own tenancy . Nothing is provisioned anywhere else.

Elestio takes over deployment, OS patching, software updates, daily backups, SSL certificates, firewall configuration and 24/7 monitoring.

You choose a support level : Level 1 included, Level 2 at $50 per service per month for a 99.5% SLA and 24 hour response (business hours), or Level 3 at $200 for 99.9% and 4 hour response (business hours) with a dedicated Customer Success Manager. Custom SLAs are available.

Your team keeps full root access throughout, and can revoke Elestio access at any time from your own console.

 Elestio holds ISO 27001, SOC 2 Type II, HIPAA and GDPR compliance positions. Contact the team to put the appropriate data processing agreements in place for your jurisdiction before production use.

 Reviews

## Trusted by 10,000+ Developers Worldwide 
 Real reviews from real users on Trustpilot.

 “

 ★★★★★

 "I'm in the IT industry for over 25 years and Elestio stands out in many ways. The managed services are top-notch, support is incredibly fast, and the platform just works. Couldn't be better!"

 Conflock 
 IT Director · Germany · Verified on Trustpilot 

 See all reviews on Trustpilot

 FAQ

## Frequently Asked Questions 

 Do we have to procure a new hosting provider? 

 No, and this is the main reason the model fits public procurement. Your infrastructure contract remains directly with Deutsche Telekom because the virtual machines are provisioned inside your own T Cloud account. Elestio is engaged as a service provider for operations, which is a different and usually simpler procurement category.

 Where would our data be stored? 

 In your own T Cloud tenancy, in whichever region you already use. T Cloud operates data centers in Germany and the Netherlands, with a separate Swiss offering. Elestio deploys into your account rather than onto Elestio infrastructure, so residency is a property of your own tenancy.

 Who holds the encryption keys? 

 Your institution. Root volumes are encrypted with the evs/default key that exists in your own account. Elestio requests read-only access to it and cannot create, rotate, disable or delete any key.

 How do we evidence what the supplier did? 

 Elestio operates through a single dedicated IAM user, so every API call is attributable to that identity in your own T Cloud audit trail. The evidence lives in your account and does not depend on requesting logs from Elestio.

 What service commitments can we contract? 

 Level 1 support is included with every service. Level 2 is $50 per service per month with a 99.5% uptime SLA, a 24 hour response commitment (business hours) and 14 days of backup retention. Level 3 is $200 per service per month with 99.9% uptime, a 4 hour response (business hours), 30 days of retention and a dedicated Customer Success Manager. Custom SLAs are available on request.

 Which open-source software is available? 

 The Elestio catalog covers more than 400 open-source services. Software frequently deployed in the sector includes Nextcloud, Keycloak, Moodle, Matomo, GitLab, PostgreSQL, Grafana, Mattermost, OpenProject and Metabase, all deployed and operated inside your own account.

 More on T Cloud

 Managed services for T Cloud Access and security model Shared responsibility and SLA In-house vs managed Managed PostgreSQL Deploy on T Cloud Bring your own T Cloud account AWS vs T Cloud Azure vs T Cloud 

## Sovereign infrastructure, operated properly 
 Your T Cloud account, your data residency, your keys. Elestio runs the open-source layer on top.

 Get Started