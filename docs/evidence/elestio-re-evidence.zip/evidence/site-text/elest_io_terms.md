https://elest.io/terms

Terms of Service | Elestio - Managed DevOps Platform 

 Managed services ▾ 

 Databases 
 PostgreSQL, MySQL, Redis, MongoDB & more 

 Applications 
 n8n, WordPress, Supabase, Keycloak & more 

 Development 
 CI/CD tools, IDE, Git hosting & version control 

 Hosting & Infrastructure 
 Servers, containers, monitoring & storage 

 AI & GPU 
 LLMs, AI frameworks, GPU-powered inference tools 

 View all 400+ services → 

 Features ▾ 

 Domains 
 Custom domains & SSL for your services 

 CI/CD 
 Automated deployment pipelines 

 Terraform 
 Infrastructure as code provider 

 Clusters 
 High availability & multi-node scaling 

 AI ▾ 

 AI DevOps 
 Describe an issue, AI fixes your server 

 Agents 
 Deploy with AI coding agents 

 AI & Automation 
 Automate your infrastructure workflows 

 Vibecoder 
 AI-powered app development & deployment 

 Resources ▾ 

 Documentation 
 Guides, API reference & tutorials 

 Blog 
 Product news, engineering & updates 

 Use Cases 
 Real customer success stories 

 Community 
 Join the discussion on Discord 

 Pricing 

 Login 
 Get Started 

 Managed services ▾

 Databases 
 Applications 
 Development 
 Hosting & Infrastructure 
 AI & GPU 
 All Services 

 Features ▾

 Domains 
 CI/CD 
 Terraform 
 Clusters 

 AI ▾

 AI DevOps 
 Agents 
 AI & Automation 
 Vibecoder 

 Resources ▾

 Documentation 
 Blog 
 Use Cases 
 Community 

 Pricing 
 Documentation 

 Login 
 Get Started 

# 
 Terms & Conditions

 Elest.io is a website owned by ELESTIO LIMITED, a company based in
 Ireland with its registered office at 29 Merrion Square, Dublin 2, D02 RW64, 
 Company Registration Number 755058.

 We provide our users with access to certain tools that allow them to
 deploy and manage Open source software (hereinafter, the “Services”)
 through the website Elest.io. You can find a complete and detailed
 description of each one of these Services in our website.
 https://Elest.io

 These Terms of Use, together with any documents herein mentioned,
 set forth the terms and conditions governing the use of this
 website, and the purchase and usage of the Services through Elest.io
 (hereinafter, the “Terms").

 Elest.io's contents and Services are available to all individuals of
 legal age, who are legally capable of entering into contracts
 (binding agreements).

 Please read through these Terms prior to using this website. By
 using this website, or purchasing Services through it, you are
 consenting to be bound by these Terms. If you do not agree to all of
 the Terms, please do not use this website.

 Please be aware that these Terms may be amended from time to time.
 It is your responsibility to regularly read through them, as the
 Terms set at the time that you use the website, or at the time of
 the formation of the Contract (as defined below), shall be the
 applicable ones. The most recent version of the Terms will always be
 available on this website. We are not required to notify you of any
 updates made to the Terms.  We, therefore, encourage all users
 to read this agreement in detail. Potential changes are effective at
 the time the Terms are updated.

1. Definitions

 The following definitions will be applicable to these Terms,
 together with any documents herein mentioned:

 a) ”You” refers to you, the user of the Elest.io website, its
 contents, and Services.  “Your” shall be interpreted
 accordingly.

 b) “We”, “Us”, and “Elestio” refers to Elestio Limited.  “Our”
 and “Elestio’s” shall be interpreted accordingly.

 c) “Our Website” refers to the website “Elest.io”.  However,
 “User App” refers to websites and mobile applications of Our Users,
 hence created using the Elestio system.

2. Purchase of Services

 2.1. Trial Version

 Elestio allows the User to try some of the Services, absolutely free
 of charge, during three (3) days ("Trial Period").  Only
 Services and features clearly indicated as "free", "trial", or "no
 charge" are free or without charge.  It is not the
 responsibility of Elestio to provide You free support of use and
 operation of the Services during the Trial Period.

 If You registered for a trial use of the Services, You must decide
 to purchase the Services within the Trial Period in order to retain
 any content that You have posted or uploaded during the Trial
 Period.  If You do not purchase the Services by the end of the
 Trial Period, Elestio will use its reasonable endeavors to preserve
 all the information contained in Your user account during the next
 seven (7) days from the expiration date of the Trial Period
 (“Suspension Period”). If within such Suspension Period You do not
 purchase any of Elestio’s Services, You will no longer have access
 to Your deployed services, and all information contained therein
 will be deleted by Elestio.  In other words, please be aware
 that after using the Services during the Trial Period, if You decide
 not to purchase the full version of the Services once the Trial and
 Suspension Periods end, You will not be able to access or retrieve
 any of the data You added/created during the Trial Period.

 Notwithstanding Clauses 11, 12, and 13 concerning liability,
 indemnities, and warranties, which are applicable to all the
 Services, the Trial Version explicitly excludes any kind of
 liability of Elestio.  Elestio does not undertake any
 commitment about the content of the Trial Version, its specific
 functions, its reliability, availability, or ability to meet Your
 needs.  We provide the Services “as is”, and We disregard any
 warranty in relation to it.  Likewise, Elestio will not be
 responsible for lost profits, revenues, or data, financial losses,
 or indirect, special, consequential, exemplary, or punitive damages
 directly or indirectly produced due to the use of the Elestio Trial
 Version.

 2.2. Paid Services and Prices

 All other applications, features, functionality, and support
 provided by Elestio are provided for the fees described as each
 Service on Our Website (“Fees”), and You are liable for such Fees.
  To review Our price table, visit
 http://www.Elest.io/pricing.html.  The values are set in US
 Dollars and exclude VAT which may be applicable.  If You wish
 to receive or use such paid Services, You are required to pay all
 applicable Fees in advance.

 2.3. Taxes

 All Fees posted on Our Website exclude all taxes (including value
 added tax, sales tax, goods and services tax, etc.), levies, or
 duties imposed by taxing authorities (“Taxes”).

 If Elestio is obligated to collect or pay any Taxes for the Fees
 payable by You, such Taxes will be added to the payment of the
 outstanding Fees, and will be reflected in the Invoice for such a
 transaction.

 For example, Elestio is required to collect Value Added Tax of the
 European Union (“EU VAT”) from certain EU customers.
  Therefore, EU VAT shall be charged to these customers, on top
 of Our Fees associated with the Services.

 You shall be responsible for the payment of all applicable Taxes
 relating to Your use of the Services, or to any payments or
 purchases made by you.

3. Contract and Contract Revocation

 3.1. Contract

 A binding contract is initiated between You and Elestio at the time
 You order a Service, and it will be upheld once the payment is
 successfully completed. “Successfully completed” is defined as full
 amount paid, and an invoice is available in Your Elestio account.

 You can opt to upgrade Your service agreement to any other contract
 agreement that Elestio currently offers, at any time during Your
 contract term.  In the event of a contract upgrade, the price
 for the purchase of the new product will be decreased in the amount
 previously paid for the Services in proportion to the remainder of
 Your original contract term.

 3.2. Duration of the Contract

 You may agree to a one (1) month or a one (1) year contract
 agreement with Elestio.

 At the end of the contract term, Your contract will be automatically
 renewed for an additional contract term until explicitly cancelled
 by you.  Cancellation must be issued through Elest.io, going
 into the specific project that You intend to cancel.  Please
 note that as the cancellation process may take some time, in order
 to avoid the next automatic renewal and respective charge, the
 cancellation request should be issued at least one (1) day prior to
 the expiration of the end of the contract term.

 If You cancel the automatic renewal, Elestio will preserve all the
 information contained in Your user account during the next sixty
 (60) days from the date of cancellation (Suspension Period).
  If within such period You do not purchase Elestio’s Services
 once again, You will no longer have access to Your user account, and
 all information contained therein will be deleted by Elestio.

 3.3. Cancellation and Termination

 Cancellation of any Service can be requested at any time through
 Elest.io, by going into Your specific project, as long as You do not
 intend to obtain the refund of paid Fees.

 If You cancel the Service before the expiration of the term of your
 subscription, You can choose from the following options: (i) to keep
 Your User Apps online until the end of the contract term; or (ii) to
 disable or delete Your User Apps at the moment of the cancellation.
  In both cases, the Suspension Period (as defined in 2.1) will
 be applicable, and it will commence at the time the User Apps are
 not available online anymore.  After the Suspension Period, if
 You do not purchase any other Elestio Services, You will no longer
 have access to Your user account, and all information contained
 therein may be deleted by Elestio.  Elestio accepts no
 liability for such deleted information or content.

 As explained in Clause 10 below, Elestio may interrupt/terminate the
 Services under certain conditions.  You agree that any
 termination of Your access to the Service under any provision of
 these Terms may be affected without prior notice.  You
 acknowledge and agree that Elestio may immediately deactivate or
 delete Your User Website, as applicable, and all related information
 and files.  In such a case, the Suspension Period may not be
 applicable. Elestio reserves the right to ban any further access to
 such files or the Service.  You agree that Elestio shall not be
 liable to You, or any third-party, for any termination of Your
 access to the Service.

4. Domain Names

 4.1. Domain Name Registration and Ownership

 If You acquire a domain name through Elest.io You become the lawful
 owner of it.  However, if You decide not to renew said domain,
 Elestio is not responsible for any problems or issues that may occur
 as a result of, or after, the domain's expiration.  Please be
 aware, as well, that if You do not renew the domain, You may lose
 the domain name to another Internet user.

 4.2. Domain Renewal

 The renewal of the domain name may be requested at any time, until
 ten (10) days prior to the expiration date stated in Our Website.
  The expiration date refers to the day that Your domain will
 become invalid, hence will cease to function.  Domain renewal
 is considered paid when the payment date precedes the expiration
 date.  The payment date is set when the payment method provider
 confirms the successful arrival of the payment.  If payment of
 a domain renewal is not timely, the domain falls into quarantine.
  It is possible to redeem the domain from the quarantine, but
 an administrative fee will be charged.

 4.3. Cancellation of Registration

 The domains are the property of whoever acquired them from the
 moment of completion of the purchase and for the full period of the
 purchase; hence it cannot be revoked, and reimbursement is,
 therefore, unfeasible.

5. Payments/Fees and Refunds

 5.1. Method of Payment

 Payments will be processed through Stripe, Our third-party payment
 service provider.  The payment services are governed solely by
 the third-party provider’s terms of service and Privacy Statement that
 You can find at stripe.com.  We are not responsible for the
 actions of the third-party service provider.  If You purchase any
 Services, You agree to Elestio or Our third-party service provider
 storing Your payment card information.  You expressly agree that
 We are authorized to charge You (i) a monthly or yearly fee for any
 applicable Services, billed on a monthly or yearly basis, (ii) any
 other Fees for Services You may have purchased (including, but not
 limited to, the purchase of domain names), and (iii) any applicable
 Taxes in connection with Your use of the Services to the payment card
 You provide, and to reimburse Us for all collection costs and interest
 for any overdue amounts.  If the payment card You provide expires
 and You do not provide new payment-card information, or cancel Your
 account, You authorize Us to continue billing You, and You agree to
 remain responsible for any uncollected Fees.  You are responsible
 to fill in Your information on the payment request.  Please make
 sure that all fields are completed and that all data supplied is
 accurate.  Elestio is not responsible for uncompleted requests
 due to wrong or insufficient information.

 5.2. Invoices

 Elestio will issue an invoice for any payment of Fees (“Invoice”).
  Each Invoice will be issued in electronic form and will be made
 available to You via Your user account and/or by email.  For the
 purpose of issuing the Invoice, You may be required to supply certain
 Personal Information (as such term is defined in the Privacy
 Statement) in order to comply with local laws.  Please note that
 the Invoice presented in Your user account may be inadequate with Your
 local law requirements and, in such case, may be used for pro forma
 purposes only.

 5.3. Recurrent Payment

 The frequency of payment can be monthly or yearly, depending on the
 type of payment that You selected.  For each renewal, the amount
 is charged one (1) day prior to the expiration date of the package.
  Renewal of domain names will be charged ten (10) days prior to
 the expiration date of the specific domain name.  As stated in
 Clause 4.2, the automatic renewal can be cancelled at any time through
 Elest.io.

 5.4. Payment Date and Activation Date

 The payment date is set upon confirmation of successful reception of
 the amount in question by the third-party payment-service provider.
  On the payment date, the Services will be activated.

 5.5. Requests for Refund

 As the Users are able to try the Services for free during the Trial
 Period, Elestio will not refund any purchase, including the automatic
 renewal of Services carried out by recurrent payment.  Likewise,
 it is not possible to refund already-registered domain names.

 If a third party decides to block any User App due to questionable
 content, requesting for a refund will not be possible.  In such a
 case, Elestio is not responsible for the potential financial loss of
 the User.

 5.6. Credit/Debit card refunds (“Chargeback”)

 If, at any time, You contact Your bank or credit/debit card company
 and decline, request refund, or otherwise reject the charge of any
 payable Fees (“Chargeback”), this act will be considered a breach of
 Your payment obligations hereunder, and Your use of the Elestio
 Services may be automatically terminated.

 In the event of a Chargeback related to the payment of Your
 subscription to Our Services, Your user account may be blocked without
 the option to be repurchased or reused.  The User Apps may be
 disabled, and the data contained therein may be immediately deleted.

 In the event of a Chargeback related to payment for purchase or
 renewal of a domain name, Elestio will become the owner of said domain
 name.

 If You have any questions or concerns regarding a payment, We
 encourage You to first contact Our customer support team before filing
 a Chargeback or reversal of payment, in order to prevent the Services
 from being cancelled, for Your user account to be blocked and to avoid
 the filing of an unwarranted or erroneous Chargeback, which may result
 in Your being liable for its applicable fees.

 We reserve Our right to dispute any Chargeback received, including by
 providing the relevant credit card company or financial institution
 with any information and documentation proving that the User
 responsible for such Chargeback did, in fact, authorize the
 transaction, and make use of the services rendered thereafter.

6. Use of the Services

 6.1. Content of User Apps

 You are legally and contractually responsible for all information,
 data, text, software, music, sound, photographs, graphics, videos,
 messages, or other materials uploaded, posted, or stored in connection
 with Your use of the Services.  Elestio is not responsible for
 such content.  You hereby grant Elestio a worldwide,
 royalty-free, non-exclusive license to host and use the content in
 order to provide You with the Services, and hereby represent and
 warrant that You have all the rights necessary to grant Us such
 license.  You are responsible for any content that may be lost or
 unrecoverable through Your use of the Services.  You are
 encouraged to archive Your content regularly and frequently.

 6.2. Acceptable Usage

 “Acceptable Usage” of Elestio’s Website, its contents, and Services is
 defined as any usage that does not contravene the prohibitions set
 forth in the paragraphs "a to "g" below.  Activities that go
 against, or are otherwise forbidden by, these paragraphs are therefore
 in violation of these Terms, and make You liable to disciplinary
 action and legal prosecution.  For more information, please refer
 to Clause 9.

 a) You will not post on, nor distribute through, the User App any
 material that is of defamatory, threatening, obscene, harmful,
 pornographic or otherwise illegal nature.  Also, materials that
 somehow violate or infringe, in any way, on Our rights or on the
 rights of others, (including but not limited to intellectual property
 rights, confidentiality rights, and privacy rights) are absolutely
 forbidden.

 b) You will not post, nor otherwise make available, on User App any
 material which You do not own, without the express consent of the
 lawful owner of the material in question.

 c) You will not engage in any behavior or action that may affect the
 operability or the security of Elestio or User App, nor will You cause
 unreasonable inconvenience or disruption to Our staff.

 d) You will not impersonate any person/entity, nor misrepresent Your
 affiliation with a person/entity.

 e) You will not promote Your User App by sending SPAM (i.e., emails
 sent to accounts without the previous agreement of the account owner).

 f) You will not use robot software (nor any other software that is not
 Elestio) to create new User Apps nor to access nor modify User Apps.

 g) You will not use workarounds of any kind to overcome package
 limitations or limitations of any Elestio service or feature.

 6.3. Selling Through User Apps

 Some of Our Services may offer You the opportunity to sell or purchase
 goods and services through Elestio’s Sites (such goods and services,
 “Commercial Products”).  We are merely providing the platform for
 buyers and sellers to negotiate and complete transactions for these
 Commercial Products.  When a buyer purchases Commercial Products,
 payments will be processed through third-party payment service
 providers.  Buyers of Commercial Products will be provided with a
 notice when entering their payment information directing them to the
 third party payment service provider’s terms of service and Privacy
 Statement.  These payment services are governed solely by the
 third-party provider’s terms of service and Privacy Statement.
  We are not responsible for the actions of these third-party
 service providers.  In addition to the other rules and
 requirements described in these Terms, You must follow the rules
 listed below when offering, selling, or purchasing Commercial
 Products.

 a) You may not offer or sell illegal or potentially illegal Commercial
 Products, including those counterfeit, stolen, or fraudulent.
  Commercial Products sold using the Services must comply with all
 applicable laws.

 b) You may not offer or sell Commercial Products that infringe, or
 have the potential to infringe, the intellectual property rights or
 proprietary rights of another.

 c) You may not offer or sell any Commercial Products that we, in Our
 discretion, determine inappropriate, offensive, pornographic, sexually
 explicit, or violent.

 d) You may not offer or sell any Commercial Products that are
 manufactured as, or primarily intended to be used as, weapons,
 including firearms, restricted devices, or ammunition.  We
 reserve the right to determine, in Our sole discretion, whether
 Commercial Products constitute as “weapons” for purposes of these
 Terms.

 e) You may not offer or sell any Commercial Products that infringe
 upon, or have the potential to infringe upon, an individual’s privacy,
 or that may be libelous, slanderous, or otherwise defamatory.

 f) You may not use images or names of any third party (including
 notable personalities or celebrities) when offering or selling
 Commercial Products, without first obtaining that third party’s
 permission.  We may immediately remove content related to the
 offer or sale of Commercial Products in violation of these Terms, and,
 in such case, Elestio will not be liable for any damages or loss of
 profit incurred by You.  Elestio shall not be liable for any
 taxes or other fees to be paid in accordance with, or related to, the
 Commercial Products.  When purchasing or selling Commercial
 Products, it is Your responsibility to determine whether or not sales
 taxes apply to a transaction, and to collect, report, and remit the
 correct amounts to the appropriate authority.  You take full
 responsibility for all taxes and fees of any nature associated with
 Services, including any sales tax related to the purchase or sale of
 Commercial Products.

7. Newsletter Service

 For the newsletter service provided directly to You by Elestio (the
 “Newsletters Service”), the following terms and conditions also apply.
  If You do not comply with these terms, Elestio may suspend or
 terminate immediately, and without prior consent, your access to, and
 use of, the Newsletters Service.  In such a case, you will not be
 entitled to any compensation or reimbursement from Elestio.

 7.1. Permitted Use

 Your use of the Newsletters Service must comply with all applicable
 domestic and international laws.  This includes the laws
 applicable to You, to Elestio, and all recipients to whom you intend
 to send emails (each, a “Recipient”).  Applicable laws include
 laws relating to spam or unsolicited commercial email (hereinafter
 “Spam” or “UCE”), privacy, security, obscenity, defamation,
 intellectual property, pornography, terrorism, homeland security,
 gambling, child protection, and other applicable laws.  It is
 your responsibility to know and understand the laws applicable to your
 use of the Newsletters Service and emails  generated and sent
 from it.
You agree to use the Newsletters Service in a lawful,
 safe, and professional manner, consistent with industry best
 practices, including keeping reliable records.  You are solely
 responsible for any and all statements you make, and for all user
 assistance, warranty, and support of your products and services.

 7.2. Prohibited Use

 The following practices violate these Terms when generating or sending
 email or messages through the Newsletters Service.
So You shall
 not:

 a) Use the Newsletters Service in violation of Elestio’s Terms of Use
 or of any law applicable to you or your Recipients.

 b) Use the Newsletters Service to send Spam.  An email is Spam
 if: (a) the recipient’s personal identity and context are irrelevant
 because the message is equally applicable to many other potential
 recipients; (b) the recipient has not verifiably granted deliberate,
 explicit and still-revocable permission for it to be sent; and (c) the
 transmission and reception of the message appears to give a
 disproportionate benefit to the sender.  Spam is an issue of
 consent, not content.  A recipient should “affirmatively opt-in,”
 or expressly consent to receiving the message, either in response to a
 clear and conspicuous request, or at the recipient’s own initiative.
  You must ensure that all Recipients have explicitly granted
 permission to receive emails from you by affirmatively opting-in to
 receive those emails.  All emails and messages sent by means of
 the Newsletters Service must comply with our Anti-Spam Policy, as
 outlined below.

 i) Elestio has a no-tolerance Spam policy and does not knowingly do
 business with any user or company that participates in sending
 Spam/UCE.  We do not sell or exchange personal information from
 our opt-in lists.

 ii) Use the Newsletters Service to request, collect, or send any
 non-public or personally identifiable information about another user,
 or any other person, without their express prior-written consent,
 illegal information, or any other information you do not have the
 right to request, collect, or distribute.

 iii) Use the Newsletters Service to send email campaigns that link to
 or display pornography, other sexually explicit content, illegal goods
 or services, or any other Content that Elestio deems inappropriate.

 iv) Transmit any message, information, data, text, software, image, or
 other content that is not owned by you or legally licensed to you, or
 is unlawful, harmful, threatening, abusive, harassing, defamatory,
 vulgar, obscene, libelous, or otherwise objectionable, which may
 violate another’s right of privacy or publicity.

 v) Send through the Newsletters Service any unethical, false, or
 misleading advertising, promotions, or sales efforts and practices.

 vi) Post or transmit any material that contains a virus or corrupted
 data.

 vii) Use purchased or rented email lists.

 viii) Use third party email addresses, domain names, or mail servers
 without proper permission.

 ix) Send emails to non-specific addresses or distribution lists,
 newsgroups, publicly available press, media addresses, or purchased
 email addresses.

 x) Send emails that result in an unacceptable number of Spam or UCE
 complaints (even if the emails themselves were not actually Spam or
 UCE).

 xi) Disable or fail to include a working “unsubscribe” link in every
 email, which allows the Recipient/s to remove themselves from your
 mailing list.

 xii) Disable or fail to comply with any request from a recipient to be
 removed from your mailing list within seven (7) calendar days of
 receipt of the request.  You cannot charge a fee, require the
 recipient to give you any personally identifiable information beyond
 an email address, or make the recipient take any step other than
 sending a reply email or visiting a single page on an Internet website
 as a condition for honoring an unsubscribe request.

 xiii) Disguise the origin or subject matter of any email, or falsify
 or manipulate the originating email address, subject line, headers, or
 transmission path information for any email.

 xiv) Include “junk mail”, “chain letters”, “pyramid schemes”,
 incentives (e.g., coupons, discounts, awards, or other incentives), or
 other material in any email that encourages a Recipient to forward the
 email to another recipient.

 xv) Fail to comply with export and import regulations.

 xvi) Copying any part of the Elestio marketing website, dashboard, or services is strictly prohibited. Violations of this rule will result in the immediate suspension of your account without a refund.

 7.3. Exclusion of Liability

 You are solely responsible for your products and services, and any
 other promotion and content contained in, or referred to in, your
 emails sent through the Newsletters Service.  It is your
 responsibility to ensure that the Content you put in your emails does
 not violate these guidelines.  Elestio has no obligation to do so
 but may monitor your account to ensure compliance with these Terms and
 operation within the acceptable industry standards.  In our sole
 discretion, we reserve the right to block emails, remove Content, or
 prohibit use of the Newsletters Service that may be in violation of
 the foregoing or of the Terms.  In no case will the foregoing
 make us responsible or liable to You or for compliance with any such
 laws or obligations, for which you remain solely responsible and
 liable.

8. Client Apps

 You are allowed to use Elestio’s Services to create websites and
 mobile applications (“Client Apps”) for third parties (Your
 “Clients”).  In particular, Elestio's Business Plans are designed
 for freelancers, web agencies, corporations, etc. to create multiple
 websites for them or for their Clients.

 If you use Elestio’s Services to create Client Apps, your use of the
 Service shall be subject to these additional terms:

 a) Your relationship with your Client is strictly between you and the
 Client.  We will not be a party to any agreement you have with
 your Client.  The manner and means in which You choose to perform
 and charge fees for Your services are in Your sole discretion and
 control.  However, you agree to perform these services in a
 professional manner, consistent with industry practice, and in
 accordance with these Terms.  Services rendered by You through
 Client Apps shall not damage the good reputation of Elestio.

 b) You accept full responsibility for all Client Apps under your
 account, and for each Client Apps’ adherence to these Terms.

 c) While subscribed to the Business Plans we intend to allow you to
 resell the service under a white label, this white label is in no way
 guaranteed, and we will in no way be held responsible for any failure
 to maintain it.

 d) In the event your Client contacts us, we will direct them to you.
  Should you fail to support your Client, and we receive a request
 from your Client stating that you have not been responsive, we reserve
 the right to support your Client directly.

 e) You understand and agree that You are responsible to Elestio for
 payment or every Client App under your account.  If, at any time,
 your billing obligations are not met, we will have the right to
 disable all Client Apps until such billing obligations are met.
  In the event of Us disabling Your Client Apps due to a breach of
 payment obligations, You will be the sole responsible for any damage
 caused to Your Client.

9. Intellectual Property

 All copyright materials, trademarks, and other intellectual property,
 rights, materials, or contents supplied as part of User App shall
 remain, at all times, vested in Us or Our licensors.  You are not
 permitted to use this material or content unless authorized by Us.
  Moreover, You are only allowed to use such material in the
 manner described in the Terms, and no other.  You will not copy,
 reproduce, distribute, commercially exploit, nor, in any form,
 benefit/profit from such materials or contents.  Nor will You
 assist/facilitate any third party in actions such as the ones
 mentioned above.  Moreover, if You become aware of any such
 distribution or commercial exploitation, You agree to notify Us
 immediately.

 Elestio does not claim ownership of your content, but You give Us your
 permission to host Your content in order to provide the Services.
  This permission exists only for as long as You continue to use
 the Services.

10. Privacy

 10.1. Privacy Statement

 We encourage You to read the Privacy Statement.  Please note that
 certain information, statements, data, and content (such as
 photographs) which You post to the User App are likely to reveal Your
 gender, ethnic origin, nationality, age, and/or other personal
 information.  You acknowledge and agree that Your submission of
 such information is voluntary on Your part.  Furthermore, You
 acknowledge, consent, and agree that We may access, preserve, and
 disclose Your information if required to do so by law, or in a good
 faith belief that such access, preservation, or disclosure is
 reasonably necessary in Our opinion. Disclosures of user information
 to third parties are further addressed in the Privacy Statement.

 10.2. Registration

 In order to use Our services and products, You must be a
 validly-registered Elestio user.  To register, You must provide a
 valid email address, a password, and other personal information (“User
 Information”).

 You, solely, are responsible for the confidentiality of Your password
 and account.  All activity originated from Your account and/or
 password is Your responsibility.  We strongly suggest that You
 keep Your password and account information strictly confidential, and
 not shared with anyone.  In case of unauthorized use of Your
 password and/or account, immediately notify Elestio in writing from
 the email address associated with your registration.

 We strongly recommend the permanent update of all User Information,
 since this data is used in customer-care services.

 The owner of a user account may be considered as the person or entity
 with access to the email address listed in Elestio’s records for said
 user account.  If any paid Services were procured via the user
 account, the owner of said user account may be considered as the
 person or entity whose billing details were used to purchase said paid
 Services.

 10.3. Data Processing

 You may be asked to enter on Our website information about Yourself.
  However, We will not use that information in any other manner
 than the one expressed where the request was made.  Furthermore,
 all User Information collected is processed in the manner, and with
 the limitations, stated in Our Privacy Statement.

 We shall abide by all applicable country-specific data protection
 legislation regarding any of Your personal information gathered by Us.

 10.4. Hosting

 Elestio infrastructure is hosted on Amazon AWS in Dublin,
 Ireland. 

 11. Violation of Our Terms

 Failure to comply with the conditions stated on Clause 6 and/or
 participation in activities that go against, or are otherwise
 forbidden by, these Terms make You liable to disciplinary action and
 legal prosecution.  The decision to initiate disciplinary action
 (including, but not being limited to, interruption of all Services)
 falls under the discretion of Elestio.  Please report infractions
 of these Terms or of Your local laws.

12. Interruption/Termination of Services

 Should You breach, or We have reasonable grounds to believe that You
 are likely to breach, Our Terms and Conditions, We reserve the right
 to immediately terminate or indefinitely suspend Our services to You.
  We will, as well, terminate Our services to You, at Our sole
 discretion, if You engage in a conduct which We determine to be
 unacceptable.

 In such a case, you will not be entitled to any compensation or
 reimbursement from Elestio.

13. Disclaimer

 We are not responsible for damages to users, or to third parties, or
 to their hardware, that occur directly, indirectly, or accidentally,
 as a result of, or in connection to, the use of Our Services.

 We are not liable for damages to users or to third parties as a result
 of the inability to use Our Services, and/or Website, nor in direct or
 indirect connection with this fact.  Therefore, Your use of the
 Services is done at Your own discretion and risk, and You are solely
 responsible for any damage to Your computer system or other device, or
 loss of data, that results from the use of any such materials.

 You expressly admit to understanding and agreeing that Your use of Our
 Website and Our Services is done “as is” and “as available”.  You
 further acknowledge and agree that We are not responsible for the
 availability and/or functionality of any third-party’s website and/or
 material You may access through Our Website.

 13.1.Third Parties

 We do not endorse and shall not be held responsible nor liable for any
 content, advertising, product, or service on, or available through,
 third-party websites.

 Any transactions between You and any third party found on or via the
 User App, including payment for, and delivery of, products, services,
 and any other terms, conditions, warranties, or representations
 associated with such dealings, are made between You and the entity in
 question.  We are, therefore, neither responsible nor liable for
 any loss/damage of any sort, incurred in such dealings.

 13.2. Exclusion of Warranty

 Elestio does not represent nor warrant to You that:

 a) Your use of the Services will meet Your requirements.

 b) Your use of the Services will be uninterrupted, timely, secure, or
 free from error, or viruses.

 c) Any information obtained by You as a result of Your use of the
 services will be accurate or reliable.

 d) Defects in the operation or functionality of any software provided
 to You as part of the Services will be corrected.

 No advice or information, whether verbal or written, obtained by You
 from Elestio, through or from Our services shall create any warranty
 not expressly stated in the Terms.

 Elestio further expressly disclaims all warranties and conditions of
 any kind, whether expressed or implied, including, but not limited to,
 the implied warranties and conditions of merchantability, fitness for
 a particular purpose, and non-infringement.

14. Limitation of Liability

 Subject to overall provision in the disclaimer above (Clause 13), You
 expressly admit to understanding and agreeing that Elestio shall not
 be liable to You for the events set forth on Clauses 14.1 to 14.3
 below.

 14.1. General

 Any direct, indirect, incidental, special, consequential, or exemplary
 damages which may be incurred by You, however caused, and under any
 theory of liability.  This shall include, but not be limited to,
 any loss of profit (whether incurred directly or indirectly), any loss
 of goodwill or business reputation, any loss of data suffered, cost of
 procurement of substitute goods or services, or other intangible loss.

 Any loss or damage which may be incurred by You, including, but not
 limited to, loss or damage as a result of:

 a) Any changes which Elestio may make to the Services, or for any
 permanent or temporary cessation in the provision of the Services (or
 any features within the Services).

 b) Deletion of, corruption of, or failure to store any content and
 other communications, data maintained or transmitted by or through
 Your use of the Services.

 c) Your failure to provide Elestio with accurate account information.

 d) Your failure to keep Your password or account details secure and
 confidential.

 e) The unavailability of the Services.

 f) Hosting issues that, result in the unavailability of, or otherwise
 impact your, website, app, newsletter, project, or otherwise.

 g) Failure to notify you of any hosting or other issues that may
 impact the Services or any website, app, newsletter, project, or
 otherwise, for which you use the Services.

 The limitations on Elestio’s liability to You in Clause 14.1 above
 shall apply whether or not Elestio has been advised of, or should have
 been aware of, the possibility of any such losses arising.  Also,
 limitations which are lawful in Your jurisdiction will apply to You.

 14.2. Information Provided on User Apps

 We are not responsible for, nor will We be liable to:

 a) Materials written by Users, particularly those posted on blogs
 and/or forums.  In addition, We do not endorse such materials,
 and reserve the right to monitor such contributions, as well as, to
 respond, comment, edit, refuse to post, or remove any content from
 blogs and/or forums at Our absolute discretion.  However, failure
 to remove particular material does not constitute in an endorsement or
 acceptance of it by Us.

 b) The accuracy, timing, or reliability of any information/statement
 on User App.  Nor will We be held accountable/liable for
 statements, advice, and/or opinions generated by Users on blogs and
 forums.  If You have any claim arising from the actions and/or
 statements of another User, You agree to pursue such a claim only
 against that User, and not against Us.

 c) The quality, accuracy, or fitness of User App, except to what is
 required by law.  However, We will engage in all reasonable
 efforts to provide Our services in the most professional manner.

 d) Any fraudulent misrepresentations We make, and for any death or
 personal injury caused by Our negligence.  We will not be
 responsible nor liable to You for any other loss/damage that You or
 any Third Party may be the subject of as a result of using, or in
 connection with, Your use of User App.

15. Exclusive Remedy

 In the event of any problem with Our Website or Our Services, You
 agree that Your sole and exclusive remedy is to cease using the
 Website and the Services. Under no circumstances shall Elestio be
 liable in any way for Your use of Our Website, the Services, the User
 Apps, the Commercial Products or third party generated content
 available on or though the Website, including, but not limited to, any
 error, omissions, any infringement of the intellectual property rights
 or other rights of third parties, or for any loss or damage of any
 kind incurred as a result of, or related to, the use of Our Website,
 the Services, Your content, the Commercial Products or any third party
 generated content available on or through the Website.

 Certain states and/or jurisdictions do not allow the exclusion of
 implied warranties or limitation of liability for incidental or
 consequential damages, so the exclusions set forth above may not apply
 to you.

16. Indemnification

 You agree to indemnify, hold harmless, and defend Elestio and its
 licensors, suppliers, officers, directors, employees, agents,
 affiliates, subsidiaries, successors, and assigns (collectively
 "Indemnified Parties") from and against any and all liability, loss,
 claim, damages, expense, or costs (including, but not limited to,
 attorneys' fees), incurred by, or made against, the Indemnified
 Parties in connection with any claim arising from, or related to; (i)
 Your use [or anyone using Your account's] use of the Services or Our
 Site, (ii) the content of the User App or (iii) any Commercial
 Products You offer on or through the User App or using Our Services.
  This includes, but is not limited to, any breach or violation of
 these Terms by You or anyone utilizing Your account.  You agree
 to fully cooperate at Your expense, as reasonably required by an
 Indemnified Party.  Each Indemnified Party may, at its election,
 assume the defense and control of any matter for which it is
 indemnified hereunder.  You shall not settle any matter involving
 an Indemnified Party without the consent of the applicable Indemnified
 Party.

17. Miscellaneous

 17.1. Changes & Updates

 The quality of Our services and products is the main focus of
 Elestio's attention; hence, Our system is subject to a continuous
 improvement process, both, on the technological, and design aspects of
 the product.  Therefore, Elestio may change, suspend, or
 terminate any of the Services (or any features thereof, or prices
 applicable thereto), and/or change any of the Terms - at any time, and
 in any way.  Such changes will not be applied in a retroactive
 manner, except as required otherwise by law.

 If any such changes involve the payment of additional Fees, We will
 provide You with a notice of such Fees prior to enabling such specific
 changes.  If You fail or refuse to pay such Fees, We may (at Our
 sole discretion) (i) cancel Your user account, (ii) continue to
 support Your then-current Services without enabling such changes, or
 (iii) provide You with alternative Services.

17.2. Governing Law & Jurisdiction

 The Terms, the rights, and remedies provided hereunder, and any and
 all claims and disputes related hereto and/or to the Services, their
 interpretation, or the breach, termination, or validity thereof, the
 relationships which result from, or pursuant to, the Terms, or any
 related transaction or purchase, shall be governed by, construed
 under, and enforced in all respects, solely and exclusively in
 accordance with the internal substantive laws of the Republic of
 Ireland, without respect to its conflict of laws principles.

 Any and all such claims and disputes shall be brought in, and You
 hereby consent to them being decided exclusively by a court of
 competent jurisdiction located in Dublin, Ireland.

 17.3. Notices

 We may provide You with notices in any of the following methods: (i)
 via the Elestio Services, including by a banner or pop-up within the
 Elestio Website, user account, or elsewhere; (ii) by email sent to the
 email address You provided us; and/or (iii) through any other means,
 including any phone number or physical address You provided Us.
  Elestio’s notice to You will be deemed received and effective
 within twenty-four (24) hours after it was published or sent through
 any of the foregoing methods, unless otherwise indicated in the
 notice.

 17.4. Relationship

 The Terms, and Your use of the Services, do not, and shall not be
 construed to create any partnership, joint venture, employer-employee,
 agency, or franchisor-franchisee relationship between Elestio and You.

 17.5. Entire agreement

 These Terms, together with any documents herein mentioned, and any
 other legal or fee notices provided to You by Elestio, shall
 constitute the entire agreement between You and Elestio concerning the
 subject matter hereof or thereof, and supersede any and all prior or
 contemporaneous agreements, understandings, promises, conditions,
 negotiations, covenants, or representations, whether written or oral,
 between Elestio and You, including those made by or between any of Our
 respective representatives, with respect to any of the Services.
  You further agree that You are not relying upon any promise,
 inducement, representation, statement, disclosure, or duty of
 disclosure of Elestio in entering into any of the Terms.

 17.6. Assignment

 Elestio may assign its rights and/or obligations hereunder, and/or
 transfer ownership rights and title in the Services to a third party
 without Your consent or prior notice to you.  You may not assign
 or transfer any of Your rights and obligations hereunder without the
 prior written consent of Elestio.  Any attempted or actual
 assignment thereof, without Elestio’s prior explicit and written
 consent, will be null and void.

 17.7. Severability & Waivers

 If any provision of the Terms is deemed by a court of competent
 jurisdiction to be invalid, unlawful, void, or, for any reason,
 unenforceable, then such provision shall be deemed severable, and will
 not affect the validity and enforceability of the remaining
 provisions.  No waiver of any breach or default of any of the
 Terms shall be deemed to be a waiver of any preceding, subsequent
 breach, or default.

 17.8. Discontinuation

 In case of a discontinuation of Elestio's activities, Elestio will
 make sure to provide all its clients a complete backup and Runtime
 version they can install on their own server so as to host said
 websites.

 17.9. Contact

 To contact Elestio’s Customer Service team, please use any of the
 options listed below:
a) Visit the Elestio Help Centre available
 at: https://docs.elest.io
b) Send an email to: [email protected] 

Last modification date: 2024-07-28 12:04

 The managed DevOps platform. Deploy 400+ open-source tools on any cloud. We handle the rest.

 ISO 27001 
 SOC2 
 HIPAA 
 GDPR 

#### Services 

 Databases 

 Applications 

 Dev Tools 

 Hosting 

 All Services 

#### Platform 

 Pricing 

 CI/CD 

 AI Skills 

 Terraform 

 Use Cases 

 API 

#### Company 

 What is Elestio? 

 About 

 Press Kit 

 Blog 

 Security 

 Status 

 Support 

#### Resources 

 Documentation 

 Use Cases 

 Community 

 Terms of Service 

 Enterprise Support 

 Contact 

#### Compare 

 Elestio vs Heroku 

 Elestio vs Railway 

 Elestio vs Render 

 Elestio vs Self-Hosting 

 Elestio vs Coolify 

 © 2026 Elestio. All rights reserved. 
 29 Merrion Square, Dublin 2, D02 RW64, Ireland 

### We use cookies 
 This website uses technologies such as cookies to enable essential site functionality, as well as for analytics and personalization. Learn more in our Privacy Policy .

 Accept 
 Decline