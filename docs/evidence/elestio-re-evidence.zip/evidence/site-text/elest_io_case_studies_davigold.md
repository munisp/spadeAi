https://elest.io/case-studies/davigold

All success stories Customer success story

# Automating secure, per-client infrastructure with AI agents on Elestio Software editor for investment funds · Per-client isolation

## What agent-driven provisioning changed Every new investment fund client gets a complete, isolated stack, created and configured without manual work.

 0 open ports
 Every environment behind a Cloudflare Zero Trust tunnel

 1 stack per client
 Front end, back end, MSSQL, ClickHouse and Redis, isolated

 Fully automated
 Projects created and deployed by AI agents through the MCP

## Who is Davigold Davigold is a software editor for the investment fund industry. Its platform helps investment funds manage and automate their capital calls and related fund operations, working with multiple funds that each manage several billion dollars in assets.
 For every fund it onboards, Davigold provisions a dedicated, fully isolated environment. The clients handle highly sensitive financial data, so strict isolation and security per client are core requirements of the product.

## The challenge: a secure, isolated stack for every client For each investment fund, Davigold needs to stand up a complete stack, isolated per client and reachable only through tightly controlled access. Provisioning this by hand for every new fund would be slow, repetitive, error prone, and a permanent drain on engineering time. Davigold needed the whole process to be automatic, repeatable, and secure by default.

## The solution: AI agents that deploy through the Elestio MCP Davigold drives its provisioning with AI agents connected to Elestio through the Elestio MCP (Model Context Protocol). Instead of an engineer working through a console, Davigold simply instructs its agent to deploy a new infrastructure for a new client. The agent, through the MCP, connects to the Elestio API and handles everything end to end. The same operations are also available through Elestio's REST API.

Creates a new dedicated Elestio project for the fund

Deploys the full stack: front end, back end, MSSQL, ClickHouse and Redis

Configures the networking and security automatically

Places every environment behind a Cloudflare Zero Trust tunnel, with all inbound ports closed

## Secured by default: Cloudflare Zero Trust, no open ports Every client environment is automatically placed behind a Cloudflare reverse tunnel with Zero Trust. This lets Davigold close all inbound ports on the VM, so the machine exposes no public attack surface at all. Access flows only through the authenticated Cloudflare tunnel, and the AI agent configures this automatically through the MCP, as part of the same provisioning motion.

## What Davigold runs on Elestio CI/CD delivery
 GitHub pipelines with automatic rebuild and redeploy of the right branch on every build

 Databases
 MSSQL, PostgreSQL, ClickHouse, Redis

 Monitoring
 Uptime Kuma

 Secure access
 Self-hosted VPN for team access, Guacamole bastion host

 File exchange
 SFTPGo to provision SFTP accounts shared with clients

 AI agents
 GetATeam instances

## Why it matters For Davigold, Elestio turns per-client infrastructure, normally a heavy, repetitive and security-critical task, into a single agent instruction. New funds are onboarded faster, every environment is isolated and secured by default, and Davigold's engineers stay focused on their product rather than on provisioning and hardening servers.

### Automate your infrastructure with agents Deploy isolated, secured stacks through the Elestio MCP and REST API.

 Talk to an expert Deploy now