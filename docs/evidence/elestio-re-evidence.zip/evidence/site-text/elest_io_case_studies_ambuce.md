https://elest.io/case-studies/ambuce

All success stories Ambuce Rescue Team Customer success story

# Keeping analytics in Europe, without running the infrastructure Medical transport and assistance · Belgium · Metabase on Elestio

## What changed after moving to Elestio Same Metabase, same dashboards, same data. Everything underneath it now sits with a certified provider.

 12h → 0h
 Team hours on infrastructure, every month

 Zero
 SSL-related outages since the move

 100% EU
 Data and infrastructure, inside a certified audit scope

 Ambuce Rescue Team is one of Belgium's leading providers of urgent and non-urgent patient transport and medical assistance, with more than 200 ambulances, 600 employees and over 200,000 patient transports each year. Metabase gives its teams the visualisation and analytics they need to understand what is happening across the business.

## The problem was not Metabase. It was everything underneath it. Ambuce wanted to continue using Metabase. What had become increasingly difficult to justify was the operational responsibility that came with self-hosting it: server maintenance, software updates, CVE and security patches, backups, monitoring, and responding when something went wrong.
 Keeping the infrastructure running was consuming an average of 12 hours a month of the team's time, engineering time that could be better spent elsewhere, and there was real downtime to show for it, notably around SSL certificate renewals.
 As an NIS2 essential entity, Ambuce also needed that maintenance work carried out by a dedicated, certified resource within its audit scope, a requirement that mattered just as much as the hours saved.

 Metabase offers its own managed cloud. For Ambuce, it did not meet the one requirement that mattered most: the data had to stay in Europe.

## Why the obvious option was ruled out As a Belgian medical assistance provider, Ambuce wanted its analytics infrastructure and data to remain in Europe, under European data protection law, while working with a managed service provider that could meet its security and compliance requirements.
 That led Ambuce to Elestio: the same open-source Metabase they had already chosen, now fully managed and hosted on Hetzner, within the EU.

## What changed 
 Self-hosted
 12 hours a month of engineering time on maintenance
 Downtime around SSL certificate renewals
 Patching handled by an external freelancer
 Server, updates, backups and monitoring on the team

 Managed on Elestio
 Effectively zero hours a month
 SSL-related downtime gone entirely
 Inside a certified supplier audit scope
 Same Metabase, same dashboards, same data

## What Elestio took over Ambuce retains Metabase itself, its dashboards, questions, users and data. Elestio keeps the environment underneath it operational.

Server management, operating system and software updates

CVE and security patching

Daily backups and 24/7 monitoring

ISO 27001 certified and SOC 2 Type II examined, operating under GDPR with customer data in the EEA

## The result Since moving to Elestio, the 12 hours a month Ambuce's team used to spend on maintenance has effectively gone to zero, and the SSL-related downtime has disappeared entirely.
 Ambuce continues to run the analytics technology it chose in the first place, on infrastructure it no longer has to manage, in a location it chose, and with server maintenance, patching and backups now sitting within a certified supplier's audit scope rather than an external freelancer's.

### Keep your analytics in Europe Managed open-source Metabase, hosted where you choose, patched and backed up by a certified provider.
 Talk to an expert Deploy now