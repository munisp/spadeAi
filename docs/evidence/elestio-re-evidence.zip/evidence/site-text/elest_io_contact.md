https://elest.io/contact

Contact Elestio | Support for Managed Open-Source Hosting 

 Managed services ▾ 

 Databases 
 PostgreSQL, MySQL, Redis, MongoDB & more 

 Applications 
 n8n, WordPress, Supabase, Keycloak & more 

 Development 
 CI/CD tools, IDE, Git hosting & version control 

 Hosting & Infrastructure 
 Servers, containers, monitoring & storage 

 AI & GPU 
 LLMs, AI frameworks, GPU-powered inference tools 

 View all 400+ services → 

 Features ▾ 

 Domains 
 Custom domains & SSL for your services 

 CI/CD 
 Automated deployment pipelines 

 Terraform 
 Infrastructure as code provider 

 Clusters 
 High availability & multi-node scaling 

 AI ▾ 

 AI DevOps 
 Describe an issue, AI fixes your server 

 Agents 
 Deploy with AI coding agents 

 AI & Automation 
 Automate your infrastructure workflows 

 Vibecoder 
 AI-powered app development & deployment 

 Resources ▾ 

 Documentation 
 Guides, API reference & tutorials 

 Blog 
 Product news, engineering & updates 

 Use Cases 
 Real customer success stories 

 Community 
 Join the discussion on Discord 

 Pricing 

 Login 
 Get Started 

 Managed services ▾

 Databases 
 Applications 
 Development 
 Hosting & Infrastructure 
 AI & GPU 
 All Services 

 Features ▾

 Domains 
 CI/CD 
 Terraform 
 Clusters 

 AI ▾

 AI DevOps 
 Agents 
 AI & Automation 
 Vibecoder 

 Resources ▾

 Documentation 
 Blog 
 Use Cases 
 Community 

 Pricing 
 Documentation 

 Login 
 Get Started 

 Contact 

# Get in Touch 
 Have questions about Elestio? Whether you need technical support, want to discuss enterprise solutions, or explore a partnership, our team is here to help.

### Technical Support 
 Expert help from real engineers. Every support request is handled by humans, not chatbots.

 Create a ticket → 

### Email Us 
 For general inquiries, sales questions, and partnership opportunities.

 [email protected] → 

### Documentation 
 Guides, tutorials, API references, and deployment documentation.

 Browse docs → 

### Community Discord 
 Chat with our team and community members. Get quick answers and share ideas.

 Join Discord → 

 Support Plans 

## Expert support at every level 
 Every Elestio service includes free Level 1 support with real human engineers. Upgrade for faster response times and SLA guarantees.

 Level 1

 Free

 Included with every service

 ✓ Email support

 ✓ Human engineers (no chatbots)

 ✓ Daily automated backups

 Popular

 Level 2

 $50 /mo 

 Per service

 ✓ 24h response time

 ✓ 99.5% uptime SLA

 ✓ 14-day backup retention

 Level 3

 $200 /mo 

 Per service

 ✓ 4h response time

 ✓ 99.9% uptime SLA

 ✓ 30-day backup retention

 ✓ Dedicated Customer Success Manager

 Office 

## Our registered office 

 Dublin, Ireland 

 29 Merrion Square
Dublin 2, D02 RW64
Ireland, Europe

## Ready to get started? 
 Deploy your first managed open-source service in just a few minutes. Free 3-day trial included.

 Start free trial 

 The managed DevOps platform. Deploy 400+ open-source tools on any cloud. We handle the rest.

 ISO 27001 
 SOC2 
 HIPAA 
 GDPR 

#### Services 

 Databases 

 Applications 

 Dev Tools 

 Hosting 

 All Services 

#### Platform 

 Pricing 

 CI/CD 

 AI Skills 

 Terraform 

 Use Cases 

 API 

#### Company 

 What is Elestio? 

 About 

 Press Kit 

 Blog 

 Security 

 Status 

 Support 

#### Resources 

 Documentation 

 Use Cases 

 Community 

 Terms of Service 

 Enterprise Support 

 Contact 

#### Compare 

 Elestio vs Heroku 

 Elestio vs Railway 

 Elestio vs Render 

 Elestio vs Self-Hosting 

 Elestio vs Coolify 

 © 2026 Elestio. All rights reserved. 
 29 Merrion Square, Dublin 2, D02 RW64, Ireland 

### We use cookies 
 This website uses technologies such as cookies to enable essential site functionality, as well as for analytics and personalization. Learn more in our Privacy Policy .

 Accept 
 Decline