https://elest.io/about

About Elestio | Managed DevOps for Open-Source 

 Managed services ▾ 

 Databases 
 PostgreSQL, MySQL, Redis, MongoDB & more 

 Applications 
 n8n, WordPress, Supabase, Keycloak & more 

 Development 
 CI/CD tools, IDE, Git hosting & version control 

 Hosting & Infrastructure 
 Servers, containers, monitoring & storage 

 AI & GPU 
 LLMs, AI frameworks, GPU-powered inference tools 

 View all 400+ services → 

 Features ▾ 

 Domains 
 Custom domains & SSL for your services 

 CI/CD 
 Automated deployment pipelines 

 Terraform 
 Infrastructure as code provider 

 Clusters 
 High availability & multi-node scaling 

 AI ▾ 

 AI DevOps 
 Describe an issue, AI fixes your server 

 Agents 
 Deploy with AI coding agents 

 AI & Automation 
 Automate your infrastructure workflows 

 Vibecoder 
 AI-powered app development & deployment 

 Resources ▾ 

 Documentation 
 Guides, API reference & tutorials 

 Blog 
 Product news, engineering & updates 

 Use Cases 
 Real customer success stories 

 Community 
 Join the discussion on Discord 

 Pricing 

 Login 
 Get Started 

 Managed services ▾

 Databases 
 Applications 
 Development 
 Hosting & Infrastructure 
 AI & GPU 
 All Services 

 Features ▾

 Domains 
 CI/CD 
 Terraform 
 Clusters 

 AI ▾

 AI DevOps 
 Agents 
 AI & Automation 
 Vibecoder 

 Resources ▾

 Documentation 
 Blog 
 Use Cases 
 Community 

 Pricing 
 Documentation 

 Login 
 Get Started 

 About 

# About Elestio 
 Founded in Dublin in 2022, Elestio is a fully managed DevOps platform for open-source software. Our team deploys and manages 400+ tools across 9 cloud providers in 100+ regions worldwide.

 OUR STORY

 Elestio was originally built by our founding technical team as an internal tool to manage thousands of virtual machines running open-source software in production environments used by millions of users, Fortune 100 companies, as well as startups, web agencies, and freelancers. Our proven team has been developing and refining Elestio's core technology for over 15 years, deploying and maintaining over 12,000 production services.

 WHAT DRIVES US

## Our mission 
 Improve the open-source ecosystem by providing fully managed services for a large catalog of curated software, contributing to OSS projects, and also creating a recurring revenue for OSS authors.

### Simplicity 
 If maintaining open-source software is your passion, you should probably consider joining our team. For the rest of us, there's Elestio: we make open-source software simple and safe.

### Community 
 We can only exist inside a vibrant open-source community of high-quality, well maintained software. We do our part to contribute via our revenue sharing program and codebase contributions.

### Empowerment 
 We empower users with choice: Choose your software, hosting provider, region, and enjoy simple, transparent, and predictable pricing. No more surprise bills, no more feature barriers.

 THE PEOPLE

## Our leadership team 
 Headquartered in Dublin, Ireland. Fully remote since day one, spanning 8+ countries. Meet the people leading Elestio.

 Joseph Benguira 

 Chief Technology Officer / CO-FOUNDER

 Kieran Conlon 

 Chief Executive Officer / CO-FOUNDER

 David Alimi 

 Chief Product Officer / CO-FOUNDER

 Joseph Amsellem 

 Chief AI Engineer

 Steven Betito 

 Chief Operating Officer / DPO

 Johnathan Sheehan 

 Director of Sales

 Amit Shukla 

 Chief Infrastructure Officer

 Thomas Legall 

 Chief Support Engineer

 Agnes Mazureck 

 Chief Design Officer

 Wassim Samad 

 Chief DevRel

 & more

 team members

 worldwide

 OUR STACK

## Built on open source 
 Elestio is used to manage the software and services we use in production

### MinIO 
 MinIO offers high-performance, S3 compatible object storage.

### ClickHouse 
 ClickHouse is a high performance columnar OLAP database management system for real-time analytics using SQL

### Redis 
 Data stored in Redis can be in any form and size. Redis is binary-safe so it can store any data.

### Uptime Kuma 
 Uptime Kuma monitors our production services, ensuring we're alerted immediately in case of issues.

## Elestio supports open source 
 We share revenue with open-source authors participating in our program. This is a win-win to us. Open-source developers and communities get more resources to improve their softwares and our customers, staff and other stakeholders know that they are helping to support something really positive. The goal is to create a sustainable ecosystem where open-source authors can focus on improving their software without any DevOps responsibilities, and without going into B2B/SaaS business models.

## Join our team 
 If you love six-sigma uptime metrics, building bullet-proof DevOps automations, and working with world-class peers on a win-win-win product, get in touch!

 Apply here 

 The managed DevOps platform. Deploy 400+ open-source tools on any cloud. We handle the rest.

 ISO 27001 
 SOC2 
 HIPAA 
 GDPR 

#### Services 

 Databases 

 Applications 

 Dev Tools 

 Hosting 

 All Services 

#### Platform 

 Pricing 

 CI/CD 

 AI Skills 

 Terraform 

 Use Cases 

 API 

#### Company 

 What is Elestio? 

 About 

 Press Kit 

 Blog 

 Security 

 Status 

 Support 

#### Resources 

 Documentation 

 Use Cases 

 Community 

 Terms of Service 

 Enterprise Support 

 Contact 

#### Compare 

 Elestio vs Heroku 

 Elestio vs Railway 

 Elestio vs Render 

 Elestio vs Self-Hosting 

 Elestio vs Coolify 

 © 2026 Elestio. All rights reserved. 
 29 Merrion Square, Dublin 2, D02 RW64, Ireland 

### We use cookies 
 This website uses technologies such as cookies to enable essential site functionality, as well as for analytics and personalization. Learn more in our Privacy Policy .

 Accept 
 Decline