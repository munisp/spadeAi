https://elest.io/get-started

Get Started | Deploy in 3 Minutes | Elestio 

 Managed services ▾ 

 Databases 
 PostgreSQL, MySQL, Redis, MongoDB & more 

 Applications 
 n8n, WordPress, Supabase, Keycloak & more 

 Development 
 CI/CD tools, IDE, Git hosting & version control 

 Hosting & Infrastructure 
 Servers, containers, monitoring & storage 

 AI & GPU 
 LLMs, AI frameworks, GPU-powered inference tools 

 View all 400+ services → 

 Features ▾ 

 Domains 
 Custom domains & SSL for your services 

 CI/CD 
 Automated deployment pipelines 

 Terraform 
 Infrastructure as code provider 

 Clusters 
 High availability & multi-node scaling 

 AI ▾ 

 AI DevOps 
 Describe an issue, AI fixes your server 

 Agents 
 Deploy with AI coding agents 

 AI & Automation 
 Automate your infrastructure workflows 

 Vibecoder 
 AI-powered app development & deployment 

 Resources ▾ 

 Documentation 
 Guides, API reference & tutorials 

 Blog 
 Product news, engineering & updates 

 Use Cases 
 Real customer success stories 

 Community 
 Join the discussion on Discord 

 Pricing 

 Login 
 Get Started 

 Managed services ▾

 Databases 
 Applications 
 Development 
 Hosting & Infrastructure 
 AI & GPU 
 All Services 

 Features ▾

 Domains 
 CI/CD 
 Terraform 
 Clusters 

 AI ▾

 AI DevOps 
 Agents 
 AI & Automation 
 Vibecoder 

 Resources ▾

 Documentation 
 Blog 
 Use Cases 
 Community 

 Pricing 
 Documentation 

 Login 
 Get Started 

# Get Started 

 The simplest way to run open-source software. Deploy any one of over
 400+ supported software services on a dedicated instance in less
 than 3 minutes.

## Step1 

### Create Your Account 

 Create your account by signing in with one of our supported OAuth
 providers (like Google, GitHub or GitLab) or using any email address
 you like.

## Step2 

### Choose your setup 

 Click the "Create a new service" button to access our new service
 setup wizard.

 Here, you'll choose:

 The software you want to deploy 

 The provider you want to use 

 The region you want to deploy in 

 The size of the VM you want 

 The level of support you want 

 Review the technical specifications and monthly cost of your
 service, and click to create the service! Our systems will
 provision, configure and deploy your new software instance
 immediately, complete with SSL certificates.

## Step3 

### Put it All Together 

 Monitor the realtime status of your new service in the dashboard.
 Once online,
 you'll be able to view the URL and secture credentials to
 connect and start using your service. 

 Do you want to bring your own domain? No problem, and no additional
 cost.
 Configure your intended hostname in our dashboard, and we'll
 pre-provision an additional SSL certificate for your
 domain 

 Configure a new CNAME record with your DNS provider, and you're all
 set.

 Yes, it's really that simple

## Step away! 

### It's smooth sailing from here 

 Now that your service is deployed, you can use it with confidence,
 knowing that:

 You're covered: elestio's technical expertise is keeping
 your services up to date, secure and backed up 

 You're giving back: 10% of our revenue is sent directly
 to open-source projects you're using. 

 You're in control: Cancel or change providers, regions
 and compute resources at any time. 

 Have questions?

 Contact us for answers or specific requirements. 

 Start your Free Trial today

 Get Started 

 The managed DevOps platform. Deploy 400+ open-source tools on any cloud. We handle the rest.

 ISO 27001 
 SOC2 
 HIPAA 
 GDPR 

#### Services 

 Databases 

 Applications 

 Dev Tools 

 Hosting 

 All Services 

#### Platform 

 Pricing 

 CI/CD 

 AI Skills 

 Terraform 

 Use Cases 

 API 

#### Company 

 What is Elestio? 

 About 

 Press Kit 

 Blog 

 Security 

 Status 

 Support 

#### Resources 

 Documentation 

 Use Cases 

 Community 

 Terms of Service 

 Enterprise Support 

 Contact 

#### Compare 

 Elestio vs Heroku 

 Elestio vs Railway 

 Elestio vs Render 

 Elestio vs Self-Hosting 

 Elestio vs Coolify 

 © 2026 Elestio. All rights reserved. 
 29 Merrion Square, Dublin 2, D02 RW64, Ireland 

### We use cookies 
 This website uses technologies such as cookies to enable essential site functionality, as well as for analytics and personalization. Learn more in our Privacy Policy .

 Accept 
 Decline