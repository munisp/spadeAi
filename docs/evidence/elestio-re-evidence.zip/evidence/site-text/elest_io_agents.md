https://elest.io/agents

AI Agent Deployment | Claude, Codex, Cursor | Elestio 

 Managed services ▾ 

 Databases 
 PostgreSQL, MySQL, Redis, MongoDB & more 

 Applications 
 n8n, WordPress, Supabase, Keycloak & more 

 Development 
 CI/CD tools, IDE, Git hosting & version control 

 Hosting & Infrastructure 
 Servers, containers, monitoring & storage 

 AI & GPU 
 LLMs, AI frameworks, GPU-powered inference tools 

 View all 400+ services → 

 Features ▾ 

 Domains 
 Custom domains & SSL for your services 

 CI/CD 
 Automated deployment pipelines 

 Terraform 
 Infrastructure as code provider 

 Clusters 
 High availability & multi-node scaling 

 AI ▾ 

 AI DevOps 
 Describe an issue, AI fixes your server 

 Agents 
 Deploy with AI coding agents 

 AI & Automation 
 Automate your infrastructure workflows 

 Vibecoder 
 AI-powered app development & deployment 

 Resources ▾ 

 Documentation 
 Guides, API reference & tutorials 

 Blog 
 Product news, engineering & updates 

 Use Cases 
 Real customer success stories 

 Community 
 Join the discussion on Discord 

 Pricing 

 Login 
 Get Started 

 Managed services ▾

 Databases 
 Applications 
 Development 
 Hosting & Infrastructure 
 AI & GPU 
 All Services 

 Features ▾

 Domains 
 CI/CD 
 Terraform 
 Clusters 

 AI ▾

 AI DevOps 
 Agents 
 AI & Automation 
 Vibecoder 

 Resources ▾

 Documentation 
 Blog 
 Use Cases 
 Community 

 Pricing 
 Documentation 

 Login 
 Get Started 

 AI Agents 

# Deploy on Elestio from your AI Agent 
 Let your favorite AI coding agent deploy and manage services on Elestio. 400+ open-source templates, 9 cloud providers, 100+ regions.

## Compatible AI Agents 

 Elestio works with leading AI coding agents. Install once, deploy from any supported agent.

 Officially Supported

### Claude Code by Anthropic 
 Agentic coding in your terminal. Full codebase understanding, git operations, and multi-file editing.

 Terminal Skill CLI 

### Codex by OpenAI 
 Lightweight terminal agent. File read/write, command execution, web browsing in a sandbox.

 Terminal Skill MCP CLI 

### Cursor by Anysphere 
 AI-first code editor. Multi-file Composer, background agents, and codebase indexing.

 Extension Skill MCP 

### OpenCode by Anomaly 
 Open-source terminal agent. Works with 75+ LLMs, TUI interface, provider agnostic architecture.

 Terminal Standalone 

 Also Compatible

### GitHub Copilot by GitHub 
 AI pair programmer with agent mode. Workspace context, CI integration, and PR summaries.

 IDE Terminal Extension 

### Windsurf by Codeium 
 Agentic IDE with Cascade. Flows automation, deep codebase search, and command suggestions.

 IDE Skill MCP CLI 

### Cline by Cline 
 VS Code extension with browser automation. Autonomous agent with human-in-the-loop approval.

 Extension MCP 

### Devin by Cognition 
 Autonomous AI software engineer. Plans, codes, debugs, and deploys independently.

 Cloud Standalone 

 Capabilities

## What agents can do with Elestio 

 Full infrastructure management through natural language commands.

### Deploy Services 
 Deploy PostgreSQL, Redis, WordPress, Grafana, n8n, and 400+ more templates with a single command.

 400+ templates 

### CI/CD Pipelines 
 Deploy your own code from GitHub or GitLab with fully automated CI/CD pipeline creation.

 Auto pipelines 

### Security & SSL 
 Manage firewall rules, SSL certificates, and SSH keys. Built-in security for all services.

 Built-in SSL 

### Backups & Snapshots 
 Configure automated backups, create snapshots, and restore from any point. S3 compatible.

 S3 compatible 

### Volumes & Storage 
 Create, attach, and manage block storage volumes for persistent data across services.

 Persistent data 

### Billing & Costs 
 Track costs across projects and services. Get billing summaries and optimize spending.

 Cost optimizer 

 Getting Started

## Up and Running in Minutes 
 Install the CLI, authenticate, and deploy your first service.

 1

#### Install the Elestio CLI 
 Global npm package, zero dependencies.

 2

#### Add the Elestio skill 
 Gives your AI agent access to 400+ templates.

 3

#### Configure credentials 
 API token from dash.elest.io/account/security 

 4

#### Verify authentication 
 One command to confirm you're connected.

 5

#### Deploy your first service 
 Pick any template and deploy in seconds.

 terminal 

 # Step 1: Install CLI 

 $ npm install -g elestio 

 # Step 2: Add skill 

 $ npx skills add elestio/elestio-skill 

   Elestio skill added 

 # Step 3: Authenticate 

 $ elestio login --email " [email protected] " --token "your_api_token" 

   Authenticated successfully 

 # Step 4: Verify 

 $ elestio auth test 

   Connected to Elestio API 

 # Step 5: Deploy! 

 $ elestio deploy PostgreSQL --project 112 --name my-db 

   PostgreSQL deployed in 2m 18s 

## Frequently Asked Questions 

 What is Elestio for AI Agents? + 
 Elestio provides a CLI tool that allows AI coding agents like Claude Code, Codex, Cursor, and OpenCode to deploy and manage services on the Elestio DevOps platform directly through natural language commands. Install it with npm install -g elestio .

 Do I need an Elestio account? + 
 Yes. You need an Elestio account with an API token. Sign up for free and generate a token at dash.elest.io/account/security .

 Which agents are supported? + 
 Officially supported: Claude Code, Codex, Cursor, and OpenCode. Elestio is also compatible with GitHub Copilot, Windsurf, Cline, and Devin since it follows the open Agent Skills specification.

 Does it require npm dependencies? + 
 The Elestio CLI is lightweight with zero npm dependencies. It's built entirely on Node.js built-in modules. Install it globally with npm install -g elestio . Requires Node.js 18 or higher.

 Is it free to use? + 
 The agent integration is free and open-source (MIT license). You only pay for the Elestio services you deploy. Elestio offers a free trial to get started.

 Reviews

## Trusted by 10,000+ Developers Worldwide 
 Real reviews from real users on Trustpilot.

 “

 ★★★★★

 "I'm in the IT industry for over 25 years and Elestio stands out in many ways. The managed services are top-notch, support is incredibly fast, and the platform just works. Couldn't be better!"

 Conflock 
 IT Director · Germany · Verified on Trustpilot 

 See all reviews on Trustpilot

## Start deploying with AI 

 Connect your AI agent to Elestio and let it handle infrastructure.

 Get Started Free

 GitHub

 API Docs

 The managed DevOps platform. Deploy 400+ open-source tools on any cloud. We handle the rest.

 ISO 27001 
 SOC2 
 HIPAA 
 GDPR 

#### Services 

 Databases 

 Applications 

 Dev Tools 

 Hosting 

 All Services 

#### Platform 

 Pricing 

 CI/CD 

 AI Skills 

 Terraform 

 Use Cases 

 API 

#### Company 

 What is Elestio? 

 About 

 Press Kit 

 Blog 

 Security 

 Status 

 Support 

#### Resources 

 Documentation 

 Use Cases 

 Community 

 Terms of Service 

 Enterprise Support 

 Contact 

#### Compare 

 Elestio vs Heroku 

 Elestio vs Railway 

 Elestio vs Render 

 Elestio vs Self-Hosting 

 Elestio vs Coolify 

 © 2026 Elestio. All rights reserved. 
 29 Merrion Square, Dublin 2, D02 RW64, Ireland 

### We use cookies 
 This website uses technologies such as cookies to enable essential site functionality, as well as for analytics and personalization. Learn more in our Privacy Policy .

 Accept 
 Decline