https://elest.io/tcloud-shared-responsibility

Responsibility and commitments 

# Who does what: Telekom, Elestio and you 
 When Elestio manages open-source services inside your own T Cloud Public (formerly Open Telekom Cloud) account, three parties share one stack. This page draws the lines layer by layer, so your procurement, security and data protection teams can sign off from one document.

 Connect Your T Cloud Account 
 Managed services for T Cloud 

 Your Telekom contract is untouched 
 Key custody stays with you 
 SLA up to 99.9% with 4h response 

 The model

## Who is responsible for what 
 Three parties, one stack. This table is the one your procurement and compliance teams will ask for.

 Layer

 Deutsche Telekom

 Elestio

 You

 Data centers, power, physical security

 ✓ Operates

 ✗ 

 ✗ 

 Hypervisor and platform (OpenStack)

 ✓ Operates

 ✗ 

 ✗ 

 Regional availability and platform SLA

 ✓ Contractual with you

 ✗ 

 Chooses the region

 Virtual machine provisioning

 Provides the API

 ✓ Executes

 Owns the account

 Operating system patching

 ✗ 

 ✓ Automated

 Approves policy

 Software installation and upgrades

 ✗ 

 ✓ Automated and reviewed

 Chooses the catalog

 Backups and restore testing

 Provides EVS snapshots

 ✓ Schedules and verifies

 Sets retention level

 SSL certificates

 ✗ 

 ✓ Issued and renewed

 Owns the domains

 Firewall and security groups

 Provides the primitive

 ✓ Configures and maintains

 Approves exposure

 Monitoring and alerting

 Platform status

 ✓ 24/7 on managed services

 Defines escalation contacts

 Encryption keys

 Provides KMS

 Read-only use of your key

 ✓ Owns and controls the key

 Application data and its lawful basis

 ✗ 

 ✗ 

 ✓ Controller responsibility

 Infrastructure invoice

 ✓ Bills you directly

 ✗ 

 ✓ Pays Telekom directly

 Management fee invoice

 ✗ 

 ✓ Bills you hourly

 ✓ Pays Elestio

 Why it matters

## What the bring your own account model does to your compliance position 
 The contractual shape matters more than any feature list when your auditors get involved.

### Your operator relationship is unchanged 
 T Cloud remains the operator of the underlying platform under German and EU jurisdiction, and your contract for it remains directly with Deutsche Telekom. Elestio does not resell, rebill or intermediate that relationship.

### Elestio is a service provider, not your host 
 Because the virtual machines are provisioned inside your own tenancy, Elestio operates software on infrastructure you hold. That is a materially different relationship from moving your workloads onto a third party platform, and it is usually the simpler one to document.

### Key control stays on your side of the line 
 Root volumes are encrypted with the evs/default key in your own account. Elestio holds read-only access to it and cannot rotate or delete it. Key custody is a question your DPO will ask, and the answer is you.

### Data residency is a property of your account 
 T Cloud operates data centers in Germany and the Netherlands, with a separate Swiss offering. Whichever region your account uses, Elestio deploys into it. Residency follows your tenancy, not our infrastructure.

 Commitments

## Support levels and what each one contractually adds 
 Level 1 ships with every service. Levels 2 and 3 add response and uptime commitments.

 Level 1

 Level 2

 Level 3

 Price per service, per month

 Included

 $50

 $200

 Uptime SLA

 No SLA

 99.5%

 ✓ 99.9%

 Response time commitment

 Email, human engineers

 24 hours (business hours)

 ✓ 4 hours (business hours)

 Remote backup retention

 7 days

 14 days

 ✓ 30 days

 Dedicated Customer Success Manager

 ✗ 

 ✗ 

 ✓ Included

 Custom SLA

 Available on request

 Available on request

 Available on request

 Reviews

## Trusted by 10,000+ Developers Worldwide 
 Real reviews from real users on Trustpilot.

 “

 ★★★★★

 "I'm in the IT industry for over 25 years and Elestio stands out in many ways. The managed services are top-notch, support is incredibly fast, and the platform just works. Couldn't be better!"

 Conflock 
 IT Director · Germany · Verified on Trustpilot 

 See all reviews on Trustpilot

 FAQ

## Frequently Asked Questions 

 Does Elestio become our hosting provider? 

 No. Deutsche Telekom remains the operator of the underlying platform and your contract for infrastructure remains directly with them. Because the virtual machines are provisioned inside your own T Cloud tenancy, Elestio operates software on infrastructure you hold, as a service provider rather than as a host.

 Who controls the encryption keys? 

 You do. Root volumes are encrypted with the evs/default key that already exists in your own account. Elestio holds read-only access to it and cannot create, rotate, disable or delete any key.

 Where is our data stored? 

 Wherever your own T Cloud account is provisioned. T Cloud operates data centers in Germany and the Netherlands, with a separate Swiss offering, and Elestio deploys into the region your account uses. Residency is a property of your tenancy, not of Elestio infrastructure.

 What are the SLA commitments? 

 Level 1 is included with every service and covers email support from real engineers with 7 days of remote backup retention, without an uptime SLA. Level 2 is $50 per service per month with a 99.5% uptime SLA, 24 hour response (business hours) and 14 days of retention. Level 3 is $200 per service per month with 99.9% uptime, 4 hour response (business hours), 30 days of retention and a dedicated Customer Success Manager. Custom SLAs are available on request.

 Who is responsible if a backup cannot be restored? 

 Elestio schedules and verifies backups for the services it manages, and the retention window is set by your support level. Deutsche Telekom provides the underlying EVS snapshot capability. You remain responsible for defining which data matters and for the lawful basis on which it is processed.

 Can we get a data processing agreement? 

 Yes. Contact the Elestio team to put the appropriate agreements in place for your jurisdiction and sector before you go into production.

 More on T Cloud

 Managed services for T Cloud Access and security model In-house vs managed Public sector Managed PostgreSQL Deploy on T Cloud Bring your own T Cloud account AWS vs T Cloud Azure vs T Cloud 

## One document for procurement, security and your DPO 
 Clear lines, named commitments, and infrastructure that never leaves your account.

 Get Started