https://elest.io/fully-managed-services/development/dev-tools

Dev tools - Development | Elestio 

 Managed services ▾ 

 Databases 
 PostgreSQL, MySQL, Redis, MongoDB & more 

 Applications 
 n8n, WordPress, Supabase, Keycloak & more 

 Development 
 CI/CD tools, IDE, Git hosting & version control 

 Hosting & Infrastructure 
 Servers, containers, monitoring & storage 

 AI & GPU 
 LLMs, AI frameworks, GPU-powered inference tools 

 View all 400+ services → 

 Features ▾ 

 Domains 
 Custom domains & SSL for your services 

 CI/CD 
 Automated deployment pipelines 

 Terraform 
 Infrastructure as code provider 

 Clusters 
 High availability & multi-node scaling 

 AI ▾ 

 AI DevOps 
 Describe an issue, AI fixes your server 

 Agents 
 Deploy with AI coding agents 

 AI & Automation 
 Automate your infrastructure workflows 

 Vibecoder 
 AI-powered app development & deployment 

 Resources ▾ 

 Documentation 
 Guides, API reference & tutorials 

 Blog 
 Product news, engineering & updates 

 Use Cases 
 Real customer success stories 

 Community 
 Join the discussion on Discord 

 Pricing 

 Login 
 Get Started 

 Managed services ▾

 Databases 
 Applications 
 Development 
 Hosting & Infrastructure 
 AI & GPU 
 All Services 

 Features ▾

 Domains 
 CI/CD 
 Terraform 
 Clusters 

 AI ▾

 AI DevOps 
 Agents 
 AI & Automation 
 Vibecoder 

 Resources ▾

 Documentation 
 Blog 
 Use Cases 
 Community 

 Pricing 
 Documentation 

 Login 
 Get Started 

 Fully Managed 

# Dev tools 
 Explore our collection of open source dev tools on Elestio. We handle installation, backup, updates, support, and maintenance, ensuring a simplified and efficient solution for optimizing your software development workflow.

 Databases 
 Applications 
 Dev Tools 
 Hosting & Infrastructure 
 AI & GPU 
 All Services 

 Identity and access management Backend-as-a-Service Dev tools Network devOps No-code / Low code 

 Search from 400+ open-source software 

 Jellyfin

 Free Software Media System that puts you in control of managing and streaming your media alternative to the proprietary Emby and Plex.

 OpnForm

 Form Builder, Create beautiful forms and share them anywhere. It is super fast, you don't need to know how to code. It's an alternative to products like Typeform, JotForm, Tally, etc

 Corteza

 A low-code platform alternative to Salesforce lets you build and iterate CRM, business processes and other structured data apps fast, create intelligent business process workflows, and connect with almost any data source. 

 Kroki

 Creates diagrams from textual descriptions!

 EMQX

 MQTT broker for IoT, IIoT, and connected vehicles. it supports multiple open standard protocols like MQTT, HTTP, QUIC, and WebSocket.

 draw

 draw.io is a JavaScript, client-side editor for general diagramming.

 Stirling-PDF

 Web application that allows you to perform various operations on PDF files.

 Infisical

 Infisical is an open-source, end-to-end encrypted platform for secret management: sync secrets across your team/infrastructure and prevents secret leaks.

 QuickChart

 QuickChart allows you to generates chart images of charts from a URL. 

 Gitlab

 GitLab enables you to deliver software faster with better security and collaboration in a single platform.

 GrowthBook

 GrowthBook is an open-source platform for feature flags and A/B tests that helps teams deploy code efficiently and analyze experiments

 Gitness

 Gitness is an Open Source developer platform with Source Control Management, Continuous Integration, and Continuous Delivery.

 DevLake

 A dev data platform that ingests, analyzes, and visualizes the fragmented data from DevOps tools to extract insights for engineering excellence, developer experience, and community growth

 Bugsink

 Self-hosted Error Tracking

 Onedev

 OneDev is an open-source all-in-one DevOps platform.

 Gogs

 Gogs is a lightweight self-hosted Git server that can be run on just about anything. 

 Gitea

 Gitea is a painless self-hosted Git service. It is similar to GitHub, Bitbucket, and GitLab

 Gerrit

 Gerrit is a code review and project management tool for Git based projects.

 Rstudio

 Publish your R and Python content with RStudio Connect

 Gotenberg

 A Docker-powered stateless API for PDF files

 Bytebase

 Bytebase is an open-source database CI/CD tool for developers and DBAs.

 Flagsmith

 Flagsmith is an, fully featured, Feature Flag and Remote Config service.

 CI-CD-Target

 Deploy one or multiple CD/CD pipelines to a target node

## Frequently Asked Questions about Dev tools 
 Here are some most commonly asked questions

 What is managed Dev tools hosting on Elestio? 

 Elestio provides fully managed hosting for Dev tools tools on dedicated cloud infrastructure. We handle installation, configuration, security, automated backups, SSL certificates, OS updates, and 24/7 monitoring so you can focus on building your product instead of managing servers.

 How much does managed Dev tools hosting cost? 

 Elestio pricing starts at $14 per month for a dedicated virtual machine. Every plan includes automated backups, SSL certificates, security updates, OS patches, and 24/7 monitoring with no hidden fees. You can choose from 9 cloud providers and 100+ regions worldwide.

 What's included with every Dev tools deployment? 

 Every deployment includes: dedicated VM (not shared containers), automated daily backups, free SSL certificates, automatic security patches and OS updates, 24/7 uptime monitoring with alerts, DNS and SMTP configuration, built-in tools (VSCode, File Explorer, Web Terminal), and API/CLI access. All managed by Elestio's DevOps team.

 How do I get started with Dev tools on Elestio? 

 Getting started takes just a few minutes: choose your software from the catalog, select a cloud provider and region, pick your VM size, and click deploy. Elestio handles the rest: installation, configuration, SSL, DNS, and monitoring are all set up automatically.

 Can I migrate my existing Dev tools services to Elestio? 

 Yes, Elestio supports migration from self-hosted or other cloud-hosted services. You get full SSH access to your dedicated VM, making it easy to import data and configurations. Elestio's support team can also assist with migration planning and execution.

 The managed DevOps platform. Deploy 400+ open-source tools on any cloud. We handle the rest.

 ISO 27001 
 SOC2 
 HIPAA 
 GDPR 

#### Services 

 Databases 

 Applications 

 Dev Tools 

 Hosting 

 All Services 

#### Platform 

 Pricing 

 CI/CD 

 AI Skills 

 Terraform 

 Use Cases 

 API 

#### Company 

 What is Elestio? 

 About 

 Press Kit 

 Blog 

 Security 

 Status 

 Support 

#### Resources 

 Documentation 

 Use Cases 

 Community 

 Terms of Service 

 Enterprise Support 

 Contact 

#### Compare 

 Elestio vs Heroku 

 Elestio vs Railway 

 Elestio vs Render 

 Elestio vs Self-Hosting 

 Elestio vs Coolify 

 © 2026 Elestio. All rights reserved. 
 29 Merrion Square, Dublin 2, D02 RW64, Ireland 

### We use cookies 
 This website uses technologies such as cookies to enable essential site functionality, as well as for analytics and personalization. Learn more in our Privacy Policy .

 Accept 
 Decline