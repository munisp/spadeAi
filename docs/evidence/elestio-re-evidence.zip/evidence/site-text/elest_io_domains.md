https://elest.io/domains

Domain Management | DNS Configuration | Elestio 

 Managed services ▾ 

 Databases 
 PostgreSQL, MySQL, Redis, MongoDB & more 

 Applications 
 n8n, WordPress, Supabase, Keycloak & more 

 Development 
 CI/CD tools, IDE, Git hosting & version control 

 Hosting & Infrastructure 
 Servers, containers, monitoring & storage 

 AI & GPU 
 LLMs, AI frameworks, GPU-powered inference tools 

 View all 400+ services → 

 Features ▾ 

 Domains 
 Custom domains & SSL for your services 

 CI/CD 
 Automated deployment pipelines 

 Terraform 
 Infrastructure as code provider 

 Clusters 
 High availability & multi-node scaling 

 AI ▾ 

 AI DevOps 
 Describe an issue, AI fixes your server 

 Agents 
 Deploy with AI coding agents 

 AI & Automation 
 Automate your infrastructure workflows 

 Vibecoder 
 AI-powered app development & deployment 

 Resources ▾ 

 Documentation 
 Guides, API reference & tutorials 

 Blog 
 Product news, engineering & updates 

 Use Cases 
 Real customer success stories 

 Community 
 Join the discussion on Discord 

 Pricing 

 Login 
 Get Started 

 Managed services ▾

 Databases 
 Applications 
 Development 
 Hosting & Infrastructure 
 AI & GPU 
 All Services 

 Features ▾

 Domains 
 CI/CD 
 Terraform 
 Clusters 

 AI ▾

 AI DevOps 
 Agents 
 AI & Automation 
 Vibecoder 

 Resources ▾

 Documentation 
 Blog 
 Use Cases 
 Community 

 Pricing 
 Documentation 

 Login 
 Get Started 

 Domain Names 

# Register Your Domain 

## Domain Name 
 Your domain helps people find you online and makes a first impression. Find one that represents you perfectly.

 Search from hundreds of domain extensions

 Everything included

## Make a name for your website 

### Privacy Protection 
 Free domain privacy protection included. Your personal information stays hidden from public WHOIS lookups.

 Free WHOIS privacy 

### DNS Management 
 Full control over your DNS records. Manage A, AAAA, CNAME, MX, TXT, SRV and more from the dashboard.

 Full DNS control 

### SSL Certificates 
 Free SSL/TLS certificates with automatic renewal. Your domain is always secured with HTTPS encryption.

 Auto-renewed SSL 

### Email Forwarding 
 Redirect emails from your domain to any address. All mail sent to @yourdomain will be forwarded automatically.

 Unlimited forwarding 

### Auto Renewal 
 Never lose your domain. Set up automatic renewal so your domain stays registered without worrying about expiration.

 Never lose your domain 

### Human Support 
 Our support team is always available to help you with domain configuration, transfers, and any questions.

 Always available 

## Frequently Asked Questions 
 Here are some most commonly asked questions

 What is a domain name? 

 A domain name is a unique identifier that serves as the address of a website on the internet, similar to the address of a building. By typing the domain name into a web browser, users can easily access a website. For example, Google's website can be found at "google.com".

 A domain name gives credibility and legitimacy to a business, and Elestio can help you find the ideal domain name for your website.

 Why do I need a domain name? 

 It's important to register a domain name to have an online presence for your business through your own website, which is necessary for success in most businesses.

 What is the registration of a domain? 

 Domain name registration is the act of securing a web address, such as Elest.io or Google.com, by registering it for exclusive use. Although you don't technically own the domain, paying the annual registration fee allows you to use it exclusively.

 Does registering a domain name protect my business? 

 Yes, registering a domain name that matches your business name can keep others from using the same name and confusing customers. To be extra safe, register several different variations of your business name, like misspelled versions and different suffixes. This will help secure your online identity.

 How to register a domain? 

 Finding the perfect domain name has never been easier. Simply enter your desired web address in the search field, and within seconds, you'll know if it's available for registration.

 If the name you've chosen is already taken, you'll receive alternative suggestions that you can consider.

 The entire process is straightforward and effortless, making it easy to secure the domain name of your choice.

 Why is there a price difference between Top Level Domains? 

 The Top Level Domain (TLD) is the extension of the domain (e.g. .com, .org, .net, etc.). This is due to popularity of some over others and differences in registry fees. We usually recommend that you order all the variations during the domain name registration process in order to protect your domain name from being used by others. Customers may type ".com" domain expecting to find your website but if you only have ".fr" they might find your competitor instead.

 What is the duration of a domain registration? 

 The duration of your domain name registration depends on the domain type and the registrar you choose. Some registrars offer the option to register a domain for a maximum of 10 years, while the typical registration period is 1-3 years.

 It's important to carefully consider the length of your registration, as it affects the availability and ownership of your domain name over time.

 How do I renew my domain? 

 To keep your domain registered to you, it's important to regularly renew it. With Elestio, renewing your domain is simple and convenient. You have the option to renew manually or set up automatic renewal to ensure that your domain stays registered without having to worry about the expiration date.

 How do I choose a good domain name? 

 When selecting a domain name, here are some factors to consider:

 1. Reflect your brand 
Your domain name should ideally match your company name, making it easy for customers to identify and remember you.

 2. Be concise and memorable 
Aim for a short, simple and memorable domain name that is easy to remember and type. Long and complex domain names can be difficult to recall or type accurately.

 3. Avoid confusing characters 
Avoid using numbers or dashes, as they can be easily forgotten or misinterpreted. For example, if your company name includes a number, consider registering both the numerical and written versions to avoid confusion.

 4. Protect your brand 
Register multiple variations of your domain name, including common misspellings and different extensions (e.g. .com, .org, .net, etc.). This helps to protect your brand and ensures that others cannot use similar domains that may confuse your customers or damage your brand.

 How to edit DNS records? 

 You can manage your domain's DNS records in the Elestio dashboard. Here are brief descriptions of the different record types:

 A record 
It maps a website name, such as 'google.com', to its corresponding IPv4 address, such as '172.217.164.110', allowing Internet hosts to be reached using human-readable names.

 AAAA record 
It serves the same purpose as an A record, linking a hostname to an IP address, but it uses IPv6 addresses instead of IPv4 addresses.

 ANAME record 
It maps an alias hostname directly to an IP address. ANAME records offer a more efficient and straightforward mapping compared to CNAME records, but they are not as widely supported by DNS providers.

 CNAME record 
It is used to associate multiple hostnames with a single canonical hostname, enabling easier management of domain names and allowing multiple hostnames to refer to the same website or service.

 MX record 
It is used by email systems to route incoming messages to the correct mail servers for a domain.

 SRV record 
SRV records are used to map specific network services to their locations on the network, including the hostname, port number, and priority/weight values.

 TXT record 
It is used to store text-based information associated with a domain name. They are commonly used for email authentication, website encryption, and other security-related purposes.

 Can I receive emails on my domain? 

 Yes, you can receive emails on your domain. You can either set up email forwarding or update your MX records to a mail server/provider.

 Elestio offers email forwarding, where all mail sent to addresses ending with your domain will be forwarded to an email address you choose. If your domain name is elest.io, all email sent to addresses ending with @elest.io will be redirected to your preferred email address, such as [email protected] .

 How to transfer a domain? 

 Sure! If your current domain provider doesn't meet your needs for pricing, support, and service, you can switch to Elestio. We aim to make the transfer process as smooth as possible so you can focus on more important things.

 You must have purchased the domain more than 60 days ago. 

 You need to get the EPP code from your previous registrar. This code protects the transaction to prevent anyone from stealing your domain. The transfer process can take between 1 and 8 days (depending on your registrar).

 Click here to transfer your domain 

## Ready to claim your domain? 
 Search for your perfect domain name and get started in minutes with Elestio.

 Get Started Free 

 The managed DevOps platform. Deploy 400+ open-source tools on any cloud. We handle the rest.

 ISO 27001 
 SOC2 
 HIPAA 
 GDPR 

#### Services 

 Databases 

 Applications 

 Dev Tools 

 Hosting 

 All Services 

#### Platform 

 Pricing 

 CI/CD 

 AI Skills 

 Terraform 

 Use Cases 

 API 

#### Company 

 What is Elestio? 

 About 

 Press Kit 

 Blog 

 Security 

 Status 

 Support 

#### Resources 

 Documentation 

 Use Cases 

 Community 

 Terms of Service 

 Enterprise Support 

 Contact 

#### Compare 

 Elestio vs Heroku 

 Elestio vs Railway 

 Elestio vs Render 

 Elestio vs Self-Hosting 

 Elestio vs Coolify 

 © 2026 Elestio. All rights reserved. 
 29 Merrion Square, Dublin 2, D02 RW64, Ireland 

### We use cookies 
 This website uses technologies such as cookies to enable essential site functionality, as well as for analytics and personalization. Learn more in our Privacy Policy .

 Accept 
 Decline