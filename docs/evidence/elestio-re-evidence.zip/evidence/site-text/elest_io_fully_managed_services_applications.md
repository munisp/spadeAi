https://elest.io/fully-managed-services/applications

Applications | Managed Open-Source | Elestio 

 Managed services ▾ 

 Databases 
 PostgreSQL, MySQL, Redis, MongoDB & more 

 Applications 
 n8n, WordPress, Supabase, Keycloak & more 

 Development 
 CI/CD tools, IDE, Git hosting & version control 

 Hosting & Infrastructure 
 Servers, containers, monitoring & storage 

 AI & GPU 
 LLMs, AI frameworks, GPU-powered inference tools 

 View all 400+ services → 

 Features ▾ 

 Domains 
 Custom domains & SSL for your services 

 CI/CD 
 Automated deployment pipelines 

 Terraform 
 Infrastructure as code provider 

 Clusters 
 High availability & multi-node scaling 

 AI ▾ 

 AI DevOps 
 Describe an issue, AI fixes your server 

 Agents 
 Deploy with AI coding agents 

 AI & Automation 
 Automate your infrastructure workflows 

 Vibecoder 
 AI-powered app development & deployment 

 Resources ▾ 

 Documentation 
 Guides, API reference & tutorials 

 Blog 
 Product news, engineering & updates 

 Use Cases 
 Real customer success stories 

 Community 
 Join the discussion on Discord 

 Pricing 

 Login 
 Get Started 

 Managed services ▾

 Databases 
 Applications 
 Development 
 Hosting & Infrastructure 
 AI & GPU 
 All Services 

 Features ▾

 Domains 
 CI/CD 
 Terraform 
 Clusters 

 AI ▾

 AI DevOps 
 Agents 
 AI & Automation 
 Vibecoder 

 Resources ▾

 Documentation 
 Blog 
 Use Cases 
 Community 

 Pricing 
 Documentation 

 Login 
 Get Started 

 Fully Managed 

# Applications 
 Unleash the potential of open-source applications with our managed services. Whether you need content management, communication tools, or e-commerce platforms, our services ensure smooth operations, timely updates, and expert support, so you can deliver an exceptional user experience.

 Databases 
 Applications 
 Dev Tools 
 Hosting & Infrastructure 
 AI & GPU 
 All Services 

 CRM / ERP Note-taking Project management Calendar Live chat Invoicing and payments Documentation Search Email marketing Product Feedback Forum / Community Business Intelligence Password manager Analytics E-commerce CMS Customer support Fediverse Automation HCM CMMS HRMS 

 Search from 400+ open-source software 

 Wordpress-Multisites

 WordPress Multisite is a version of WordPress that allows you to run multiple sites off a single installation of WordPress.

 Wordpress

 WordPress is the world’s most popular open-source platform for creating websites, blogs, and applications.

 Ghost

 Ghost is a powerful app for new-media creators to publish, share, and grow a business around their content.

 Nextcloud

 Nextcloud provides an industry-leading, on-premises content collaboration platform.

 Vaultwarden

 Vaultwarden is an open-source password management application that can be self-hosted and run on your infrastructure. 

 Chatwoot

 Chatwoot is a modern open-source customer engagement suite, a powerful alternative to Intercom, Zendesk, and Salesforce Service Cloud.

 Mattermost Team Edition

 Mattermost is an open-source platform for secure collaboration across the entire software development lifecycle. 

 NodeBB

 NodeBB is next-generation forum software - powerful, mobile-ready and easy to use.

 Discourse

 Discourse is an open-source discussion platform built for the next decade of the Internet. 

 Rocket.Chat

 Rocket.Chat is an open-source communications platform for organizations with high standards of data protection. 

 Prestashop

 The PrestaShop project is a universal open-source software platform to build your e-commerce solution.

 Drupal

 Drupal is an open-source content management platform that supports a wide variety of websites.

 Joomla

 Joomla is an award-winning content management system for building websites and powerful online applications.

 Magento

 Magento open-source software delivers basic e-commerce capabilities that allow you to build a unique online store from the ground up. 

 LimeSurvey

 LimeSurvey is the most popular FOSS online survey tool on the web.

 OnlyOffice

 OnlyOffice is an online office suite that includes editors and viewers for text documents, spreadsheets, and presentations.

 PhotoPrism

 PhotoPrism is an AI-powered app for browsing, organizing & sharing your photo collection

 Umami

 Umami is a simple, fast, website analytics alternative to Google Analytics.

 CryptPad

 CryptPad is a collaboration suite, encrypted and open-source.

 FreeScout

 FreeScout is a free self-hosted help desk & shared mailbox.

 Papercups

 Papercups is a open-source live customer chat

 Dolibarr

 Dolibarr ERP CRM is a modern software package to manage your company or foundation's activity

 Joplin

 Joplin - an open source note taking and to-do application with synchronization capabilities for Windows, macOS, Linux, Android and iOS

 OpenSlides

 OpenSlides is a powerful and modern, web-based software for the digital organization of your meetings and committees. 

 Formbricks

 Formbricks is your go-to solution for in-product micro-surveys that will supercharge your product experience. 

 Dittofeed

 Automate communications with customers. Give data control to your growth engineers.

 Plane

 An open-source software development tool to manage issues, sprints, and product roadmaps with peace of mind

 Pixelfed

 Pixelfed is a fediverse decentralized social network for image sharing. Unlike other platforms with features similar to those of the social network Instagram.

 Pritunl

 Best open-source alternative to proprietary commercial VPN products such as Aviatrix and Pulse Secure.

 Hop

 Apache Hop is a data orchestration and data engineering platform that aims to facilitate all aspects of data and metadata orchestration

 Bigcapital

 Bigcapital is financial accounting with intelligent reporting for faster decision-making, an open-source alternative to Quickbooks, Xero, etc.

 Lago

 Open-source alternative to Stripe Billing and Chargebee it offers a modular architecture for metering and usage-based billing, at every stage of your company.

 GLPI

 GLPI is a Free Asset and IT Management Software package, Data center management, ITIL Service Desk, licenses tracking and software auditing.

 Leantime

 Leantime is a strategic project management system for non-project managers.

 Logto

 Logto is an Auth0 alternative for building modern customer identity infrastructure with minimal effort, for both your customers and their organizations.

 Cells

 Pydio Cells is the Document Sharing, Management, and Collaboration platform.

 Attendize

 Attendize is a ticket-selling and event management platform.

 Pretix

 Ticket shop application for conferences, festivals, concerts, tech events, shows, exhibitions, workshops, bar camps, etc.

 Password Pusher

 An application to communicate passwords over the web. Links to passwords expire after a certain number of views and/or time has passed.

 HumHub

 HumHub to communicate and collaborate, share information, interact with all people in your organization, and personalize the software to fit your individual needs.

 EasyAppointments

 Open Source Appointment Scheduler that allows customers to book appointments with you

 Jellyfin

 Free Software Media System that puts you in control of managing and streaming your media alternative to the proprietary Emby and Plex.

 OpnForm

 Form Builder, Create beautiful forms and share them anywhere. It is super fast, you don't need to know how to code. It's an alternative to products like Typeform, JotForm, Tally, etc

 Pleroma

 A microblogging server software that can federate other servers that support ActivityPub. it will federate with all servers like Friendica, GNU Social, Hubzilla, Mastodon, Misskey, Peertube, and Pixelfed.

 Corteza

 A low-code platform alternative to Salesforce lets you build and iterate CRM, business processes and other structured data apps fast, create intelligent business process workflows, and connect with almost any data source. 

 Vikunja

 The open-source to-do app. Organize everything, on all platforms.

 Papermerge

 Open Source Document Management System for Digital Archives (Scanned Documents)

 Kroki

 Creates diagrams from textual descriptions!

 Cryptgeon

 Cryptgeon is a secure, open-source note / file-sharing service inspired by PrivNote written in rust & svelte.

 EMQX

 MQTT broker for IoT, IIoT, and connected vehicles. it supports multiple open standard protocols like MQTT, HTTP, QUIC, and WebSocket.

 Photon

 A replacement for Lemmy-ui with more features, a better design, and more customizability. It includes Photon UI + Lemmy

 Misskey

 Misskey is an open-source microblogging, federated social media platform that's free forever! 

 Crater

 Crater helps you track expenses, and payments & create professional invoices & estimates.

 Passit

 Password manager to use on any device with a web browser to secure your digital life.

 draw

 draw.io is a JavaScript, client-side editor for general diagramming.

 YOURLS

 YOURLS (Your Own URL Shortener), de facto standard self-hosted URL shortener in PHP

 Countly

 Countly is a product analytics platform that helps teams track, analyze, and act on their user actions and behavior on mobile, web, and desktop applications.

 Stirling-PDF

 Web application that allows you to perform various operations on PDF files.

 Wger

 FLOSS fitness/workout, nutrition and weight tracker

 OJS

 Open Journal Systems (OJS) is open-source software to manage scholarly journals.

 IOMAD

 IOMAD is a multi-tenancy solution for business, corporate, and workplace Moodle markets.

 FreshRSS

 FreshRSS is an RSS and Atom feed aggregator.

 Linkwarden

 Linkwarden is a collaborative bookmark manager to collects, organizes, and preserves web pages.

 XWiki

 XWiki Platform is a generic wiki platform offering runtime services for applications built on top of it.

 Revolt

 The Open Source Discord Alternative. Find your community, connect with the world

 Sharkey

 Sharkey is an open source, decentralized social media platform that's free forever! 

 Tolgee

 Open-source developer & translator friendly localization platform 🐁

 Snipe-it

 An IT asset/license management system

 Docassemble

 A free, open-source expert system for guided interviews and document assembly, based on Python, YAML, and Markdown.

 Dashy

 The Ultimate Homepage for your Homelab

 Saltcorn

 Saltcorn is a platform for building applications without writing code.

 Peppermint

 An open source ticket management & help desk solution. A zendesk/freshdesk alternative

 Hi-events

 Event management and ticket selling platform 🎟️

 Maybe

 OS for your personal finances

 Docmost

 Docmost is a collaborative wiki and documentation software. It is an open-source alternative to Confluence and Notion.

 Indico

 A feature-rich event management system, made @ CERN, the place where the Web was born.

 Wazuh

 The Open Source Security Platform. Unified XDR and SIEM protection for endpoints and cloud workloads.

 Grist

 A modern, spreadsheet that goes beyond the grid.

 Saleor

 Saleor Core: the high-performance, composable, headless commerce API.

 Funkwhale

 A modern, convivial, and free music audio and podcasts server on YunoHost

 IRIS

 Iris is a web collaborative platform aiming to help incident responders sharing technical details during investigations.

 UVdesk

 UVdesk Opensource Community Helpdesk Project is built for all to make a full ticketing support system along with many more other features.

 HortusFox

 Self-hosted collaborative plant management and tracking system for plant enthusiasts

 AppFlowy

 Bring projects, wikis, and teams together with AI. AppFlowy is an AI collaborative workspace where you achieve more without losing control of your data. The best open source alternative to Notion.

 Postiz

 The ultimate social media scheduling tool with a bunch of AI.

 Kener

 Stunning status pages, batteries included!

 CiviCRM

 Open Source CRM For Nonprofits Worldwide

 Omeka

 A flexible web publishing platform for the display of library, museum, and scholarly collections, archives, and exhibitions.

 Eneo

 Open AI platform for generative AI that puts public Sweden in the driver's seat.

 Cryptomator

 Secure client-side encryption for your cloud storage, ensuring privacy and control over your data.

 Rybbit

 Alternative to Google Analytics that is 10x more intuitive.

 UniBee

 Automate Subscription Billing & Recurring Payments Unify subscriptions, real-time usage metering, and multiple payment gateways

 InvenTree

 Inventory management system which provides intuitive parts management and stock control.

 PieFed

 Lemmy/Mbin alternative written in Python with Flask

 Convex

 Convex is the open-source reactive database designed to make life easy for web app developers, whether human or LLM.

 OpenObserve

 OpenObserve is an open-source observability platform for logs, metrics, traces, and frontend monitoring. A cost-effective alternative to Datadog, Splunk, and Elasticsearch with 140x lower storage costs and single binary deployment.

 OVA-Runner

 Run any OVA/VMDK/QCOW2 virtual machine image on Elestio using QEMU/KVM.

 SeaweedFS

 SeaweedFS is a distributed storage system for object storage (S3), file systems, and Iceberg tables, designed to handle billions of files with O(1) disk access and effortless horizontal scaling.

 Garage

 (Mirror) S3-compatible object store for small self-hosted geo-distributed deployments.

 RustFS

 RustFS is a high-performance, distributed object storage system built in Rust, one of the most loved programming languages worldwide. RustFS combines the simplicity of MinIO with the memory safety and raw performance of Rust. It offers full S3 compatibilit

 Hermes

 The self-improving AI agent built by Nous Research. It's the only agent with a built-in learning loop.

 Erugo

 A powerful, self-hosted file-sharing platform built with PHP and Laravel with a Vue.js frontend. It offers secure, customizable file-transfer capabilities through an elegant user interface, giving you complete control over your data while providing a seam

 Ghostfolio

 Open Source Wealth Management Software. It's a privacy-first dashboard for your personal finances. Break down your asset allocation, know your net worth, and make solid, data-driven investment decisions.

 NetBox

 The premier source of truth powering network automation.

 Glean

 A self-hosted RSS reader and personal knowledge management tool.

 AudioMuse-AI

 AudioMuse-AI is a self-hosted, Dockerized music playlist generator using sonic analysis to discover related tracks for Jellyfin, Navidrome, LMS, Lyrion, and Emby: no metadata or external APIs needed.

 Temporal

 Temporal is a durable execution platform that enables developers to build scalable applications without sacrificing productivity or reliability

 WildFly

 A powerful, modular, & lightweight application server that helps you build amazing applications.

 OpenSign

 The premier open-source document signing solution (DocuSign alternative)

 nao

 nao is an open-source analytics agent. Create the context of your analytics agent with nao-core cli: data, metadata, modeling, rules, etc.

 WulfVault

 WulfVault is a professional-grade, self-hosted file-sharing platform designed for organizations that demand security, accountability, and complete control over their data

 Continuwuity

 A community-driven Matrix homeserver

 Kan

 The open source Trello alternative.

 OpenEMR

 The most popular open source electronic health records and medical practice management solution.

 Notifuse

 Notifuse is an open-source & modern emailing platform

 Cyclos

 Payment software created for banks, barters, remittances, and innovative currency systems. Cyclos is used by more than 1500 payment systems worldwide.

 Horilla

 HRMS designed to streamline HR operations and enhance organizational efficiency

 Weblate

 Weblate is a libre software web-based continuous localization system, used by over 2500 libre projects and companies in more than 165 countries.

 Mixpost

 Schedule, publish, and manage your social media content on your server. No subscriptions, no limits. (Buffer alternative)

 Synaplan

 The open-source AI platform, chat, knowledge, media, and agents on infrastructure you control.

 Bifrost

 A high-performance AI gateway that fronts 15+ LLM providers behind one OpenAI-compatible API, with failover, load balancing, and budgets.

 PgBouncer

 PgBouncer is a lightweight connection pooler for PostgreSQL, multiplex hundreds of client connections onto a small pool of real database connections, with a bundled PostgreSQL and pgAdmin console included.

 Odyssey

 Odyssey is a scalable, multi-threaded connection pooler for PostgreSQL by Yandex, spreads clients across worker threads that scale with available CPUs, with a bundled PostgreSQL and pgAdmin console included.

 PgDog

 PgDog is a PostgreSQL connection pooler, load balancer, and query router written in Rust, spreads reads across replicas and routes sharded queries, with a bundled PostgreSQL and pgAdmin console included.

 FarmOS

 FarmOS is a web-based farm record keeping application, track locations, assets, and land use through an interactive map-based dashboard, with a bundled PostgreSQL database.

 Evolution-API

 Evolution API is an open-source REST API for WhatsApp and multi-channel messaging, supports Baileys-based WhatsApp Web and the official WhatsApp Cloud API, with native integrations for Typebot, Chatwoot, Dify, OpenAI, RabbitMQ, and more.

 Alexandrie

 Alexandrie is the open-source, offline-first Notion, Obsidian & Confluence alternative, advanced Markdown, multi-tenant teams, OIDC/SSO, and local S3 backups

 Fleet

 Fleet is an open-source device management platform, inventory laptops, workstations, and servers, run live osquery queries, enforce policies, and track software and vulnerabilities across your fleet.

 Solidtime

 solidtime is a modern, open-source time-tracking app, timer, calendar and weekly timesheets, flexible reporting and export, invoicing from billable hours, and project budgeting with team roles and access controls.

 Termix

 Termix is a self-hosted, all-in-one server management platform, SSH terminal with split-screen and tabs, remote desktop (RDP/VNC/Telnet), SSH tunneling, file management, and container/host monitoring.

 LiteParse

 LiteParse is a document parsing REST API by LlamaIndex, parses PDF, DOCX, PPTX, and images into JSON, text, or Markdown, renders page screenshots, and estimates OCR needs, fully locally with no API key or GPU required.

 Fleetbase

 Fleetbase is a modular, open-source logistics and supply chain operating system, Fleet-Ops dispatch and route optimization, a headless multi-vendor Storefront, and automated Ledger invoicing, deployable self-hosted with no vendor lock-in.

 Maxun

 Maxun is an open-source, no-code platform for building robots that extract, scrape and crawl structured data from websites.

 Wikijs

 Wikijs is a powerful open-source wiki app built on Node.js, Git and Markdown.

 Neko Rooms

 Neko-Rooms is a simple room management system for n.eko. 

 Odoo ERP & CRM

 Odoo is a suite of web-based, open-source business apps.

 Matomo

 Matomo is a full-featured PHP MySQL software program that you download and install on your own webserver

 Redash

 Make Your Company Data Driven. Connect to any data source, easily visualize, dashboard and share your data.

 Fugu

 Fugu is a product analytics software with a strong focus on simplicity and privacy-friendliness.

 nopCommerce

 nopCommerce is the most popular ASP.NET shopping cart in the world based on Microsoft technologies. Free and open-source eCommerce platform.

 Mapzy

 A simple, self-hostable store finder that cares about your privacy.

 ChangeDetection

 Changedetection.io is an open source web page monitoring, notification and change detection.

 Mautic

 Mautic is a open source marketing automation software.

 Metabase

 Metabase is an open-source tool that simply and quickly gathers business intelligence and analytics for your company.

 MetabasePostgres

 Metabase is an open-source tool that simply and quickly gathers business intelligence and analytics for your company.

 Lightdash

 Lighdash an open source alternative to Looker built using dbt.

 Superset

 Apache Superset is a data visualization and data exploration platform.

 Unomi

 Apache Unomi stores user profile information and is mostly used to provide a backend server for A/B testing and personalization

 Zammad

 Zammad is a web-based, open-source helpdesk/customer support system.

 PostHog

 PostHog provides open-source product analytics, session recording, feature flagging and a/b testing that you can self-host.

 Moodle

 Moodle is the world's most popular open-source learning platform for educators to create their own websites.

 OpenProject

 OpenProject is a web-based project management system for location-independent team collaboration.

 ErpNext

 ERPNext is the leading open-source enterprise resource planning (ERP) software. 

 Penpot

 Penpot is the first open-source design and prototyping platform for cross-domain teams.

 Syncthing

 Syncthing is a free, continuous, multiple-device file synchronization program. 

 Jitsi

 Jitsi is a set of open-source projects that allows you to easily build and deploy secure video conferencing solutions. 

 Filestash

 Filestash is a Dropbox-like file manager that lets you manage your data anywhere it is located. 

 Outline

 Outline is a fast wiki and knowledge base for growing teams - an alternative to Google Docs. 

 Kimai

 Kimai is a free, open-source, online time-tracking software designed for small businesses and freelancers.

 BookStack

 BookStack is a platform to create documentation/wiki content built with PHP & Laravel.

 ownCloud

 ownCloud is a suite of client-server software for creating and using file hosting services. 

 InvoiceNinja

 Invoice Ninja is the leading free, open-source online invoicing app for freelancers and businesses. 

 KeeWeb

 KeeWeb is a free, open-source password manager, available as a web version and as a desktop app. 

 MediaCMS

 MediaCMS is a fully featured open-source video and media CMS.

 AzuraCast

 A self-hosted web radio management suite

 Mastodon

 Mastodon is a free fediverse, open-source social network server with OpenSearch for indexing.

 Paperless-ngx

 Paperless-ngx is an open-source document management system that digitizes, organizes, and archives your physical documents into a fully searchable online library.

 Zulip

 Zulip is a team collaboration tool with unique topic-based threading that combines the best of email and chat to make remote work productive and delightful.

 Taiga

 Your Agile, Free and Open Source Project Management Tool

 Shlink

 The definitive self-hosted URL shortener

 FocalBoard

 Project & Task Management for Software Development Teams

 Flarum

 Flarum is a delightfully simple discussion platform for your website

 HedgeDoc

 HedgeDoc is an open-source, web-based, self-hosted, collaborative markdown editor

 ArchiveBox

 ArchiveBox is a powerful, self-hosted internet archiving solution to collect, save, and view sites you want to preserve offline.

 Element

 Create your community based on Matrix protocol

 iTop

 iTop adapts to the needs of digital businesses to manage multiple customers, contracts and SLAs

 Fider

 Customer Feedback Made Easy

 Etherpad

 Etherpad is a highly customizable open source online editor providing collaborative editing in really real-time.

 Trudesk

 Trudesk is an open-source help desk/ticketing solution.

 MantisBT

 MantisBT makes collaboration with team members & clients easy, fast, and professional

 SuiteCRM

 SuiteCRM is an open source Customer Relationship Management (CRM) software solution that provides a 360-degree view of your customers and business.

 Ubuntu-Desktop

 Ubuntu Virtual Desktop experience in your browser

 Documize

 Free Knowledge Management Software

 MetaTrader5

 Trade on Forex & stock markets in a virtual desktop from your browser

 BTCPay

 Start Accepting Bitcoin Payments With 0% Fees & No Third-party

 PeerTube

 Free software to take back control of your videos for the Fediverse

 LanguageTool

 LanguageTool is an Open Source proofreading software for English, Spanish, French, German, Portuguese, Polish, Dutch, and more than 20 other languages.

 Docspell

 Simple document organizer

 RustdeskServer

 Open source virtual / remote desktop infrastructure for everyone!

 Shopware

 Shopware is a modern eCommerce platform connecting enterprise-level capabilities with flexibility

 Traduora

 Open Translation Management Platform. Teams use Ever Traduora to reach users all around the globe. Automate your translation workflow today

 ChiefOnboarding

 Create entire blueprints of what your new hire will go through within minutes. Simply drag and drop items into the timeline.

 Mealie

 Mealie is an intuitive and easy to use recipe management app

 Trilium

 Trilium Notes is a hierarchical note taking application with focus on building large personal knowledge bases.

 Affine

 More than Notion and Miro's next-generation knowledge base, AFFiNE unifies planning, sorting, and creation.

 WooCommerce

 WooCommerce is a customizable, open-source eCommerce platform built on WordPress.

 Castopod

 Self-host your podcasts with ease, keep control over what you create, and talk to your audience without any middleman. Your podcast and your audience belong to you and you only.

 Owncast

 Owncast is a free and open source live video and web chat server for use with existing popular broadcasting software.

 SearXNG

 SearXNG is a free internet metasearch engine which aggregates results from various search services and databases. Users are neither tracked nor profiled.

 Activepieces

 Activepieces is an open source alternative to Zapier, Make.com and Tray.io. Automate your work with our builder and connectors - host it on your machine.

 EspoCRM

 EspoCRM is a web application that allows users to see, enter and evaluate all your company relationships regardless of the type.

 Dremio

 The Easy and Open Data Lakehouse Self-service analytics with data warehouse functionality and data lake flexibility across all your data.

 Immich

 Self-hosted photo and video backup solution directly from your mobile phone.

 Picoshare

 PicoShare is a service for sharing images, videos, and other files.

 SerpBear

 SerpBear is an Open Source Search Engine Position Tracking App. It allows you to track your website's keyword positions in Google and get notified of their positions.

 Wekan

 Experience efficient task management with WeKan - the Open-Source, customizable, and privacy-focused Kanban.

 Typebot

 Typebot gives you powerful blocks to create unique chat experiences. Embed them anywhere on your web/mobile apps and start collecting results like the magic.

 Memos

 A lightweight, self-hosted memo hub. Open Source and Free forever.

 Flatnotes

 A self-hosted, database-less note-taking web app that utilizes a flat folder of markdown files for storage.

 Automatisch

 Automatisch helps you to automate your business processes without coding. Use our affordable cloud solution or self-host on your own servers.

 Friendica

 A Decentralized Social Network, you can use to host your own social media server that forms one part of the fediverse, an interconnected and decentralized network of independently operated servers

 Lemmy

 Open-source Reddit alternative. Create your own discussion platform with Lemmy

 KBIN

 A reddit-like content aggregator and micro-blogging platform for the fediverse.

 Yopass

 Yopass encryption mechanisms are built on open-source software meaning full transparency with the possibility to audit and submit features.

 Traggo

 Traggo is a tag-based time tracking tool. In Traggo there are no tasks, only tagged time spans.

 Infisical

 Infisical is an open-source, end-to-end encrypted platform for secret management: sync secrets across your team/infrastructure and prevents secret leaks.

 ILLA

 ILLA Cloud is a low-code platform. Anyone can build internal tools with ILLA Cloud in minutes.

 TotaljsFlow

 It's a friendly, modern, straightforward Visual Programming Interface for Low-code Development accessible through a web browser. The tool integrates, processes, and transforms various events and data in real-time.

 DocuSeal

 Open source, tool to streamline document filling and signing. Create custom PDF forms to complete and sign with an easy-to-use online tool.

 Rallly

 Rallly is the Doodle alternative scheduling and collaboration tool designed to make organizing events and meetings easier.

 LightLDAP

 A Lightweight authentication server that provides an opinionated, simplified LDAP interface for authentication. It integrates with many backends, from KeyCloak to Authelia to Nextcloud and more!

 Authelia

 Authelia is an authentication and authorization server and portal fulfilling the identity and access management (IAM) role of information security in providing multi-factor authentication and single sign-on (SSO) for your applications via a web portal. It

 Cal

 Calendly alternative Cal.com, is the event-juggling scheduler for everyone. Focus on meetings, not making meetings. Free for individuals.

 Tracardi

 TRACARDI is a new HOME for your customer data. TRACARDI is an API-first solution, a low-code / no-code platform aimed at any e-commerce business that wants to start using user data for marketing purposes.

 MiroTalk

 WebRTC - P2P - Simple, Secure, Fast Real-Time Video Conferences Up to 4k and 60fps, compatible with all browsers and platforms.

 Twenty

 Open-source CRM, Building a modern alternative to Salesforce, powered by the community.

 Hyperswitch

 An open-source payments switch written in Rust to make payments fast, reliable, and affordable.

 FrappeHR

 Frappe HR (ERPNext HRMS) is a user-friendly solution designed to streamline HR and payroll operations, driving excellence within your team.

 Akaunting

 Online accounting software for small businesses and freelancers. Send invoices and track expenses on the cloud.

 MintHCM

 Human Capital Management system (HCM) that you can start using today to manage your HR departments and businesses in different branches.

 Parseable

 Parseable is a log analytics system platform for modern, cloud-native workloads

 Jibri

 Jibri provides services for recording or streaming a Jitsi Meet conference.

 Karakeep

 Karakeep (formerly Hoarder) is a self-hostable bookmark-everything app that uses AI to automatically organize what you save.

## Frequently Asked Questions about Applications 
 Here are some most commonly asked questions

 What is managed Applications hosting on Elestio? 

 Elestio provides fully managed hosting for Applications tools on dedicated cloud infrastructure. We handle installation, configuration, security, automated backups, SSL certificates, OS updates, and 24/7 monitoring so you can focus on building your product instead of managing servers.

 How much does managed Applications hosting cost? 

 Elestio pricing starts at $14 per month for a dedicated virtual machine. Every plan includes automated backups, SSL certificates, security updates, OS patches, and 24/7 monitoring with no hidden fees. You can choose from 9 cloud providers and 100+ regions worldwide.

 What's included with every Applications deployment? 

 Every deployment includes: dedicated VM (not shared containers), automated daily backups, free SSL certificates, automatic security patches and OS updates, 24/7 uptime monitoring with alerts, DNS and SMTP configuration, built-in tools (VSCode, File Explorer, Web Terminal), and API/CLI access. All managed by Elestio's DevOps team.

 How do I get started with Applications on Elestio? 

 Getting started takes just a few minutes: choose your software from the catalog, select a cloud provider and region, pick your VM size, and click deploy. Elestio handles the rest: installation, configuration, SSL, DNS, and monitoring are all set up automatically.

 Can I migrate my existing Applications services to Elestio? 

 Yes, Elestio supports migration from self-hosted or other cloud-hosted services. You get full SSH access to your dedicated VM, making it easy to import data and configurations. Elestio's support team can also assist with migration planning and execution.

 The managed DevOps platform. Deploy 400+ open-source tools on any cloud. We handle the rest.

 ISO 27001 
 SOC2 
 HIPAA 
 GDPR 

#### Services 

 Databases 

 Applications 

 Dev Tools 

 Hosting 

 All Services 

#### Platform 

 Pricing 

 CI/CD 

 AI Skills 

 Terraform 

 Use Cases 

 API 

#### Company 

 What is Elestio? 

 About 

 Press Kit 

 Blog 

 Security 

 Status 

 Support 

#### Resources 

 Documentation 

 Use Cases 

 Community 

 Terms of Service 

 Enterprise Support 

 Contact 

#### Compare 

 Elestio vs Heroku 

 Elestio vs Railway 

 Elestio vs Render 

 Elestio vs Self-Hosting 

 Elestio vs Coolify 

 © 2026 Elestio. All rights reserved. 
 29 Merrion Square, Dublin 2, D02 RW64, Ireland 

### We use cookies 
 This website uses technologies such as cookies to enable essential site functionality, as well as for analytics and personalization. Learn more in our Privacy Policy .

 Accept 
 Decline