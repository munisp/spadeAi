https://elest.io/managed-postgresql-on-tcloud

Managed database on T Cloud 

# Managed PostgreSQL on your own T Cloud account 
 Production PostgreSQL deployed on an Elastic Cloud Server inside the T Cloud Public (formerly Open Telekom Cloud) account you already hold. Automated daily backups, volumes encrypted with your own key, 24/7 monitoring, and root access that stays yours.

 Connect Your T Cloud Account 
 Managed services for T Cloud 

 Runs in your own T Cloud tenancy 
 Encrypted with a key you own 
 Automated daily backups 

 What you get

## Production PostgreSQL, operated inside your own account 
 Deployed on an Elastic Cloud Server in your T Cloud tenancy, with the operational work handled and full root access retained.

### Deployed and configured for production 
 PostgreSQL provisioned on your own Elastic Cloud Server instance, Docker-based and pre-configured, with sensible defaults rather than a blank server and an install guide.

### Automated daily backups 
 Automated daily backups with a retention window that follows your support level: 7 days on Level 1, 14 on Level 2, 30 on Level 3. Restores are part of the service, not a runbook you hope works.

### Encrypted volumes with your own key 
 The root volume is encrypted at creation using the evs/default key that already exists in your T Cloud account. Elestio has read-only access to that key and cannot rotate or delete it.

### Network exposure you control 
 Firewall and security group rules configured and maintained, so the database is reachable by what should reach it and nothing else. SSL certificates issued and renewed automatically.

### Monitoring that pages someone else 
 24/7 uptime and resource monitoring with alerting and proactive intervention, up to a 99.9% SLA with a 4 hour response commitment (business hours) on Level 3.

### No lock-in on the data or the host 
 Full root access to the instance, standard PostgreSQL dump and restore, and the ability to clone or migrate the service to any of the 9 cloud providers Elestio supports.

 Operations

## Who does what once it is running 
 The database is in your account. The operational work is not on your team.

 Task

 Self-managed PostgreSQL

 Managed by Elestio

 Initial deployment and hardening

 Hours to days per instance

 ✓ One click

 Minor version updates

 Manual tracking and execution

 ✓ Applied automatically

 Major version upgrades

 A project on its own

 ✓ Reviewed and applied from the dashboard

 OS patching underneath

 Yours

 ✓ Automated

 Daily backups

 Scripted by you

 ✓ Automated daily backups

 Backup restore testing

 Usually skipped

 ✓ Part of the service

 SSL certificate lifecycle

 Manual renewal

 ✓ Issued and renewed automatically

 Firewall rules

 Hand-maintained

 ✓ Configured and maintained

 Out of hours alerting

 Your on-call rota

 ✓ 24/7 with intervention

 Root access to the server

 Yours

 ✓ Still yours

 Where the data lives

 Your T Cloud account

 ✓ Your T Cloud account, unchanged

 Pricing

## What a managed PostgreSQL instance costs 
 Two invoices. Deutsche Telekom bills the infrastructure on your existing account, Elestio bills the management fee hourly.

 Small
 2 vCPU · 4 GB RAM · 80 GB disk
 $22 /mo 
 $10 CPU + $10 RAM + $2 disk

 Medium
 4 vCPU · 8 GB RAM · 160 GB disk
 $44 /mo 
 $20 CPU + $20 RAM + $4 disk

 Large
 8 vCPU · 16 GB RAM · 320 GB disk
 $88 /mo 
 $40 CPU + $40 RAM + $8 disk

 Elestio management fees only, billed hourly. Your T Cloud Elastic Cloud Server and Elastic Volume Service costs are billed separately and directly by Deutsche Telekom on your existing account, so committed volume and negotiated discounts still apply. 

 Reviews

## Trusted by 10,000+ Developers Worldwide 
 Real reviews from real users on Trustpilot.

 “

 ★★★★★

 "I'm in the IT industry for over 25 years and Elestio stands out in many ways. The managed services are top-notch, support is incredibly fast, and the platform just works. Couldn't be better!"

 Conflock 
 IT Director · Germany · Verified on Trustpilot 

 See all reviews on Trustpilot

 FAQ

## Frequently Asked Questions 

 Where does the database actually run? 

 On an Elastic Cloud Server instance inside your own T Cloud account, in the region your tenancy uses. Elestio provisions and operates it there. The data never sits on Elestio infrastructure and your contract with Deutsche Telekom is unchanged.

 Do we still get root access? 

 Yes. You keep full root access to the instance and standard PostgreSQL dump and restore. Managed does not mean locked. You can also clone or migrate the service to any of the 9 cloud providers Elestio supports.

 How are backups handled? 

 Automated daily backups. Remote retention follows your support level: 7 days on Level 1, 14 days on Level 2, 30 days on Level 3, and custom retention on request. Restores are part of the managed service.

 Is the data encrypted at rest? 

 Yes. The root volume is encrypted at creation using the evs/default key that already exists in your own T Cloud account. Elestio holds read-only access to that key and cannot create, rotate, disable or delete it.

 How are version upgrades handled? 

 Minor versions and OS patches are applied automatically. Major version upgrades are surfaced in the dashboard so you review and apply them when it suits you, and a backup is always taken before an update.

 What does it cost? 

 Two separate lines. Elestio charges a management fee of $5 per vCPU plus $2.50 per GB RAM plus $0.025 per GB disk, billed hourly, so a 4 vCPU, 8 GB RAM, 160 GB instance is $44 per month. Deutsche Telekom bills the underlying Elastic Cloud Server and storage directly on your own account.

 Can you manage databases we already run? 

 Talk to the team about your setup. Elestio provisions and operates services inside your account, and the right approach depends on how your existing instance was deployed.

 More on T Cloud

 Managed services for T Cloud Access and security model Shared responsibility and SLA In-house vs managed Public sector Deploy on T Cloud Bring your own T Cloud account AWS vs T Cloud Azure vs T Cloud 

## Stop being your own DBA 
 PostgreSQL in your own T Cloud account, operated around the clock, with root access that stays yours.

 Get Started