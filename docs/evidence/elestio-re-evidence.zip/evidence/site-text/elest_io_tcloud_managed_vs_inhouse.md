https://elest.io/tcloud-managed-vs-inhouse

Build or outsource 

# Open source on T Cloud: in-house or managed 
 The patching, the backups, the certificate rotation and the 3am pager do not go away when you self-host on T Cloud Public, formerly Open Telekom Cloud. They get assigned to someone. This page puts the two options side by side with a pricing formula you can compute yourself.

 Connect Your T Cloud Account 
 Managed services for T Cloud 

 Same account, same jurisdiction 
 Formula pricing, no quote needed 
 Scales down as well as up 

 The real question

## The work does not disappear. It just moves. 
 Nobody decides between having operations and not having them. You decide who is accountable, and what that accountability costs in salary, attention and risk.

### What running open source in-house actually contains 

 Continuous CVE monitoring across every component you self-host, including the ones nobody remembers installing.

 OS patching on a schedule that survives a busy quarter, not one that slips the moment a release is due.

 Version upgrades researched, staged and executed per service, each with its own breaking changes.

 Backups that are actually restore-tested , which is a different task from backups that run.

 Certificate rotation before expiry rather than during the outage it causes.

 24/7 monitoring and an on-call rota , which requires enough people to make a rota humane.

 None of this is difficult work. All of it is relentless, and it competes directly with the roadmap every single week.

 Side by side

## In-house operations versus Elestio on your own T Cloud Public account 
 Same infrastructure, same account, same jurisdiction. The difference is who carries the operational load.

 In-house

 Elestio on your T Cloud account

 Where the virtual machines run

 Your T Cloud account

 ✓ Your T Cloud account, unchanged

 Who holds the Telekom contract

 You

 ✓ You, unchanged

 Time to deploy a new service

 Days of setup and hardening

 ✓ One click from 400+ services

 Patching and CVE response

 Manual, competes with the roadmap

 ✓ Automated and continuous

 Backup verification

 Rarely done honestly

 ✓ Automated daily backups

 Out of hours incidents

 Your on-call rota

 ✓ 24/7 monitoring and intervention

 Uptime commitment

 Best effort

 ✓ Up to 99.9% with a 4 hour response (business hours)

 Cost shape

 Salaried headcount, fixed

 ✓ Per resource, hourly, scales down too

 Key person risk

 High, one engineer knows the stack

 ✓ Removed, the runbook is the product

 If you stop

 Nothing changes

 ✓ Infrastructure stays, you keep root access

 Worked example

## What twenty services cost to have managed 
 The Elestio fee is a formula, so you can compute your own number rather than ask for a quote.

 $5
 per vCPU

 $2.50
 per GB RAM

 $0.025
 per GB disk

 5 services
 4 vCPU · 8 GB · 160 GB each
 $220 /mo 
 $44 per service in management fees

 20 services
 4 vCPU · 8 GB · 160 GB each
 $880 /mo 
 $44 per service in management fees

 50 services
 4 vCPU · 8 GB · 160 GB each
 $2,200 /mo 
 $44 per service in management fees

 Management fees only, billed hourly. T Cloud infrastructure is billed separately and directly by Deutsche Telekom on your own account. Support Level 2 adds $50 per service per month for a 99.5% SLA, Level 3 adds $200 for 99.9% and a 4 hour response (business hours). Compare the total against the fully loaded cost of the engineering time it replaces at your own rates. 

 Beyond cost

## The two arguments that usually decide it 
 Budget holders start with the monthly number. They sign for different reasons.

### Key person risk is the quiet one 
 In most organizations, one engineer knows how the stack is really wired. When that person takes a new job, the knowledge leaves with them. Handing operations to a provider converts a person-shaped dependency into a contract with a response time attached.

### Opportunity cost is the expensive one 
 Every hour spent patching a wiki or rotating a certificate is an hour not spent on the thing your organization is actually judged on. That cost never appears on any invoice, which is exactly why it goes unmanaged for years.

 Reviews

## Trusted by 10,000+ Developers Worldwide 
 Real reviews from real users on Trustpilot.

 “

 ★★★★★

 "I'm in the IT industry for over 25 years and Elestio stands out in many ways. The managed services are top-notch, support is incredibly fast, and the platform just works. Couldn't be better!"

 Conflock 
 IT Director · Germany · Verified on Trustpilot 

 See all reviews on Trustpilot

 FAQ

## Frequently Asked Questions 

 Is this cheaper than hiring? 

 That depends entirely on your own loaded cost per engineer, which is why the pricing is a formula rather than a quote. Compute your total with $5 per vCPU plus $2.50 per GB RAM plus $0.025 per GB disk across the services you would hand over, add support level if you need an SLA, and compare it against the fully loaded cost of the engineering time it replaces at your rates.

 Do we lose control by outsourcing operations? 

 No. You keep full root access to every server, the virtual machines stay in your own T Cloud account, and your contract with Deutsche Telekom is unchanged. Elestio access runs through a dedicated IAM user that you can revoke from your own console at any time.

 What if we only want some services managed? 

 That works. The fee is charged per managed service based on its resources, so you can hand over the twenty things that are pure operational overhead and keep the ones your team genuinely wants to own.

 Does the cost scale down if we shrink? 

 Yes. Management fees are billed hourly on actual resources, so reducing instance sizes or removing services reduces the fee immediately. Salaried headcount does not behave that way.

 What happens to our existing Telekom discount? 

 It is untouched. Deutsche Telekom bills your infrastructure directly on your existing account, so committed volume and negotiated discounts still apply. Elestio never sits in that billing relationship.

 What if we want to leave later? 

 The infrastructure is already yours and stays where it is. Revoke the IAM user in your own console and the servers keep running unmanaged. You can also clone or migrate managed services to any of the 9 cloud providers Elestio supports.

 More on T Cloud

 Managed services for T Cloud Access and security model Shared responsibility and SLA Public sector Managed PostgreSQL Deploy on T Cloud Bring your own T Cloud account AWS vs T Cloud Azure vs T Cloud 

## Compute your number, then decide 
 Same infrastructure, same account. The only variable is who carries the operational load.

 Get Started