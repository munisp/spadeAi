https://elest.io/fully-managed-services/databases

Databases | Managed Open-Source | Elestio 

 Managed services ▾ 

 Databases 
 PostgreSQL, MySQL, Redis, MongoDB & more 

 Applications 
 n8n, WordPress, Supabase, Keycloak & more 

 Development 
 CI/CD tools, IDE, Git hosting & version control 

 Hosting & Infrastructure 
 Servers, containers, monitoring & storage 

 AI & GPU 
 LLMs, AI frameworks, GPU-powered inference tools 

 View all 400+ services → 

 Features ▾ 

 Domains 
 Custom domains & SSL for your services 

 CI/CD 
 Automated deployment pipelines 

 Terraform 
 Infrastructure as code provider 

 Clusters 
 High availability & multi-node scaling 

 AI ▾ 

 AI DevOps 
 Describe an issue, AI fixes your server 

 Agents 
 Deploy with AI coding agents 

 AI & Automation 
 Automate your infrastructure workflows 

 Vibecoder 
 AI-powered app development & deployment 

 Resources ▾ 

 Documentation 
 Guides, API reference & tutorials 

 Blog 
 Product news, engineering & updates 

 Use Cases 
 Real customer success stories 

 Community 
 Join the discussion on Discord 

 Pricing 

 Login 
 Get Started 

 Managed services ▾

 Databases 
 Applications 
 Development 
 Hosting & Infrastructure 
 AI & GPU 
 All Services 

 Features ▾

 Domains 
 CI/CD 
 Terraform 
 Clusters 

 AI ▾

 AI DevOps 
 Agents 
 AI & Automation 
 Vibecoder 

 Resources ▾

 Documentation 
 Blog 
 Use Cases 
 Community 

 Pricing 
 Documentation 

 Login 
 Get Started 

 Fully Managed 

# Databases 
 Explore a comprehensive list of open source database software solutions. Discover reliable, community-driven database management tools for various applications and use cases. From relational databases to NoSQL options, find the right open source database software to suit your project's requirements.

 Databases 
 Applications 
 Dev Tools 
 Hosting & Infrastructure 
 AI & GPU 
 All Services 

 Relational databases NoSQL Specialized Databases 

 Search from 400+ open-source software 

 PostgreSQL

 PostgreSQL is a powerful, open-source object-relational database system, known for reliability, data integrity and performance.

 MySQL

 MySQL is an Oracle-backed open-source RDBMS that runs on almost all platforms.

 MariaDB

 The open source relational database

 ColumnStore

 MariaDB ColumnStore is a GPLv2 open-source columnar database built on MariaDB Server.

 Redis

 Redis is an open-source, in-memory database, cache and message broker. 

 Valkey

 A flexible distributed key-value datastore that supports both caching and beyond caching workloads.

 pgvector

 Open-source vector similarity search for Postgres

 postGis

 PostGIS extends the capabilities of the PostgreSQL relational database by adding support for storing, indexing, and querying geospatial data.

 pgDuckDB

 DuckDB's columnar-vectorized analytics engine into PostgreSQL, enabling high-performance analytics and data-intensive applications

 KeyDB

 KeyDB is both your cache and database, for cloud-optimized solutions.

 TimescaleDB

 TimescaleDB is the leading open-source relational database with support for time-series data. 

 ClickHouse

 ClickHouse is an open-source, column-oriented DBMS for online analytical processing. 

 ClickHouseS3

 ClickHouse + S3 is an open-source, column-oriented DBMS for online analytical processing. 

 ScyllaDB

 ScyllaDB is a true NoSQL database for the most demanding applications. 

 InfluxDB

 InfluxDB is a scalable datastore that empowers developers to build IoT, analytics and monitoring software. 

 MSSQL

 SQL Server is a modern data platform designed to tackle the challenges of today's data professional.

 Chromadb

 The AI-native open-source embedding database

 Milvus

 The High-Performance Vector Database Built for Scale

 Neo4j

 Neo4j is the world’s leading Graph Database

 Kafka

 Apache Kafka is an open-source platform for high-performance data pipelines, streaming analytics, data integration and mission-critical applications. 

 M3DB

 M3 is a Prometheus compatible, easy to adopt metrics engine

 OpenSearch

 Open source distributed and RESTful search engine.

 ImmuDB

 immutable ledger database based on zero trust, SQL and Key-Value, tamperproof, data change history

 Cassandra

 Open Source NoSQL Database

 Weaviate

 Weaviate is an open-source vector database. It allows you to store data objects and vector embeddings from your favorite ML models, and scale seamlessly into billions of data objects.

 FerretDB

 Documents DB, built on Postgres. FerretDB allows you to use MongoDB drivers seamlessly with PostgreSQL as the database backend. Use all tools, drivers, UIs, and the same query language and stay open-source.

## Frequently Asked Questions about Databases 
 Here are some most commonly asked questions

 What is managed Databases hosting on Elestio? 

 Elestio provides fully managed hosting for Databases tools on dedicated cloud infrastructure. We handle installation, configuration, security, automated backups, SSL certificates, OS updates, and 24/7 monitoring so you can focus on building your product instead of managing servers.

 How much does managed Databases hosting cost? 

 Elestio pricing starts at $14 per month for a dedicated virtual machine. Every plan includes automated backups, SSL certificates, security updates, OS patches, and 24/7 monitoring with no hidden fees. You can choose from 9 cloud providers and 100+ regions worldwide.

 What's included with every Databases deployment? 

 Every deployment includes: dedicated VM (not shared containers), automated daily backups, free SSL certificates, automatic security patches and OS updates, 24/7 uptime monitoring with alerts, DNS and SMTP configuration, built-in tools (VSCode, File Explorer, Web Terminal), and API/CLI access. All managed by Elestio's DevOps team.

 How do I get started with Databases on Elestio? 

 Getting started takes just a few minutes: choose your software from the catalog, select a cloud provider and region, pick your VM size, and click deploy. Elestio handles the rest: installation, configuration, SSL, DNS, and monitoring are all set up automatically.

 Can I migrate my existing Databases services to Elestio? 

 Yes, Elestio supports migration from self-hosted or other cloud-hosted services. You get full SSH access to your dedicated VM, making it easy to import data and configurations. Elestio's support team can also assist with migration planning and execution.

 The managed DevOps platform. Deploy 400+ open-source tools on any cloud. We handle the rest.

 ISO 27001 
 SOC2 
 HIPAA 
 GDPR 

#### Services 

 Databases 

 Applications 

 Dev Tools 

 Hosting 

 All Services 

#### Platform 

 Pricing 

 CI/CD 

 AI Skills 

 Terraform 

 Use Cases 

 API 

#### Company 

 What is Elestio? 

 About 

 Press Kit 

 Blog 

 Security 

 Status 

 Support 

#### Resources 

 Documentation 

 Use Cases 

 Community 

 Terms of Service 

 Enterprise Support 

 Contact 

#### Compare 

 Elestio vs Heroku 

 Elestio vs Railway 

 Elestio vs Render 

 Elestio vs Self-Hosting 

 Elestio vs Coolify 

 © 2026 Elestio. All rights reserved. 
 29 Merrion Square, Dublin 2, D02 RW64, Ireland 

### We use cookies 
 This website uses technologies such as cookies to enable essential site functionality, as well as for analytics and personalization. Learn more in our Privacy Policy .

 Accept 
 Decline