https://elest.io/deploy-on-azure

Bring Your Own Azure Account 

# Deploy on Azure with Elestio 
 Use your own Azure subscription. Elestio deploys and manages 400+ open-source services on your Azure VMs. You pay Microsoft directly for infrastructure. We handle backups, updates, monitoring, SSL, and security.

 Connect Your Azure Account 
 Read the Docs 

 Your Azure subscription, your control

 Keep your Azure credits & EA discounts

 60+ Azure regions

 How it works

## Bring Your Own Azure Account in 3 steps 
 Connect your Azure subscription via OAuth, and Elestio handles the rest. Full ownership stays with you.

### Connect your Azure subscription 
 Authenticate via Azure Active Directory with OAuth. Grant Elestio Contributor role access on your subscription. Elestio gets permission to create and manage VMs, disks, networks, and storage in your account.

### Pick from 400+ open-source tools 
 Databases, applications, dev tools, ai workloads. select your vm size and azure region from 60+ locations worldwide.

### Elestio deploys & manages 
 We deploy on your Azure VMs and handle all operations: automated backups, OS & software updates, SSL, monitoring, firewall, and security hardening.

 Fully managed

## What Elestio handles on your Azure subscription 
 You keep full ownership of your Azure subscription. Elestio takes care of all the operational work.

### Automated Deployment 
 One-click deployment of 400+ open-source tools on your Azure VMs. Docker-based, pre-configured, ready to use.

### Security & SSL 
 Automatic SSL certificates, NSG firewall rules, security hardening, and vulnerability monitoring on every deployment.

### Updates & Backups 
 Daily automated backups via Azure Recovery Services. OS patches and software updates applied automatically.

### Monitoring & Alerts 
 24/7 uptime monitoring, resource usage tracking, and instant alerts. Proactive intervention before issues impact users.

 Pricing

## Transparent management pricing 
 You pay Microsoft Azure directly for your VM infrastructure costs. Elestio charges a separate management fee based on your instance specifications:

 $5

 per vCPU

 $2.50

 per GB RAM

 $0.025

 per GB disk

 Small

 2 vCPU · 4 GB RAM · 80 GB disk

 $22 /mo 

 $10 CPU + $10 RAM + $2 disk

 Medium

 4 vCPU · 8 GB RAM · 160 GB disk

 $44 /mo 

 $20 CPU + $20 RAM + $4 disk

 Large

 8 vCPU · 16 GB RAM · 320 GB disk

 $88 /mo 

 $40 CPU + $40 RAM + $8 disk

 These are Elestio management fees only. Azure infrastructure costs are billed separately by Microsoft on your own Azure subscription. Your existing Azure credits and Enterprise Agreement discounts apply. 

 Reviews

## Trusted by 10,000+ Developers Worldwide 
 Real reviews from real users on Trustpilot.

 “

 ★★★★★

 "I'm in the IT industry for over 25 years and Elestio stands out in many ways. The managed services are top-notch, support is incredibly fast, and the platform just works. Couldn't be better!"

 Conflock 
 IT Director · Germany · Verified on Trustpilot 

 See all reviews on Trustpilot

 FAQ

## Frequently Asked Questions 

 What is Bring Your Own Azure Account? 

 BYO Azure lets you connect your existing Azure subscription to Elestio. Instead of using Elestio's shared infrastructure, Elestio creates and manages virtual machines directly in your Azure subscription. You pay Microsoft directly for all infrastructure costs (compute, storage, bandwidth), and Elestio charges a separate management fee for handling deployments, backups, updates, monitoring, SSL, and security hardening.

 How does BYO Azure pricing work? 

 You pay two separate costs: Azure infrastructure costs billed directly by Microsoft (VMs, managed disks, bandwidth), plus an Elestio management fee calculated as $5 per vCPU + $2.50 per GB RAM + $0.025 per GB disk. For example, a 2 vCPU, 4 GB RAM, 80 GB instance costs $22/month in Elestio management fees, plus whatever Azure charges for that VM. All your existing Azure credits, Enterprise Agreement discounts, and reserved instances apply.

 What does Elestio manage on my Azure subscription? 

 Elestio handles the full operational stack: automated deployment of 400+ open-source tools, daily backups via Azure Recovery Services, OS and software updates, SSL certificate management, 24/7 monitoring and alerting, NSG firewall configuration, and security hardening. Elestio creates resource groups, VMs, managed disks, virtual networks, network interfaces, public IPs, and storage accounts in your subscription. You keep full visibility of all resources in your Azure portal.

 What Azure permissions does Elestio need? 

 Elestio requires the Contributor role on your Azure subscription, granted via OAuth through Azure Active Directory. You need a Global Administrator, Privileged Role Administrator, or Application role in Azure AD. The connection uses the Azure Resource Manager scope for user impersonation. A step-by-step setup guide is available in our documentation .

 Which Azure regions are supported? 

 Elestio supports all 60+ Azure regions worldwide. You can deploy in any region available in your Azure subscription, including East US (Virginia), West Europe (Netherlands), Southeast Asia (Singapore), UK South (London), Central US (Iowa), Japan East (Tokyo), Australia East (Sydney), and many more.

 Can I keep my existing Azure credits and Enterprise Agreement? 

 Yes. Since you pay Microsoft directly for infrastructure, all your existing credits, Enterprise Agreement discounts, reserved instances, MSDN/Visual Studio benefits, and Azure Hybrid Benefit apply normally. Elestio's management fee is completely separate from your Azure billing.

## Connect your Azure subscription and deploy in minutes 
 Keep your Azure infrastructure. Let Elestio manage the operations.

 Get Started