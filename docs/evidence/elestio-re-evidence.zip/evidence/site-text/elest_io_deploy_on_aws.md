https://elest.io/deploy-on-aws

Bring Your Own AWS Account 

# Deploy on AWS EC2 with Elestio 
 Use your own AWS account. Elestio deploys and manages 400+ open-source services on your EC2 instances. You pay AWS directly for infrastructure. We handle backups, updates, monitoring, SSL, and security.

 Connect Your AWS Account 
 Read the Docs 

 Your AWS account, your control

 Keep your AWS credits & discounts

 27+ AWS regions

 How it works

## Bring Your Own AWS Account in 3 steps 
 Connect your AWS account, and Elestio handles the rest. You keep full ownership of your infrastructure.

### Connect your AWS account 
 Link your AWS account to Elestio using IAM credentials. Elestio gets permission to create and manage EC2 instances, security groups, volumes, and snapshots in your account.

### Pick from 400+ open-source tools 
 Databases, applications, dev tools, ai workloads. select your ec2 instance size and aws region.

### Elestio deploys & manages 
 We deploy on your EC2 instances and handle all operations: automated backups, OS & software updates, SSL, monitoring, firewall, and security hardening.

 Fully managed

## What Elestio handles on your AWS account 
 You keep full ownership of your AWS account. Elestio takes care of all the operational work.

### Automated Deployment 
 One-click deployment of 400+ open-source tools on your EC2 instances. Docker-based, pre-configured, ready to use.

### Security & SSL 
 Automatic SSL certificates, firewall rules, security hardening, and vulnerability monitoring on every deployment.

### Updates & Backups 
 Daily automated backups. OS patches and software updates applied automatically.

### Monitoring & Alerts 
 24/7 uptime monitoring, resource usage tracking, and instant alerts. Proactive intervention before issues impact users.

 Pricing

## Transparent management pricing 
 You pay AWS directly for your EC2 infrastructure costs. Elestio charges a separate management fee based on your instance specifications:

 $5

 per vCPU

 $2.50

 per GB RAM

 $0.025

 per GB disk

 Small

 2 vCPU · 4 GB RAM · 80 GB disk

 $22 /mo 

 $10 CPU + $10 RAM + $2 disk

 Medium

 4 vCPU · 8 GB RAM · 160 GB disk

 $44 /mo 

 $20 CPU + $20 RAM + $4 disk

 Large

 8 vCPU · 16 GB RAM · 320 GB disk

 $88 /mo 

 $40 CPU + $40 RAM + $8 disk

 These are Elestio management fees only. AWS EC2 infrastructure costs are billed separately by Amazon on your own AWS account. Your existing AWS credits and discounts apply. 

 Reviews

## Trusted by 10,000+ Developers Worldwide 
 Real reviews from real users on Trustpilot.

 “

 ★★★★★

 "I'm in the IT industry for over 25 years and Elestio stands out in many ways. The managed services are top-notch, support is incredibly fast, and the platform just works. Couldn't be better!"

 Conflock 
 IT Director · Germany · Verified on Trustpilot 

 See all reviews on Trustpilot

 FAQ

## Frequently Asked Questions 

 What is Bring Your Own AWS Account (BYOAWS)? 

 BYOAWS lets you connect your existing AWS account to Elestio. Instead of using Elestio's shared infrastructure, Elestio creates and manages EC2 instances directly in your AWS account. You pay AWS directly for all infrastructure costs (compute, storage, bandwidth), and Elestio charges a separate management fee for handling deployments, backups, updates, monitoring, SSL, and security hardening.

 How does BYO AWS pricing work? 

 You pay two separate costs: AWS infrastructure costs billed directly by Amazon (EC2 instances, storage, bandwidth), plus an Elestio management fee calculated as $5 per vCPU + $2.50 per GB RAM + $0.025 per GB disk. For example, a 2 vCPU, 4 GB RAM, 80 GB instance costs $22/month in Elestio management fees, plus whatever AWS charges for that EC2 instance. All your existing AWS credits, reserved instances, and savings plans apply.

 What does Elestio manage on my AWS account? 

 Elestio handles the full operational stack: automated deployment of 400+ open-source tools, daily backups with snapshots, OS and software updates, SSL certificate management, 24/7 monitoring and alerting, firewall configuration, and security hardening. You keep full ownership and visibility of all resources in your AWS console.

 What AWS permissions does Elestio need? 

 Elestio needs IAM credentials with permissions to manage EC2 instances, security groups, elastic IPs, EBS volumes, and snapshots. A step-by-step setup guide is available in our documentation . Elestio operates with the minimum permissions needed and does not modify your IAM policies or billing settings.

 Which AWS regions are supported? 

 Elestio supports 27+ AWS EC2 regions across North America, Europe, Asia Pacific, South America, Africa, and the Middle East. You can deploy in any region available in your AWS account, including US East (Virginia, Ohio), US West (Oregon, N. California), EU (Ireland, Frankfurt, London, Paris, Stockholm), Asia Pacific (Tokyo, Singapore, Sydney, Mumbai), and more.

 Can I keep my existing AWS credits and discounts? 

 Yes. Since you pay AWS directly for infrastructure, all your existing credits, reserved instances, savings plans, and enterprise discount programs (EDP) apply normally. Elestio's management fee is completely separate from your AWS billing.

## Connect your AWS account and deploy in minutes 
 Keep your AWS infrastructure. Let Elestio manage the operations.

 Get Started