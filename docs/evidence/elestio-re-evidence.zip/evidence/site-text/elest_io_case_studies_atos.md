https://elest.io/case-studies/atos

All success stories Customer success story

# Scaling deployments on Elestio, from CI/CD to AI environments Global IT and cloud services · Europe and the United States

## What five years on Elestio look like A client since the earliest days of the platform, now deploying a growing range of applications, internal tools and infrastructure services.

 5+ years
 On Elestio, since the earliest days of the platform

 EU and US
 Teams deploying across both regions

 One platform
 From CI/CD pipelines to AI environments

## Who is Atos Atos is a global leader in digital transformation, cybersecurity and cloud services, operating worldwide with teams across Europe, the United States and beyond.

## A long-standing relationship Atos has been an Elestio customer from the very beginning, for more than five years. That longevity reflects a relationship built on trust: Atos's teams have relied on Elestio to deploy and run services for years, and they continue to expand their usage.

## An accelerating footprint Rather than a static deployment, Atos's use of Elestio is accelerating, with several new services rolled out in just the last couple of months. The platform has become a natural, repeatable way for Atos teams to ship what they need, when they need it.

## What Atos deploys on Elestio CI/CD delivery
 Application front ends and back ends, deployed from GitHub and GitLab

 Databases
 PostgreSQL, ClickHouse

 BI & analytics
 Superset

 Identity
 Keycloak

 Infrastructure tools
 Guacamole bastion host, Uptime Kuma monitoring, Centrifugo realtime messaging, Squid gateway

 AI development
 AI development environments and AI coding tools

## Why it matters For a group of Atos's scale, Elestio provides a single, consistent platform to deploy a broad and growing range of services, from CI/CD application delivery to databases, analytics, identity, infrastructure tooling and AI development environments, reliably and securely across geographies. A relationship that has lasted more than five years, and keeps growing, is the clearest signal of the value it delivers.

### Ready to scale your deployments? Deploy CI/CD, databases, and AI environments on one managed platform.

 Talk to an expert Deploy now