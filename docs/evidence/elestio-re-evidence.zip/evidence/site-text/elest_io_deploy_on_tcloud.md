https://elest.io/deploy-on-tcloud

Enterprise managed services for T Cloud 

# Deploy on T Cloud with Elestio 
 Already running T Cloud Public (formerly Open Telekom Cloud), the sovereign German cloud? Elestio deploys and operates 400+ open-source services inside the account you already have. Nothing migrates. Your Elastic Cloud Server instances, your Deutsche Telekom contract and your compliance posture stay exactly where they are. We add the operations layer on top.

 Connect Your T Cloud Account 
 Managed services for T Cloud 

 No migration, your account stays yours 
 Scoped IAM access, revocable at any time 
 Your Deutsche Telekom contract untouched 

 How it works

## Three steps, and none of them is a migration 
 There is no lift and shift phase, no cutover weekend and no parallel run. Elestio provisions inside the account you already hold, under your own contract with Deutsche Telekom. Most engagements are running the same week they are approved.

### You create a scoped IAM user 
 A dedicated user in your T Cloud console with six explicit policies. Not your root credentials, not a shared account. You hand over three values: an Access Key, a Secret Key and your account Domain Name.

### You choose what we operate 
 Databases, applications, dev tools, AI workloads, from a catalog of 400+. Select the Elastic Cloud Server size and the region inside your own tenancy.

### We take over the operations 
 Deployment, daily backups, OS and software updates, SSL certificates, firewall rules, 24/7 monitoring and security hardening. You keep full root access throughout.

 Fully managed

## What Elestio handles on your T Cloud Public account 
 You keep full ownership of your T Cloud account. Elestio takes care of all the operational work.

### Automated Deployment 
 One-click deployment of 400+ open-source tools on your Elastic Cloud Server instances. Docker-based, pre-configured, ready to use.

### Security & Encrypted Disks 
 Automatic SSL certificates, firewall rules, security hardening, and EVS volumes encrypted with the default key that lives in your own account.

### Updates & Backups 
 Daily automated backups. OS patches and software updates applied automatically.

### Monitoring & Alerts 
 24/7 uptime monitoring, resource usage tracking, and instant alerts. Proactive intervention before issues impact users.

 Setup

## A scoped, auditable, revocable access model 
 The first question every security team asks is what exactly we can reach. Three credentials, six scoped policies, a dedicated identity that is never your root account, and revocation you control from your own console.

 Access Key

 Your T Cloud IAM user access key, created with programmatic access.

 Secret Key

 Shown only once when the IAM user is created. Store it securely.

 Domain Name

 Your account domain identifier, found under My Account. It starts with OTC00.

### The six IAM policies, and what each one is for 

 ECS Admin to create and delete the virtual machines Elestio operates, and to manage their lifecycle and SSH keypairs.

 ECS FullAccess to handle reboot, power control, resizing and instance state APIs.

 EVS FullAccess to create and attach root volumes, manage backups, and expand or delete storage.

 VPC Administrator to create VPCs and subnets, configure security groups, manage Elastic IPs and automate firewall rules.

 KMS CMKReadOnlyAccess , read only, to fetch the evs/default key and encrypt root volumes at creation. Elestio never creates encryption keys, it uses the one already in your account.

 DNS Administrator to configure reverse DNS records automatically, which is what makes email deliverability and SSL validation work.

 Access lives in a dedicated IAM user, isolated from your existing resources, and every action it performs is attributable to that identity in your own T Cloud audit trail. You revoke it from your console at any time, without contacting Elestio. Scope must be set to all resources across existing and future projects, otherwise every new deployment needs a manual permission change. On the first encrypted disk in your account, T Cloud requires a one-time EVS service agency per region. Full step by step in the documentation , and the complete security model on the access and security page .

 Comparison

## T Cloud vs AWS vs Azure, with Elestio on top 
 Elestio manages your deployments identically on all three. The difference is who operates the infrastructure, under which jurisdiction, and on which stack.

 T Cloud AWS EC2 Microsoft Azure 
 Operator Deutsche Telekom / T-Systems Amazon (US) Microsoft (US) 
 Primary jurisdiction Germany, EU United States United States 
 Underlying stack OpenStack, open standards Proprietary Proprietary 
 Region used with Elestio Europe, Germany (Magdeburg) 27+ regions worldwide Global regions 
 Credentials Elestio needs Access Key, Secret Key, Domain Name IAM credentials App registration in Azure AD 
 Disk encryption EVS encrypted by default, with the key that already lives in your account EBS volumes Managed disks 
 Who bills the infrastructure Deutsche Telekom, directly to you Amazon, directly to you Microsoft, directly to you 
 Elestio management fee $5/vCPU + $2.50/GB RAM + $0.025/GB disk Same formula Same formula 
 Existing credits and discounts Kept, you pay Telekom directly Kept, EDP and savings plans apply Kept, EA and reservations apply 

 Choose T Cloud when data residency, GDPR or digital sovereignty drive the decision. Choose AWS or Azure when you need a wide global region footprint or you already hold committed spend there. Elestio supports all three as bring your own account providers.

 Full AWS vs T Cloud comparison  ·  Full Azure vs T Cloud comparison 

 Pricing

## Transparent management pricing 
 You pay Deutsche Telekom directly for your T Cloud infrastructure. Elestio charges a separate management fee based on your instance specifications:

 $5

 per vCPU

 $2.50

 per GB RAM

 $0.025

 per GB disk

 Small

 2 vCPU · 4 GB RAM · 80 GB disk

 $22 /mo 

 $10 CPU + $10 RAM + $2 disk

 Medium

 4 vCPU · 8 GB RAM · 160 GB disk

 $44 /mo 

 $20 CPU + $20 RAM + $4 disk

 Large

 8 vCPU · 16 GB RAM · 320 GB disk

 $88 /mo 

 $40 CPU + $40 RAM + $8 disk

 These are Elestio management fees only. T Cloud infrastructure costs are billed separately by Deutsche Telekom on your own account, so any starting credit, committed spend or negotiated discount you hold there still applies. 

 Reviews

## Trusted by 10,000+ Developers Worldwide 
 Real reviews from real users on Trustpilot.

 “

 ★★★★★

 "I'm in the IT industry for over 25 years and Elestio stands out in many ways. The managed services are top-notch, support is incredibly fast, and the platform just works. Couldn't be better!"

 Conflock 
 IT Director · Germany · Verified on Trustpilot 

 See all reviews on Trustpilot

 FAQ

## Frequently Asked Questions 

 What is Bring Your Own T Cloud Account (BYO-T Cloud)? 

 BYO-T Cloud lets you connect your existing T Cloud account to Elestio. Instead of using Elestio shared infrastructure, Elestio creates and manages Elastic Cloud Server instances directly in your own account. You pay Deutsche Telekom directly for all infrastructure costs, and Elestio charges a separate management fee for handling deployments, backups, updates, monitoring, SSL, and security hardening.

 Is T Cloud the same as Open Telekom Cloud? 

 Yes. T Cloud Public is the current name of the service previously known as Open Telekom Cloud, operated by Deutsche Telekom and T-Systems. The console is still at console.otc.t-systems.com and account domain names still start with OTC00, which is why you will see both names in documentation. Elestio lists the provider as T Cloud.

 How does BYO T Cloud pricing work? 

 You pay two separate costs: T Cloud infrastructure billed directly by Deutsche Telekom, plus an Elestio management fee calculated as $5 per vCPU + $2.50 per GB RAM + $0.025 per GB disk. For example, a 2 vCPU, 4 GB RAM, 80 GB instance costs $22 per month in Elestio management fees, plus whatever Deutsche Telekom charges for that Elastic Cloud Server. Any starting credit or negotiated discount on your T Cloud account applies normally.

 What permissions does Elestio need in my T Cloud account? 

 Elestio needs an IAM user with six policies scoped to all resources, existing and future projects: ECS Admin and ECS FullAccess for virtual machine lifecycle, EVS FullAccess for block storage, VPC Administrator for networking and firewall rules, KMS CMKReadOnlyAccess for disk encryption, and DNS Administrator for reverse DNS. You provide an Access Key, a Secret Key and your Domain Name. We strongly recommend creating a dedicated IAM user instead of using root credentials, so your existing resources stay isolated. Full guide in the documentation .

 Are my disks encrypted, and who holds the key? 

 Elestio provisions encrypted Elastic Volume Service volumes by default. Elestio does not create encryption keys. It uses the evs/default key that already exists in your own T Cloud account, so the key never leaves your control. If that key is missing, create one with the alias evs/default under Key Management Service. The first time an encrypted disk is created in your account, T Cloud also requires a one-time EVS service agency, per region.

 Which T Cloud regions can I deploy to? 

 Elestio currently deploys to the European region in Germany, hosted in Magdeburg. Because this is a bring your own account provider, your deployments live inside your own T Cloud account and remain subject to your own contract and data residency terms with Deutsche Telekom.

 Why choose T Cloud over AWS or Azure? 

 T Cloud is operated by Deutsche Telekom under German and EU jurisdiction, and it is built on OpenStack rather than a proprietary stack, which keeps your workloads portable. For organizations where data residency, GDPR or digital sovereignty drive the decision, that combination is the reason to prefer it over a US hyperscaler. AWS and Azure remain the better fit when you need a wide global region footprint or you already hold committed spend. Elestio supports all three as bring your own account providers, with the same management fee formula.

 More on T Cloud

 Managed services for T Cloud Access and security model Shared responsibility and SLA In-house vs managed Public sector Managed PostgreSQL Bring your own T Cloud account AWS vs T Cloud Azure vs T Cloud 

## Your infrastructure is already sovereign. Make it operated. 
 Connect the T Cloud account you already have and let Elestio run the open-source layer on top.

 Get Started