https://elest.io/agents/devin

Devin + Elestio | Deploy with AI Agents | Elest.io 



 ‹ All agents 
 Autonomous Agent 

# Devin + Elestio 
 Devin is the world's first fully autonomous AI software engineer by Cognition Labs. When paired with Elestio, it can deploy applications, manage infrastructure, configure backups, and handle your entire DevOps workflow.

 Get Started Free 

 Install CLI

 Getting Started

## Up and Running in Minutes 
 Install the CLI, authenticate, and deploy your first service with Devin.

 1

#### Install the Elestio CLI 
 Global npm package, zero dependencies.

 2

#### Add the Elestio skill 
 Gives Cursor access to 400+ templates.

 3

#### Access Devin 
 Open Devin at devin.ai and start a session.

 4

#### Configure credentials 
 API token from dash.elest.io/account/security 

 5

#### Deploy your first service 
 Ask Cursor to deploy, it uses the Elestio CLI automatically.

 terminal 

 # Step 1: Install CLI 

 $ npm install -g elestio 

 # Step 2: Add skill 

 $ npx skills add elestio/elestio-skill 

   Elestio skill added 

 # Step 3: Authenticate 

 $ elestio login --email " [email protected] " --token "your_api_token" 

   Authenticated successfully 

 # Step 4: Deploy! 

 $ elestio deploy PostgreSQL --project 112 --name my-db --provider hetzner 

   PostgreSQL deployed in 2m 18s 

 What you can ask

## Example Prompts 

 "Deploy N8N on Netcup in Germany"

 "Add a custom SSL domain to my service"

 "Scale my service to 8 vCPUs and 16GB memory"

 "Create a firewall rule to whitelist my IP"

 "Create a backup before migration"

 "Deploy my GitHub repo with CI/CD"

 "Add your SSH-key to my server"

 "Reboot my server"

 "Add 50GB of storage to my service"

 "Get the admin credentials for my database"

 Full platform access

## Elestio CLI 

 The Elestio CLI gives Cursor full access to the Elestio platform, deploy services, manage infrastructure, configure backups, and more. 400+ templates, any cloud provider, 100+ regions.

 View on GitHub →

 terminal 

 # Install Elestio CLI 

 $ npm install -g elestio 

 # Authenticate 

 $ elestio login --email " [email protected] " --token "your_api_token" 

   Authenticated successfully 

 # Search templates 

 $ elestio templates search "postgresql" 

 # Deploy a service 

 $ elestio deploy PostgreSQL --project 112 

   Service deployed successfully 

 Use cases

## Common Workflows 

### Deploy a database 

Ask Devin to deploy PostgreSQL

Searches with elestio templates search 

Selects provider and region

Deploys with elestio deploy 

### Deploy from GitHub 

Ask Devin to deploy your repo

Deploys CI/CD with elestio deploy cicd 

Creates pipeline with elestio cicd create 

Configures auto-deploy

### Configure backups 

Ask Devin to set up backups

Enables with elestio backups auto-enable 

Creates snapshot with elestio snapshots take 

Confirms backup schedule

### Set up firewall 

Ask Devin to configure firewall

Lists rules with elestio firewall get 

Adds rules with elestio firewall enable 

Verifies configuration

### Check billing 

Ask Devin for billing overview

Runs elestio billing 

Shows costs with elestio billing project 

Provides cost breakdown

### Add SSL / custom domain 

Ask Devin to add a domain

Adds with elestio ssl add 

Provides DNS instructions

Verifies SSL is working

 Support

## Frequently Asked Questions 

 How do I give Devin access to Elestio? + 
 Install the Elestio CLI with npm install -g elestio and authenticate with elestio login . This gives Devin access to Elestio's full API for deployments, backups, and infrastructure management.

 What can I deploy with Devin + Elestio? + 
 Anything from Elestio's catalog of 400+ open-source templates, databases (PostgreSQL, MySQL, MongoDB), CMS (WordPress, Ghost), development tools (GitLab, Gitea), monitoring (Grafana, Prometheus), and more. You can also deploy custom apps from GitHub with CI/CD pipelines.

 Can Devin manage existing Elestio services? + 
 Yes! Devin can list, manage, resize, and delete your existing services. It can also configure backups, firewall rules, SSL certificates, and check billing, all from your IDE.

 How does billing work when deploying via Devin? + 
 Billing works exactly the same as deploying from the Elestio dashboard. Services are billed to your Elestio account based on the provider, region, and server size you choose. Devin can show you pricing with elestio sizes before deploying.

 Explore more

## Related Agents 

### Cursor AI Code Editor

### Claude Code Anthropic

### Codex OpenAI

### OpenCode Open Source CLI

### GitHub Copilot GitHub

### Windsurf AI IDE

### Cline VS Code Extension

## Start deploying with Devin 
 Install the Elestio CLI and let Devin handle your infrastructure.

 Get Started Free 

 GitHub