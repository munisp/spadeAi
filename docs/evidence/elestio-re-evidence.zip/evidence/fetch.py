import sys,re,time,urllib.request,pathlib,html
from concurrent.futures import ThreadPoolExecutor
def text(u):
    r=urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0 research'})
    s=urllib.request.urlopen(r,timeout=30).read().decode('utf-8','ignore')
    s=re.sub(r'(?is)<(script|style|svg|noscript)[^>]*>.*?</\1>',' ',s)
    m=re.search(r'(?is)<(main|article)[^>]*>(.*)</\1>',s)
    body=m.group(2) if m else s
    body=re.sub(r'(?i)<(h[1-6])[^>]*>',lambda m:'\n\n'+'#'*int(m.group(1)[1])+' ',body)
    body=re.sub(r'(?i)<(br|/p|/li|/tr|/div|li)[^>]*>','\n',body)
    t=html.unescape(re.sub(r'<[^>]+>',' ',body))
    t=re.sub(r'[ \t]+',' ',t); t=re.sub(r'\n\s*\n+','\n\n',t)
    return t.strip()
out=pathlib.Path(sys.argv[2])
urls=[l.strip() for l in open(sys.argv[1]) if l.strip()]
def go(u):
    name=re.sub(r'[^a-zA-Z0-9]+','_',u.split('//',1)[1]).strip('_')[:150]
    try: (out/(name+'.md')).write_text(u+'\n\n'+text(u))
    except Exception as e: print('ERR',u,e)
with ThreadPoolExecutor(6) as ex: list(ex.map(go,urls))
